"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import type { User } from "firebase/auth"
import { useRouter } from "next/navigation"
import { onAuthChange as firebaseOnAuthChange, signOut as firebaseSignOut } from "@/lib/firebase/auth"

interface AuthContextType {
  user: User | null
  loading: boolean
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  signOut: async () => {},
})

export const useAuth = () => useContext(AuthContext)

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    try {
      const unsubscribe = firebaseOnAuthChange((authUser: User | null) => {
        setUser(authUser)
        setLoading(false)
      })
      return () => {
        if (typeof unsubscribe === "function") {
          unsubscribe()
        }
      }
    } catch (error) {
      console.error("Error setting up auth listener:", error)
      setLoading(false)
      return () => {}
    }
  }, [])

  const handleSignOut = async () => {
    try {
      await firebaseSignOut()
      router.push("/signin")
    } catch (error) {
      console.error("Error signing out:", error)
      // Even if sign out fails, redirect to sign in page
      router.push("/signin")
    }
  }

  const value = {
    user,
    loading,
    signOut: handleSignOut,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
