export interface Message {
  id: string
  conversationId: string
  senderId: string
  receiverId: string
  content: string
  timestamp: any // Firestore timestamp
  read: boolean
  type: "text" | "image" | "system"
}

export interface Conversation {
  id: string
  participants: string[] // Array of user IDs
  lastMessage?: {
    content: string
    timestamp: any
    senderId: string
  }
  lastActivity: any // Firestore timestamp
  unreadCount: { [userId: string]: number }
  createdAt: any
  participantNames?: { [userId: string]: string }
  participantPhotos?: { [userId: string]: string | null }
  participantProfileIds?: { [userId: string]: string }
}

export interface ConversationWithProfile {
  conversation: Conversation
  otherUserProfile?: {
    id: string
    name: string
    photos: string[]
  }
}
