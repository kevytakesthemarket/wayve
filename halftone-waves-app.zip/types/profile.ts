export interface Profile {
  id: string
  slug?: string
  userId?: string
  name: string
  displayName?: string
  categoryTags: string[]
  bio: string
  bioTag: string
  whyHere: string
  whyHereTag: string
  lookingFor: string
  lookingForTag: string
  politicalBeliefs?: string
  politicalBeliefsTag?: string
  controversialBelief?: string
  controversialBeliefTag?: string
  contactInfo?: {
    telegram?: string
    twitter?: string
    email?: string
  }
  photos: string[]
  photoCropSettings?: Array<{
    cropX: number
    cropY: number
    cropScale: number
  }>
  externalLinks?: Array<{
    title: string
    url: string
    description?: string
  }>
  event: "freedomfest" | "fee" // New field to distinguish events
  createdAt?: any
  updatedAt?: any
  cropSettings?: Array<{
    cropX: number
    cropY: number
    cropScale: number
  }>
}
