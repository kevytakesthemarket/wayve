import type { Profile } from "@/types/profile"
import { v4 as uuidv4 } from "uuid"

// Mock profiles for initial data
const mockProfiles: Profile[] = [
  {
    id: "1",
    name: "Alex Chen",
    categoryTags: ["Libertarian", "Entrepreneur", "Crypto"],
    bio: "Futurist and blockchain enthusiast",
    bioTag: "Crypto Builder",
    whyHere: "To connect with forward-thinking individuals",
    whyHereTag: "Network Growth",
    lookingFor: "Collaborators for decentralized projects",
    lookingForTag: "DeFi Partners",
    politicalBeliefs: "Techno-optimist, pro-innovation policies",
    politicalBeliefsTag: "Techno-optimist",
    controversialBelief: "AGI will solve more problems than it creates",
    controversialBeliefTag: "Pro-AGI",
    contactInfo: {
      telegram: "@alexchen",
      twitter: "@alexc_future",
    },
    photos: ["/placeholder.svg?key=n9c8m", "/blockchain-conference.png"],
  },
  {
    id: "2",
    name: "Maya Johnson",
    categoryTags: ["Progressive", "Scientist", "AI", "Philosophy"],
    bio: "Neuroscientist exploring consciousness",
    bioTag: "Mind Explorer",
    whyHere: "To discuss the intersection of mind and technology",
    whyHereTag: "Tech Philosophy",
    lookingFor: "Deep conversations about the nature of reality",
    lookingForTag: "Reality Debates",
    politicalBeliefs: "Scientific pragmatism, evidence-based policy",
    politicalBeliefsTag: "Evidence-based",
    contactInfo: {
      email: "maya@consciousness.io",
    },
    photos: ["/placeholder.svg?key=wiuhi", "/placeholder.svg?key=08mpy", "/placeholder.svg?key=cwxki"],
  },
  {
    id: "3",
    name: "Raj Patel",
    categoryTags: ["Centrist", "Entrepreneur", "Climate"],
    bio: "Climate tech entrepreneur",
    bioTag: "Climate Innovator",
    whyHere: "To find partners for sustainable innovation",
    whyHereTag: "Green Partners",
    lookingFor: "Investors and engineers passionate about solving climate change",
    lookingForTag: "Climate Team",
    politicalBeliefs: "Eco-pragmatist, market-based environmental solutions",
    politicalBeliefsTag: "Eco-pragmatist",
    controversialBelief: "Nuclear energy is essential for climate stability",
    controversialBeliefTag: "Pro-Nuclear",
    contactInfo: {
      twitter: "@raj_climatetech",
      telegram: "@rajpatel",
    },
    photos: ["/placeholder.svg?key=1lhwg", "/solar-panel-installation.png"],
  },
]

// In-memory storage for profiles
let profiles: Profile[] = [...mockProfiles]

// Get all profiles
export const getMockProfiles = (): Profile[] => {
  return profiles
}

// Get a profile by ID
export const getMockProfile = (id: string): Profile | undefined => {
  return profiles.find((profile) => profile.id === id)
}

// Create a new profile
export const createMockProfile = (profile: Omit<Profile, "id">): Profile => {
  const newProfile = { ...profile, id: uuidv4() }
  profiles = [...profiles, newProfile]
  return newProfile
}

// Update a profile
export const updateMockProfile = (id: string, data: Partial<Profile>): Profile | undefined => {
  const index = profiles.findIndex((p) => p.id === id)
  if (index !== -1) {
    profiles[index] = { ...profiles[index], ...data }
    return profiles[index]
  }
  return undefined
}

// Delete a profile
export const deleteMockProfile = (id: string): boolean => {
  const initialLength = profiles.length
  profiles = profiles.filter((p) => p.id !== id)
  return profiles.length < initialLength
}

// Filter profiles by tags
export const filterMockProfilesByTags = (tags: string[]): Profile[] => {
  if (!tags.length) return profiles
  return profiles.filter((profile) => tags.some((tag) => profile.categoryTags.includes(tag)))
}

// Search profiles
export const searchMockProfiles = (searchTerm: string): Profile[] => {
  if (!searchTerm) return profiles
  const lowerSearchTerm = searchTerm.toLowerCase()
  return profiles.filter(
    (profile) =>
      profile.name.toLowerCase().includes(lowerSearchTerm) ||
      profile.bio.toLowerCase().includes(lowerSearchTerm) ||
      (profile.bioTag && profile.bioTag.toLowerCase().includes(lowerSearchTerm)) ||
      (profile.whyHereTag && profile.whyHereTag.toLowerCase().includes(lowerSearchTerm)) ||
      (profile.lookingForTag && profile.lookingForTag.toLowerCase().includes(lowerSearchTerm)),
  )
}

// Mock photo upload
export const mockUploadProfileImages = (files: File[]): string[] => {
  return files.map((_, index) => `/placeholder.svg?height=400&width=300&query=profile photo placeholder ${index + 1}`)
}
