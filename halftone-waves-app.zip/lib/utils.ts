import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

/**
 * Combines multiple class names using clsx and tailwind-merge
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Checks if a string is a valid URL
 */
export function isValidUrl(url: string): boolean {
  try {
    new URL(url)
    return true
  } catch (e) {
    return false
  }
}

/**
 * Checks if a URL is a Firebase Storage URL
 */
export function isFirebaseStorageUrl(url: string): boolean {
  return (
    url &&
    (url.includes("firebasestorage.googleapis.com") || url.includes("firebasestorage.app") || url.startsWith("gs://"))
  )
}

/**
 * Ensures a Firebase Storage URL has the alt=media parameter
 */
export function ensureValidImageUrl(url: string): string {
  if (!url) return "/placeholder.svg"

  // If it's a relative URL starting with /, it's a local asset
  if (url.startsWith("/")) return url

  // For Firebase Storage URLs, ensure they have the alt=media parameter
  if (isFirebaseStorageUrl(url) && !url.includes("alt=media")) {
    return url.includes("?") ? `${url}&alt=media` : `${url}?alt=media`
  }

  return url
}

/**
 * Logs an error when an image fails to load
 */
export function logImageError(url: string, error?: any): void {
  console.error(`Image failed to load: ${url}`, error)
}

/**
 * Extracts the storage path from a Firebase Storage URL
 */
export function extractStoragePathFromUrl(url: string): string | null {
  if (!url || !url.includes("firebasestorage.googleapis.com")) {
    return null
  }

  try {
    // Extract the path from the URL
    const match = url.match(/\/o\/([^?]+)/)
    if (!match || !match[1]) {
      return null
    }

    // Decode the URL-encoded path
    return decodeURIComponent(match[1])
  } catch (error) {
    console.error("Error extracting storage path from URL:", error)
    return null
  }
}

/**
 * Creates a URL-friendly slug from a string
 */
export function createSlug(text: string): string {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, "-") // Replace spaces with -
    .replace(/&/g, "-and-") // Replace & with 'and'
    .replace(/[^\w-]+/g, "") // Remove all non-word characters
    .replace(/--+/g, "-") // Replace multiple - with single -
    .replace(/^-+/, "") // Trim - from start of text
    .replace(/-+$/, "") // Trim - from end of text
}
