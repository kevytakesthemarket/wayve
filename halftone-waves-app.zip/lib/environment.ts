// Environment configuration for different events
export type EventType = "freedomfest" | "fee"

// Current event configuration - set to FEE only
export const CURRENT_EVENT: EventType = "fee" // Set to 'fee' for new FEE Student Seminar

// Event configurations
export const EVENT_CONFIG = {
  freedomfest: {
    name: "FreedomFest",
    shortName: "FreedomFest",
    description: "A networking tool that replaces small talk.",
    tagline: "Discover other people at FreedomFest through fast, personalized profiles built for real connection.",
    color: "purple",
  },
  fee: {
    name: "FEE Student Seminar",
    shortName: "FEE",
    description: "Connect with fellow students and liberty advocates.",
    tagline: "Discover other attendees at the FEE Student Seminar through personalized profiles.",
    color: "blue",
  },
} as const

// Get current event configuration
export const getCurrentEventConfig = () => EVENT_CONFIG[CURRENT_EVENT]

// Collection names - back to original names since we're using event filtering
export const getCollectionNames = () => ({
  profiles: "profiles",
  conversations: "conversations",
  messages: "messages",
  users: "users",
})

// Log current environment
export const logEnvironment = () => {
  const config = getCurrentEventConfig()
  console.log(`🎯 Current Event: ${config.name}`)
  console.log(`📊 Collections: ${JSON.stringify(getCollectionNames())}`)
}
