/**
 * Compresses an image file to reduce its size
 * @param file The image file to compress
 * @param maxWidth Maximum width of the compressed image
 * @param quality JPEG quality (0-1)
 * @returns Promise with the compressed file
 */
export const compressImage = async (file: File, maxWidth = 1200, quality = 0.7): Promise<File> => {
  // Skip compression for small files (less than 100KB)
  if (file.size < 100 * 1024) {
    console.log(`Skipping compression for small file: ${file.name} (${(file.size / 1024).toFixed(2)}KB)`)
    return file
  }

  // Skip compression for non-image files
  if (!file.type.startsWith("image/")) {
    console.log(`Skipping compression for non-image file: ${file.name}`)
    return file
  }

  // Skip compression for GIFs to preserve animation
  if (file.type === "image/gif") {
    console.log(`Skipping compression for GIF: ${file.name}`)
    return file
  }

  return new Promise((resolve, reject) => {
    try {
      const reader = new FileReader()
      reader.readAsDataURL(file)
      reader.onload = (event) => {
        const img = new Image()
        img.src = event.target?.result as string
        img.crossOrigin = "anonymous"

        img.onload = () => {
          // Calculate new dimensions
          let width = img.width
          let height = img.height

          if (width > maxWidth) {
            height = (height * maxWidth) / width
            width = maxWidth
          }

          // Create canvas and draw image
          const canvas = document.createElement("canvas")
          canvas.width = width
          canvas.height = height
          const ctx = canvas.getContext("2d")

          if (!ctx) {
            console.error("Could not get canvas context")
            resolve(file) // Return original file if compression fails
            return
          }

          // Draw image on canvas with a white background for transparent PNGs
          ctx.fillStyle = "#FFFFFF"
          ctx.fillRect(0, 0, width, height)
          ctx.drawImage(img, 0, 0, width, height)

          // Determine output type and quality
          let outputType = file.type
          let outputQuality = quality

          // For large files, use more aggressive compression
          if (file.size > 2 * 1024 * 1024) {
            // > 2MB
            outputType = "image/jpeg"
            outputQuality = 0.6
          } else if (file.size > 1 * 1024 * 1024) {
            // > 1MB
            outputQuality = 0.65
          }

          // Convert to blob
          canvas.toBlob(
            (blob) => {
              if (!blob) {
                console.error("Failed to create blob from canvas")
                resolve(file) // Return original file if compression fails
                return
              }

              // Create new file from blob
              const compressedFile = new File([blob], file.name, {
                type: outputType,
                lastModified: Date.now(),
              })

              console.log(
                `Compressed ${file.name}: ${(file.size / 1024).toFixed(2)}KB → ${(compressedFile.size / 1024).toFixed(
                  2,
                )}KB (${((compressedFile.size / file.size) * 100).toFixed(1)}%)`,
              )

              // If compression actually made it bigger, return the original
              if (compressedFile.size > file.size) {
                console.log(`Compression increased file size, using original for ${file.name}`)
                resolve(file)
              } else {
                resolve(compressedFile)
              }
            },
            outputType,
            outputQuality,
          )
        }

        img.onerror = () => {
          console.error(`Error loading image for compression: ${file.name}`)
          resolve(file) // Return original file if compression fails
        }
      }

      reader.onerror = () => {
        console.error(`Error reading file for compression: ${file.name}`)
        resolve(file) // Return original file if compression fails
      }
    } catch (error) {
      console.error(`Error compressing image: ${file.name}`, error)
      resolve(file) // Return original file if compression fails
    }
  })
}

/**
 * Compresses multiple image files
 * @param files Array of image files to compress
 * @param maxWidth Maximum width of the compressed images
 * @param quality JPEG quality (0-1)
 * @returns Promise with array of compressed files
 */
export const compressImages = async (files: File[], maxWidth = 1200, quality = 0.7): Promise<File[]> => {
  if (!files.length) return []

  try {
    console.log(`Compressing ${files.length} images...`)
    const compressedFiles = await Promise.all(
      files.map(async (file) => {
        return await compressImage(file, maxWidth, quality)
      }),
    )
    return compressedFiles
  } catch (error) {
    console.error("Error compressing multiple images:", error)
    return files // Return original files if compression fails
  }
}
