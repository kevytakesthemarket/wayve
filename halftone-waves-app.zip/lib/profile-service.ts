import type { Profile } from "@/types/profile"
import { db } from "./firebase"
import { logEnvironment, CURRENT_EVENT } from "./environment"
import { uploadImages, deleteImage } from "./firebase/storage"

// Log environment on import
if (typeof window !== "undefined") {
  logEnvironment()
}

// Available category tags
export const CATEGORY_TAGS = {
  POLITICAL: [
    "Libertarian",
    "Conservative",
    "Republican",
    "Democrat",
    "Ancap",
    "Minarchist",
    "Progressive",
    "Centrist",
    "Voluntaryist",
  ],
  OCCUPATION: [
    "Entrepreneur",
    "Developer",
    "Investor",
    "Farmer",
    "Artist",
    "Scientist",
    "Writer",
    "Educator",
    "Student",
  ],
  INTERESTS: ["Crypto", "AI", "Climate", "Space", "Biotech", "Philosophy", "Economics", "Privacy", "Community"],
  ORGANIZATION: ["Students for Liberty", "Foundation for Economic Education"],
}

// Get all profiles (filtered by current event)
export const getProfiles = async (eventFilter?: "freedomfest" | "fee"): Promise<Profile[]> => {
  if (!db) {
    console.error("Firebase DB not available")
    return []
  }

  try {
    // Import Firebase functions dynamically
    const { getProfilesFromFirestore } = await import("./firebase/db")

    // Get profiles from Firestore
    console.log("Fetching profiles from Firestore")
    const firestoreProfiles = await getProfilesFromFirestore()

    // Filter by event (use eventFilter if provided, otherwise use CURRENT_EVENT)
    const targetEvent = eventFilter || CURRENT_EVENT
    const filteredProfiles = firestoreProfiles.filter((profile) => profile.event === targetEvent)

    console.log(`Fetched ${filteredProfiles.length} profiles for event: ${targetEvent}`)
    return filteredProfiles
  } catch (error) {
    console.error("Error getting profiles from Firestore:", error)
    return []
  }
}

// Get a profile by ID (updated to handle both slug and userId)
export const getProfile = async (identifier: string): Promise<Profile | undefined> => {
  if (!db) {
    console.error("Firebase DB not available")
    return undefined
  }

  try {
    // Import Firebase functions dynamically
    const { getProfileFromFirestore, getProfileByUserId } = await import("./firebase/db")

    // First try to get by profile ID/slug
    let firestoreProfile = await getProfileFromFirestore(identifier)

    // If not found, try by userId (fallback for direct userId access)
    if (!firestoreProfile) {
      firestoreProfile = await getProfileByUserId(identifier)
    }

    return firestoreProfile || undefined
  } catch (error) {
    console.error("Error getting profile from Firestore:", error)
    return undefined
  }
}

// Create a new profile (automatically tagged with current event)
export const createProfile = async (profile: Omit<Profile, "id" | "event">, userId?: string): Promise<Profile> => {
  console.log("createProfile called with userId:", userId)

  if (!db || !userId) {
    throw new Error("Firebase DB not available or user not authenticated")
  }

  try {
    console.log("Creating profile in Firestore")
    // Import Firebase functions dynamically
    const { createProfileInFirestore } = await import("./firebase/db")

    // Add current event to profile
    const profileWithEvent = {
      ...profile,
      event: CURRENT_EVENT, // Automatically tag with current event
    }

    // Create profile in Firestore with timeout handling
    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(() => reject(new Error("Profile creation timed out after 30 seconds")), 30000)
    })

    // Race between the actual operation and the timeout
    return (await Promise.race([createProfileInFirestore(profileWithEvent, userId), timeoutPromise])) as Profile
  } catch (error) {
    console.error("Error creating profile in Firestore:", error)
    throw error
  }
}

// Update a profile
export const updateProfile = async (id: string, data: Partial<Profile>): Promise<Profile | undefined> => {
  if (!db) {
    throw new Error("Firebase DB not available")
  }

  try {
    // Import Firebase functions dynamically
    const { updateProfileInFirestore } = await import("./firebase/db")

    // Update profile in Firestore
    await updateProfileInFirestore(id, data)
    return await getProfile(id)
  } catch (error) {
    console.error("Error updating profile in Firestore:", error)
    throw error
  }
}

// Delete a profile
export const deleteProfile = async (id: string): Promise<boolean> => {
  if (!db) {
    throw new Error("Firebase DB not available")
  }

  try {
    // Import Firebase functions dynamically
    const { deleteProfileFromFirestore } = await import("./firebase/db")

    // Delete profile from Firestore
    await deleteProfileFromFirestore(id)
    return true
  } catch (error) {
    console.error("Error deleting profile from Firestore:", error)
    throw error
  }
}

// Filter profiles by tags
export const filterProfilesByTags = async (tags: string[], eventFilter?: "freedomfest" | "fee"): Promise<Profile[]> => {
  if (!tags.length) return getProfiles(eventFilter)

  if (!db) {
    console.error("Firebase DB not available")
    return []
  }

  try {
    // Import Firebase functions dynamically
    const { getProfilesByTags } = await import("./firebase/db")

    // Filter profiles by tags in Firestore
    const profiles = await getProfilesByTags(tags)

    // Filter by event
    const targetEvent = eventFilter || CURRENT_EVENT
    return profiles.filter((profile) => profile.event === targetEvent)
  } catch (error) {
    console.error("Error filtering profiles by tags in Firestore:", error)
    return []
  }
}

// Search profiles
export const searchProfilesService = async (
  searchTerm: string,
  eventFilter?: "freedomfest" | "fee",
): Promise<Profile[]> => {
  if (!searchTerm) return getProfiles(eventFilter)

  if (!db) {
    console.error("Firebase DB not available")
    return []
  }

  try {
    // Import Firebase functions dynamically
    const { searchProfiles } = await import("./firebase/db")

    // Search profiles in Firestore
    const profiles = await searchProfiles(searchTerm)

    // Filter by event
    const targetEvent = eventFilter || CURRENT_EVENT
    return profiles.filter((profile) => profile.event === targetEvent)
  } catch (error) {
    console.error("Error searching profiles in Firestore:", error)
    return []
  }
}

// Upload profile photos and get URLs
export const uploadProfileImages = async (
  files: File[],
  userId = "anonymous", // Make userId optional with default value
  onProgress?: (progress: number) => void,
): Promise<string[]> => {
  try {
    console.log(`Uploading ${files.length} profile photos for user ${userId}`)

    // Use our upload function with progress tracking
    const downloadURLs = await uploadImages(files, userId, onProgress)

    console.log(`Successfully uploaded ${downloadURLs.length} profile photos`)
    return downloadURLs
  } catch (error) {
    console.error("Error uploading profile photos:", error)
    throw error
  }
}

// Delete a profile image from Firebase Storage
export const deleteProfileImage = async (storagePath: string): Promise<boolean> => {
  try {
    console.log(`Deleting profile photo: ${storagePath}`)

    // Use the deleteImage function from firebase/storage
    await deleteImage(storagePath)

    console.log(`Successfully deleted profile photo: ${storagePath}`)
    return true
  } catch (error) {
    console.error(`Error deleting profile photo: ${storagePath}`, error)
    throw error
  }
}
