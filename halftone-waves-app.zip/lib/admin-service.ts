import { collection, getDocs, Timestamp } from "firebase/firestore"
import { db } from "@/lib/firebase"

export interface AdminStats {
  totalUsers: number
  totalProfiles: number
  totalMessages: number
  totalConversations: number
  newUsersToday: number
  newUsersThisWeek: number
  newUsersThisMonth: number
  activeUsersToday: number
  activeUsersThisWeek: number
  profilesWithPhotos: number
  profilesWithoutPhotos: number
  averagePhotosPerProfile: number
  profileCompletionRate: number
  dailyActiveRate: number
  weeklyActiveRate: number
  topTags: Array<{ tag: string; count: number }>
  messageStats: {
    totalConversations: number
    messagesPerDay: number
    averageMessagesPerConversation: number
    conversationsToday: number
    conversationsThisWeek: number
  }
  storageStats: {
    totalImages: number
    estimatedStorageUsed: string
  }
  engagementMetrics: {
    usersWithMessages: number
    usersWithProfiles: number
    messagingEngagementRate: number
    profileCreationRate: number
  }
  debugInfo: {
    firebaseConnected: boolean
    collectionsFound: string[]
    errors: string[]
  }
}

export interface RecentUser {
  id: string
  email: string
  displayName: string
  createdAt: Date
  lastActive: Date
  profileComplete: boolean
  photoCount: number
  hasMessages: boolean
}

export interface BusinessMetrics {
  userGrowth: {
    total: number
    today: number
    week: number
    month: number
    growthRate: number
  }
  engagement: {
    profileCreation: number
    messaging: number
    photoUploads: number
    dailyActive: number
  }
  retention: {
    weeklyActive: number
    monthlyActive: number
    returningUsers: number
  }
}

export class AdminService {
  static async getStats(): Promise<AdminStats> {
    const debugInfo = {
      firebaseConnected: false,
      collectionsFound: [] as string[],
      errors: [] as string[],
    }

    try {
      console.log("🔍 Starting admin stats fetch...")
      console.log("Firebase db object:", db)

      if (!db) {
        throw new Error("Firebase database not initialized")
      }

      debugInfo.firebaseConnected = true

      const now = new Date()
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
      const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000)
      const monthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000)

      console.log("📅 Date ranges:", { today, weekAgo, monthAgo })

      // Test each collection individually with detailed logging
      let usersSnapshot, profilesSnapshot, messagesSnapshot, conversationsSnapshot

      try {
        console.log("👥 Fetching users collection...")
        usersSnapshot = await getDocs(collection(db, "users"))
        console.log(`✅ Users collection: ${usersSnapshot.size} documents`)
        debugInfo.collectionsFound.push(`users: ${usersSnapshot.size}`)
      } catch (error) {
        console.error("❌ Error fetching users:", error)
        debugInfo.errors.push(`Users collection error: ${error}`)
        usersSnapshot = { docs: [], size: 0 }
      }

      try {
        console.log("📝 Fetching profiles collection...")
        profilesSnapshot = await getDocs(collection(db, "profiles"))
        console.log(`✅ Profiles collection: ${profilesSnapshot.size} documents`)
        debugInfo.collectionsFound.push(`profiles: ${profilesSnapshot.size}`)
      } catch (error) {
        console.error("❌ Error fetching profiles:", error)
        debugInfo.errors.push(`Profiles collection error: ${error}`)
        profilesSnapshot = { docs: [], size: 0 }
      }

      try {
        console.log("💬 Fetching messages collection...")
        messagesSnapshot = await getDocs(collection(db, "messages"))
        console.log(`✅ Messages collection: ${messagesSnapshot.size} documents`)
        debugInfo.collectionsFound.push(`messages: ${messagesSnapshot.size}`)
      } catch (error) {
        console.error("❌ Error fetching messages:", error)
        debugInfo.errors.push(`Messages collection error: ${error}`)
        messagesSnapshot = { docs: [], size: 0 }
      }

      try {
        console.log("🗨️ Fetching conversations collection...")
        conversationsSnapshot = await getDocs(collection(db, "conversations"))
        console.log(`✅ Conversations collection: ${conversationsSnapshot.size} documents`)
        debugInfo.collectionsFound.push(`conversations: ${conversationsSnapshot.size}`)
      } catch (error) {
        console.error("❌ Error fetching conversations:", error)
        debugInfo.errors.push(`Conversations collection error: ${error}`)
        conversationsSnapshot = { docs: [], size: 0 }
      }

      // Process users data with detailed logging
      const users = usersSnapshot.docs.map((doc, index) => {
        const data = doc.data()
        if (index < 3) {
          console.log(`👤 User ${index + 1} data:`, {
            id: doc.id,
            email: data.email,
            createdAt: data.createdAt,
            lastActive: data.lastActive,
          })
        }
        return {
          id: doc.id,
          ...data,
          createdAt:
            data.createdAt instanceof Timestamp
              ? data.createdAt.toDate()
              : data.createdAt
                ? new Date(data.createdAt)
                : new Date(),
          lastActive:
            data.lastActive instanceof Timestamp
              ? data.lastActive.toDate()
              : data.lastActive
                ? new Date(data.lastActive)
                : new Date(),
        }
      })

      console.log(`📊 Processed ${users.length} users`)

      // Process profiles data with detailed logging
      const profiles = profilesSnapshot.docs.map((doc, index) => {
        const data = doc.data()
        if (index < 3) {
          console.log(`📋 Profile ${index + 1} data:`, {
            id: doc.id,
            userId: data.userId,
            name: data.name,
            photos: data.photos?.length || 0,
            tags: data.tags?.length || 0,
          })
        }
        return {
          id: doc.id,
          ...data,
          createdAt:
            data.createdAt instanceof Timestamp
              ? data.createdAt.toDate()
              : data.createdAt
                ? new Date(data.createdAt)
                : new Date(),
        }
      })

      console.log(`📊 Processed ${profiles.length} profiles`)

      // Process messages data
      const messages = messagesSnapshot.docs.map((doc) => {
        const data = doc.data()
        return {
          id: doc.id,
          ...data,
          timestamp:
            data.timestamp instanceof Timestamp
              ? data.timestamp.toDate()
              : data.timestamp
                ? new Date(data.timestamp)
                : new Date(),
        }
      })

      console.log(`📊 Processed ${messages.length} messages`)

      // Process conversations data
      const conversations = conversationsSnapshot.docs.map((doc) => {
        const data = doc.data()
        return {
          id: doc.id,
          ...data,
          createdAt:
            data.createdAt instanceof Timestamp
              ? data.createdAt.toDate()
              : data.createdAt
                ? new Date(data.createdAt)
                : new Date(),
        }
      })

      console.log(`📊 Processed ${conversations.length} conversations`)

      // Calculate user metrics
      const newUsersToday = users.filter((user) => user.createdAt >= today).length
      const newUsersThisWeek = users.filter((user) => user.createdAt >= weekAgo).length
      const newUsersThisMonth = users.filter((user) => user.createdAt >= monthAgo).length
      const activeUsersToday = users.filter((user) => user.lastActive >= today).length
      const activeUsersThisWeek = users.filter((user) => user.lastActive >= weekAgo).length

      console.log("📈 User metrics:", {
        total: users.length,
        newToday: newUsersToday,
        newWeek: newUsersThisWeek,
        newMonth: newUsersThisMonth,
        activeToday: activeUsersToday,
        activeWeek: activeUsersThisWeek,
      })

      // Calculate profile metrics
      const profilesWithPhotos = profiles.filter((profile) => profile.photos && profile.photos.length > 0).length
      const profilesWithoutPhotos = profiles.length - profilesWithPhotos
      const totalPhotos = profiles.reduce((sum, profile) => sum + (profile.photos?.length || 0), 0)
      const averagePhotosPerProfile = profiles.length > 0 ? totalPhotos / profiles.length : 0
      const profileCompletionRate = users.length > 0 ? (profiles.length / users.length) * 100 : 0

      console.log("📸 Profile metrics:", {
        total: profiles.length,
        withPhotos: profilesWithPhotos,
        withoutPhotos: profilesWithoutPhotos,
        totalPhotos,
        averagePhotos: averagePhotosPerProfile,
        completionRate: profileCompletionRate,
      })

      // Calculate engagement metrics
      const usersWithMessages = new Set(messages.map((m) => m.fromUserId)).size
      const usersWithProfiles = profiles.length
      const messagingEngagementRate = users.length > 0 ? (usersWithMessages / users.length) * 100 : 0
      const profileCreationRate = users.length > 0 ? (usersWithProfiles / users.length) * 100 : 0

      // Calculate activity rates
      const dailyActiveRate = users.length > 0 ? (activeUsersToday / users.length) * 100 : 0
      const weeklyActiveRate = users.length > 0 ? (activeUsersThisWeek / users.length) * 100 : 0

      // Calculate tag statistics
      const tagCounts: Record<string, number> = {}
      profiles.forEach((profile) => {
        if (profile.tags && Array.isArray(profile.tags)) {
          profile.tags.forEach((tag: string) => {
            tagCounts[tag] = (tagCounts[tag] || 0) + 1
          })
        }
      })

      const topTags = Object.entries(tagCounts)
        .map(([tag, count]) => ({ tag, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10)

      console.log("🏷️ Tag metrics:", { totalTags: Object.keys(tagCounts).length, topTags: topTags.slice(0, 3) })

      // Calculate message statistics
      const messagesPerDay = messages.filter((message) => message.timestamp >= today).length
      const averageMessagesPerConversation = conversations.length > 0 ? messages.length / conversations.length : 0
      const conversationsToday = conversations.filter((conv) => conv.createdAt >= today).length
      const conversationsThisWeek = conversations.filter((conv) => conv.createdAt >= weekAgo).length

      console.log("💬 Message metrics:", {
        total: messages.length,
        perDay: messagesPerDay,
        avgPerConv: averageMessagesPerConversation,
        convsToday: conversationsToday,
        convsWeek: conversationsThisWeek,
      })

      // Calculate storage
      const estimatedStorageMB = totalPhotos * 0.5
      const estimatedStorageUsed =
        estimatedStorageMB > 1024
          ? `${(estimatedStorageMB / 1024).toFixed(2)} GB`
          : `${estimatedStorageMB.toFixed(2)} MB`

      const stats = {
        totalUsers: users.length,
        totalProfiles: profiles.length,
        totalMessages: messages.length,
        totalConversations: conversations.length,
        newUsersToday,
        newUsersThisWeek,
        newUsersThisMonth,
        activeUsersToday,
        activeUsersThisWeek,
        profilesWithPhotos,
        profilesWithoutPhotos,
        averagePhotosPerProfile: Math.round(averagePhotosPerProfile * 100) / 100,
        profileCompletionRate: Math.round(profileCompletionRate * 100) / 100,
        dailyActiveRate: Math.round(dailyActiveRate * 100) / 100,
        weeklyActiveRate: Math.round(weeklyActiveRate * 100) / 100,
        topTags,
        messageStats: {
          totalConversations: conversations.length,
          messagesPerDay,
          averageMessagesPerConversation: Math.round(averageMessagesPerConversation * 100) / 100,
          conversationsToday,
          conversationsThisWeek,
        },
        storageStats: {
          totalImages: totalPhotos,
          estimatedStorageUsed,
        },
        engagementMetrics: {
          usersWithMessages,
          usersWithProfiles,
          messagingEngagementRate: Math.round(messagingEngagementRate * 100) / 100,
          profileCreationRate: Math.round(profileCreationRate * 100) / 100,
        },
        debugInfo,
      }

      console.log("✅ Final stats calculated:", {
        totalUsers: stats.totalUsers,
        totalProfiles: stats.totalProfiles,
        totalMessages: stats.totalMessages,
        debugInfo: stats.debugInfo,
      })

      return stats
    } catch (error) {
      console.error("💥 Critical error in getStats:", error)
      debugInfo.errors.push(`Critical error: ${error}`)

      // Return empty stats with debug info
      return {
        totalUsers: 0,
        totalProfiles: 0,
        totalMessages: 0,
        totalConversations: 0,
        newUsersToday: 0,
        newUsersThisWeek: 0,
        newUsersThisMonth: 0,
        activeUsersToday: 0,
        activeUsersThisWeek: 0,
        profilesWithPhotos: 0,
        profilesWithoutPhotos: 0,
        averagePhotosPerProfile: 0,
        profileCompletionRate: 0,
        dailyActiveRate: 0,
        weeklyActiveRate: 0,
        topTags: [],
        messageStats: {
          totalConversations: 0,
          messagesPerDay: 0,
          averageMessagesPerConversation: 0,
          conversationsToday: 0,
          conversationsThisWeek: 0,
        },
        storageStats: {
          totalImages: 0,
          estimatedStorageUsed: "0 MB",
        },
        engagementMetrics: {
          usersWithMessages: 0,
          usersWithProfiles: 0,
          messagingEngagementRate: 0,
          profileCreationRate: 0,
        },
        debugInfo,
      }
    }
  }

  static async getRecentUsers(limitCount = 20): Promise<RecentUser[]> {
    try {
      console.log("🔍 Fetching recent users...")

      // Get all users and sort by creation date
      const usersSnapshot = await getDocs(collection(db, "users"))
      console.log(`👥 Found ${usersSnapshot.size} users`)

      const users = usersSnapshot.docs.map((doc) => {
        const data = doc.data()
        return {
          id: doc.id,
          email: data.email || "N/A",
          displayName: data.displayName || "Anonymous",
          createdAt:
            data.createdAt instanceof Timestamp
              ? data.createdAt.toDate()
              : data.createdAt
                ? new Date(data.createdAt)
                : new Date(),
          lastActive:
            data.lastActive instanceof Timestamp
              ? data.lastActive.toDate()
              : data.lastActive
                ? new Date(data.lastActive)
                : new Date(),
        }
      })

      // Sort by creation date and limit
      const sortedUsers = users.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()).slice(0, limitCount)

      // Get additional data for each user
      const [profilesSnapshot, messagesSnapshot] = await Promise.all([
        getDocs(collection(db, "profiles")),
        getDocs(collection(db, "messages")),
      ])

      console.log(`📋 Found ${profilesSnapshot.size} profiles`)
      console.log(`💬 Found ${messagesSnapshot.size} messages`)

      // Create maps for efficient lookup
      const profileMap = new Map()
      profilesSnapshot.docs.forEach((doc) => {
        const data = doc.data()
        if (data.userId) {
          profileMap.set(data.userId, data)
        }
      })

      const userMessagesMap = new Map()
      messagesSnapshot.docs.forEach((doc) => {
        const data = doc.data()
        if (data.fromUserId) {
          userMessagesMap.set(data.fromUserId, true)
        }
      })

      // Enhance user data
      const usersWithProfiles = sortedUsers.map((user) => {
        const profile = profileMap.get(user.id)
        const hasMessages = userMessagesMap.has(user.id)

        return {
          ...user,
          displayName: profile?.name || user.displayName || "Anonymous",
          profileComplete: !!(profile?.name && profile?.bio && profile?.photos?.length > 0),
          photoCount: profile?.photos?.length || 0,
          hasMessages,
        }
      })

      console.log(`✅ Processed ${usersWithProfiles.length} recent users`)
      return usersWithProfiles
    } catch (error) {
      console.error("❌ Error fetching recent users:", error)
      return []
    }
  }

  static async getBusinessMetrics(): Promise<BusinessMetrics> {
    try {
      const stats = await this.getStats()

      // Calculate growth rate (week over week)
      const growthRate =
        stats.newUsersThisWeek > 0 && stats.totalUsers > stats.newUsersThisWeek
          ? (stats.newUsersThisWeek / (stats.totalUsers - stats.newUsersThisWeek)) * 100
          : 0

      return {
        userGrowth: {
          total: stats.totalUsers,
          today: stats.newUsersToday,
          week: stats.newUsersThisWeek,
          month: stats.newUsersThisMonth,
          growthRate: Math.round(growthRate * 100) / 100,
        },
        engagement: {
          profileCreation: stats.engagementMetrics.profileCreationRate,
          messaging: stats.engagementMetrics.messagingEngagementRate,
          photoUploads: stats.profilesWithPhotos,
          dailyActive: stats.dailyActiveRate,
        },
        retention: {
          weeklyActive: stats.weeklyActiveRate,
          monthlyActive: 0, // Would need 30-day tracking
          returningUsers: stats.activeUsersThisWeek - stats.newUsersThisWeek,
        },
      }
    } catch (error) {
      console.error("❌ Error calculating business metrics:", error)
      throw error
    }
  }
}
