// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app"
import { getAuth } from "firebase/auth"
import { getFirestore } from "firebase/firestore"
import { getStorage } from "firebase/storage"
import { getAnalytics, isSupported } from "firebase/analytics"

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDeW9YU5G1w25694HqoVKTdXU6Lmpmigx8",
  authDomain: "wayve-freedomfest.firebaseapp.com",
  projectId: "wayve-freedomfest",
  storageBucket: "wayve-freedomfest.firebasestorage.app",
  messagingSenderId: "932600983573",
  appId: "1:932600983573:web:1ab5e8fc47b03ad2829e1c",
  measurementId: "G-2TK97X0ESQ",
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)

// Initialize Firebase services
const auth = getAuth(app)
const db = getFirestore(app)
const storage = getStorage(app)

// Initialize Analytics only in browser environment
let analytics = null
if (typeof window !== "undefined") {
  // Check if analytics is supported
  isSupported()
    .then((supported) => {
      if (supported) {
        analytics = getAnalytics(app)
      }
    })
    .catch((err) => {
      console.error("Analytics error:", err)
    })
}

// Export the initialized services
export { app, auth, db, storage, analytics }
