import {
  collection,
  doc,
  addDoc,
  getDocs,
  query,
  where,
  orderBy,
  onSnapshot,
  updateDoc,
  serverTimestamp,
  increment,
  writeBatch,
  getDoc,
  type Unsubscribe,
} from "firebase/firestore"
import { db, auth } from "../firebase"
import type { Message, Conversation } from "@/types/message"
import { getCollectionNames } from "@/lib/environment"
import { getProfileFromFirestore, getProfilesByUserId } from "@/lib/firebase/db" // Import missing functions

// Authentication guard helper
const ensureAuthenticated = () => {
  if (!auth.currentUser) {
    throw new Error("User must be authenticated to perform this action")
  }
  return auth.currentUser
}

// Collection references using dynamic collection names
const getMessagesCollection = () => {
  if (!db) throw new Error("Firestore is not initialized")
  const collections = getCollectionNames()
  console.log(`Using messages collection: ${collections.messages}`)
  return collection(db, collections.messages)
}

const getConversationsCollection = () => {
  if (!db) throw new Error("Firestore is not initialized")
  const collections = getCollectionNames()
  console.log(`Using conversations collection: ${collections.conversations}`)
  return collection(db, collections.conversations)
}

// Generate conversation ID from two user IDs (consistent ordering)
export const generateConversationId = (userId1: string, userId2: string): string => {
  return [userId1, userId2].sort().join("_")
}

// Helper function to get user profile with better error handling
const getUserProfile = async (userIdOrSlug: string) => {
  try {
    console.log(`📋 Fetching profile for user: ${userIdOrSlug}`)

    // First try to get profile by document ID (slug)
    let profile = await getProfileFromFirestore(userIdOrSlug)

    if (!profile) {
      console.log(`❌ No profile found with ID ${userIdOrSlug}, trying to find by userId field...`)
      // If not found, try to find by userId field
      const profiles = await getProfilesByUserId(userIdOrSlug)
      if (profiles.length > 0) {
        profile = profiles[0]
        console.log(`✅ Found profile by userId field:`, profile)
      }
    } else {
      console.log(`✅ Found profile by document ID:`, profile)
    }

    if (profile) {
      return {
        id: profile.id,
        userId: profile.userId || userIdOrSlug,
        name: profile.name || profile.displayName || "Unknown User",
        photo: profile.photos?.[0] || null,
      }
    }

    console.log(`❌ No profile found for ${userIdOrSlug}`)
    // If no profile found, return default
    return {
      id: userIdOrSlug,
      userId: userIdOrSlug,
      name: "Unknown User",
      photo: null,
    }
  } catch (error) {
    console.error(`❌ Error fetching profile for ${userIdOrSlug}:`, error)
    return {
      id: userIdOrSlug,
      userId: userIdOrSlug,
      name: "Unknown User",
      photo: null,
    }
  }
}

// Create or get existing conversation
export const createOrGetConversation = async (
  currentUserAuthId: string,
  targetUserIdOrSlug: string,
): Promise<string> => {
  try {
    // 🔒 PARAMETER VALIDATION - Check before any operations
    if (!currentUserAuthId) {
      throw new Error("currentUserAuthId is required but was undefined")
    }

    if (!targetUserIdOrSlug) {
      throw new Error("targetUserIdOrSlug is required but was undefined")
    }

    console.log("🔍 DEBUG - Function Parameters:")
    console.log("currentUserAuthId:", currentUserAuthId, "type:", typeof currentUserAuthId)
    console.log("targetUserIdOrSlug:", targetUserIdOrSlug, "type:", typeof targetUserIdOrSlug)

    // 🔒 AUTHENTICATION GUARD - Check before any operations
    const currentUser = ensureAuthenticated()

    console.log("🔍 DEBUG - createOrGetConversation Authentication Check:")
    console.log("auth.currentUser?.uid:", currentUser.uid)
    console.log("currentUserAuthId parameter:", currentUserAuthId)

    // Validate that the provided ID matches the authenticated user
    if (currentUserAuthId !== currentUser.uid) {
      throw new Error(
        `Authentication mismatch: provided ID ${currentUserAuthId} does not match authenticated user ${currentUser.uid}`,
      )
    }

    console.log(`🚀 Creating conversation between auth user ${currentUserAuthId} and target ${targetUserIdOrSlug}`)

    // Validate that we have an authenticated user ID
    if (!currentUserAuthId || typeof currentUserAuthId !== "string" || currentUserAuthId.length < 20) {
      throw new Error(`Invalid authenticated user ID: ${currentUserAuthId}`)
    }

    // CRITICAL: Always use the authenticated user's UID directly
    const authUserId = currentUserAuthId

    // For the target user, resolve their ID if it's a slug
    let targetUserId = targetUserIdOrSlug

    // If it looks like a slug (not a Firebase UID), try to resolve it
    if (typeof targetUserIdOrSlug === "string" && targetUserIdOrSlug.length < 20) {
      console.log(`🔍 Resolving target slug ${targetUserIdOrSlug}...`)
      const targetProfile = await getProfileFromFirestore(targetUserIdOrSlug)
      if (targetProfile?.userId) {
        console.log(`✅ Resolved target slug ${targetUserIdOrSlug} to userId: ${targetProfile.userId}`)
        targetUserId = targetProfile.userId
      } else {
        console.log(`⚠️ Could not resolve slug ${targetUserIdOrSlug}, using as-is`)
      }
    }

    // Validate target user ID
    if (!targetUserId) {
      throw new Error(`Invalid target user ID: ${targetUserId}`)
    }

    // Prevent self-messaging
    if (authUserId === targetUserId) {
      throw new Error("Cannot create conversation with yourself")
    }

    // Generate conversation ID using the resolved Firebase Auth UIDs
    const conversationId = generateConversationId(authUserId, targetUserId)
    console.log(`🆔 Generated conversation ID: ${conversationId}`)

    const conversationsCollection = getConversationsCollection()
    const conversationRef = doc(conversationsCollection, conversationId)

    // Check if conversation exists
    const conversationDoc = await getDoc(conversationRef)

    if (!conversationDoc.exists()) {
      console.log(`✨ Creating new conversation between ${authUserId} and ${targetUserId}`)

      // Get profiles for display info
      const [authUserProfile, targetUserProfile] = await Promise.all([
        getUserProfile(authUserId),
        getUserProfile(targetUserId),
      ])

      console.log(`👤 Auth user profile:`, {
        id: authUserProfile.id,
        userId: authUserProfile.userId,
        name: authUserProfile.name,
      })
      console.log(`👤 Target user profile:`, {
        id: targetUserProfile.id,
        userId: targetUserProfile.userId,
        name: targetUserProfile.name,
      })

      // ✅ SIMPLIFIED: Create conversation with ONLY required fields first
      const basicConversationData = {
        participants: [authUserId, targetUserId], // ✅ REQUIRED - must be array of Firebase Auth UIDs
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        lastMessage: null,
        unreadCount: {
          [authUserId]: 0,
          [targetUserId]: 0,
        },
      }

      // 🧪 DEBUG: Log the basic data being sent to Firestore
      console.log(`🧪 DEBUG - Basic conversation data being sent to Firestore:`)
      console.log(`   participants:`, basicConversationData.participants)
      console.log(`   participants type:`, Array.isArray(basicConversationData.participants) ? "array" : "not array")
      console.log(`   auth.currentUser.uid:`, auth.currentUser.uid)
      console.log(`   authUserId in participants:`, basicConversationData.participants.includes(auth.currentUser.uid))

      // Create the basic conversation first
      await updateDoc(conversationRef, basicConversationData)
      console.log(`✅ Basic conversation created successfully`)
    } else {
      console.log(`♻️ Conversation ${conversationId} already exists`)
    }

    return conversationId
  } catch (error) {
    console.error(`❌ Error in createOrGetConversation:`, error)
    throw error
  }
}

// Send a message
export const sendMessage = async (
  conversationId: string,
  senderId: string,
  receiverId: string,
  content: string,
): Promise<void> => {
  try {
    // 🔒 AUTHENTICATION GUARD - Check before any operations
    const currentUser = ensureAuthenticated()

    console.log("🔍 DEBUG - sendMessage Authentication Check:")
    console.log("auth.currentUser?.uid:", currentUser.uid)
    console.log("senderId parameter:", senderId)

    // Validate that the sender is the authenticated user
    if (senderId !== currentUser.uid) {
      throw new Error(`Authentication error: senderId ${senderId} does not match authenticated user ${currentUser.uid}`)
    }

    console.log(`📤 Sending message from ${senderId} to ${receiverId}`)

    // Validate sender ID (must be Firebase Auth UID)
    if (!senderId || senderId.length < 20) {
      throw new Error(`Invalid sender ID: ${senderId}`)
    }

    const messagesCollection = getMessagesCollection()
    const conversationsCollection = getConversationsCollection()

    // Add message to messages collection
    const messageData = {
      conversationId,
      senderId,
      receiverId,
      content,
      timestamp: serverTimestamp(),
      read: false,
    }

    await addDoc(messagesCollection, messageData)

    // Update conversation with last message and increment unread count for receiver
    const conversationRef = doc(conversationsCollection, conversationId)
    await updateDoc(conversationRef, {
      lastMessage: {
        content,
        senderId,
        timestamp: serverTimestamp(),
      },
      updatedAt: serverTimestamp(),
      [`unreadCount.${receiverId}`]: increment(1),
    })
  } catch (error) {
    console.error("Error sending message:", error)
    throw error
  }
}

// Get messages for a conversation
export const getMessages = async (conversationId: string): Promise<Message[]> => {
  try {
    // 🔒 AUTHENTICATION GUARD - Check before any operations
    ensureAuthenticated()

    const messagesCollection = getMessagesCollection()
    const q = query(messagesCollection, where("conversationId", "==", conversationId), orderBy("timestamp", "asc"))

    const querySnapshot = await getDocs(q)
    const messages: Message[] = []

    querySnapshot.forEach((doc) => {
      const data = doc.data()
      messages.push({
        id: doc.id,
        conversationId: data.conversationId,
        senderId: data.senderId,
        receiverId: data.receiverId,
        content: data.content,
        timestamp: data.timestamp,
        read: data.read || false,
      })
    })

    return messages
  } catch (error) {
    console.error("Error getting messages:", error)
    throw error
  }
}

// Listen to messages in real-time
export const subscribeToMessages = (conversationId: string, callback: (messages: Message[]) => void): Unsubscribe => {
  try {
    // 🔒 AUTHENTICATION GUARD - Check before any operations
    ensureAuthenticated()

    const messagesCollection = getMessagesCollection()
    const q = query(messagesCollection, where("conversationId", "==", conversationId), orderBy("timestamp", "asc"))

    return onSnapshot(q, (querySnapshot) => {
      const messages: Message[] = []
      querySnapshot.forEach((doc) => {
        const data = doc.data()
        messages.push({
          id: doc.id,
          conversationId: data.conversationId,
          senderId: data.senderId,
          receiverId: data.receiverId,
          content: data.content,
          timestamp: data.timestamp,
          read: data.read || false,
        })
      })
      callback(messages)
    })
  } catch (error) {
    console.error("Error subscribing to messages:", error)
    // Return a dummy unsubscribe function
    return () => {}
  }
}

// Get user's conversations
export const getUserConversations = async (userId: string): Promise<Conversation[]> => {
  try {
    // 🔒 AUTHENTICATION GUARD - Check before any operations
    const currentUser = ensureAuthenticated()

    // Validate that the user is requesting their own conversations
    if (userId !== currentUser.uid) {
      throw new Error(`Authentication error: cannot access conversations for user ${userId}`)
    }

    const conversationsCollection = getConversationsCollection()
    const q = query(conversationsCollection, where("participants", "array-contains", userId))

    const querySnapshot = await getDocs(q)
    const conversations: Conversation[] = []

    querySnapshot.forEach((doc) => {
      const data = doc.data()
      conversations.push({
        id: doc.id,
        participants: data.participants || [],
        lastMessage: data.lastMessage || null,
        updatedAt: data.updatedAt,
        unreadCount: data.unreadCount || {},
      })
    })

    return conversations.sort((a, b) => {
      const aTime = a.updatedAt?.toMillis() || 0
      const bTime = b.updatedAt?.toMillis() || 0
      return bTime - aTime
    })
  } catch (error) {
    console.error("Error getting user conversations:", error)
    return []
  }
}

// Listen to user's conversations in real-time
export const subscribeToUserConversations = (
  userId: string,
  callback: (conversations: Conversation[]) => void,
): Unsubscribe => {
  try {
    // 🔒 AUTHENTICATION GUARD - Check before any operations
    const currentUser = ensureAuthenticated()

    // Validate that the user is subscribing to their own conversations
    if (userId !== currentUser.uid) {
      throw new Error(`Authentication error: cannot subscribe to conversations for user ${userId}`)
    }

    const conversationsCollection = getConversationsCollection()
    const q = query(conversationsCollection, where("participants", "array-contains", userId))

    return onSnapshot(q, (querySnapshot) => {
      const conversations: Conversation[] = []
      querySnapshot.forEach((doc) => {
        const data = doc.data()
        conversations.push({
          id: doc.id,
          participants: data.participants || [],
          lastMessage: data.lastMessage || null,
          updatedAt: data.updatedAt,
          unreadCount: data.unreadCount || {},
        })
      })

      // Sort by last updated
      conversations.sort((a, b) => {
        const aTime = a.updatedAt?.toMillis() || 0
        const bTime = b.updatedAt?.toMillis() || 0
        return bTime - aTime
      })

      callback(conversations)
    })
  } catch (error) {
    console.error("Error subscribing to user conversations:", error)
    // Return a dummy unsubscribe function
    return () => {}
  }
}

// Mark messages as read
export const markMessagesAsRead = async (conversationId: string, userId: string): Promise<void> => {
  try {
    // 🔒 AUTHENTICATION GUARD - Check before any operations
    const currentUser = ensureAuthenticated()

    // Validate that the user is marking their own messages as read
    if (userId !== currentUser.uid) {
      throw new Error(`Authentication error: cannot mark messages as read for user ${userId}`)
    }

    const messagesCollection = getMessagesCollection()
    const conversationsCollection = getConversationsCollection()

    // Get unread messages for this user in this conversation
    const q = query(
      messagesCollection,
      where("conversationId", "==", conversationId),
      where("receiverId", "==", userId),
      where("read", "==", false),
    )

    const querySnapshot = await getDocs(q)
    const batch = writeBatch(db!)

    // Mark all unread messages as read
    querySnapshot.forEach((doc) => {
      batch.update(doc.ref, { read: true })
    })

    // Reset unread count for this user in the conversation
    const conversationRef = doc(conversationsCollection, conversationId)
    batch.update(conversationRef, {
      [`unreadCount.${userId}`]: 0,
    })

    await batch.commit()
  } catch (error) {
    console.error("Error marking messages as read:", error)
    throw error
  }
}

// Get conversation with profile info
export const getConversationWithProfile = async (
  conversation: Conversation,
  currentUserId: string,
): Promise<{
  conversation: Conversation
  otherUserProfile?: { id: string; name: string; photos: string[] }
}> => {
  const otherUserId = conversation.participants.find((id) => id !== currentUserId)

  if (!otherUserId) {
    return { conversation }
  }

  try {
    const profile = await getProfileFromFirestore(otherUserId)
    if (profile) {
      return {
        conversation,
        otherUserProfile: {
          id: profile.id,
          name: profile.name || profile.displayName || "",
          photos: profile.photos || [],
        },
      }
    }
  } catch (error) {
    console.error("Error fetching profile for conversation:", error)
  }

  return { conversation }
}
