import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  query,
  where,
  updateDoc,
  deleteDoc,
  serverTimestamp,
  type QueryConstraint,
} from "firebase/firestore"
import { db } from "../firebase"
import type { Profile } from "@/types/profile"
import { createSlug } from "@/lib/utils"
import { getCollectionNames } from "@/lib/environment"

// Collection references - handle case where db is null and use dynamic collection names
const getProfilesCollection = () => {
  if (!db) throw new Error("Firestore is not initialized")
  const collections = getCollectionNames()
  return collection(db, collections.profiles)
}

// Check if a slug is already in use
export const isSlugAvailable = async (slug: string): Promise<boolean> => {
  try {
    const profilesCollection = getProfilesCollection()
    const q = query(profilesCollection, where("slug", "==", slug))
    const querySnapshot = await getDocs(q)
    return querySnapshot.empty
  } catch (error) {
    console.error("Error checking slug availability:", error)
    throw error
  }
}

// Generate a unique slug based on the user's name
export const generateUniqueSlug = async (name: string): Promise<string> => {
  let slug = createSlug(name)
  let isAvailable = await isSlugAvailable(slug)
  let counter = 1

  // If the slug is already taken, append a number until we find an available one
  while (!isAvailable) {
    slug = `${createSlug(name)}-${counter}`
    isAvailable = await isSlugAvailable(slug)
    counter++
  }

  return slug
}

// Create a new profile
export const createProfileInFirestore = async (profile: Omit<Profile, "id">, userId: string): Promise<Profile> => {
  try {
    const profilesCollection = getProfilesCollection()

    // Generate a unique slug based on the user's name
    const slug = await generateUniqueSlug(profile.name)

    const profileWithTimestamp = {
      ...profile,
      displayName: profile.name, // Add displayName field for Firebase rules
      userId,
      slug, // Store the slug in the document
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    }

    console.log("Creating profile with slug:", slug, "for event:", profile.event)

    // Use the slug as the document ID
    const profileRef = doc(profilesCollection, slug)

    // Use a more efficient set operation
    await setDoc(profileRef, profileWithTimestamp)

    console.log("Profile created successfully with ID:", profileRef.id)

    return {
      id: profileRef.id, // This will be the slug
      ...profile,
      slug,
    }
  } catch (error) {
    console.error("Error creating profile:", error)
    throw error
  }
}

// Get a profile by ID (which is now the slug)
export const getProfileFromFirestore = async (id: string): Promise<Profile | null> => {
  try {
    const profilesCollection = getProfilesCollection()
    const profileDoc = await getDoc(doc(profilesCollection, id))

    if (profileDoc.exists()) {
      const data = profileDoc.data()
      return {
        id: profileDoc.id, // This is the slug
        name: data.name || data.displayName || "", // Support both name and displayName
        slug: data.slug || profileDoc.id, // Ensure slug is available
        categoryTags: data.categoryTags || [],
        bio: data.bio || "",
        bioTag: data.bioTag || "",
        whyHere: data.whyHere || "",
        whyHereTag: data.whyHereTag || "",
        lookingFor: data.lookingFor || "",
        lookingForTag: data.lookingForTag || "",
        politicalBeliefs: data.politicalBeliefs || "",
        politicalBeliefsTag: data.politicalBeliefsTag || "",
        controversialBelief: data.controversialBelief || "",
        controversialBeliefTag: data.controversialBeliefTag || "",
        contactInfo: data.contactInfo || {},
        photos: data.photos || [],
        externalLinks: data.externalLinks || [],
        event: data.event || "freedomfest", // Default to freedomfest for existing profiles
        ...data,
      } as Profile
    }

    return null
  } catch (error) {
    console.error("Error getting profile:", error)
    throw error
  }
}

// Get a profile by user ID
export const getProfileByUserId = async (userId: string): Promise<Profile | null> => {
  try {
    const profilesCollection = getProfilesCollection()
    const q = query(profilesCollection, where("userId", "==", userId))
    const querySnapshot = await getDocs(q)

    if (querySnapshot.empty) {
      return null
    }

    const doc = querySnapshot.docs[0]
    const data = doc.data()
    return {
      id: doc.id, // This is the slug
      slug: data.slug || doc.id, // Ensure slug is available
      name: data.name || data.displayName || "", // Support both name and displayName
      categoryTags: data.categoryTags || [],
      bio: data.bio || "",
      bioTag: data.bioTag || "",
      whyHere: data.whyHere || "",
      whyHereTag: data.whyHereTag || "",
      lookingFor: data.lookingFor || "",
      lookingForTag: data.lookingForTag || "",
      politicalBeliefs: data.politicalBeliefs || "",
      politicalBeliefsTag: data.politicalBeliefsTag || "",
      controversialBelief: data.controversialBelief || "",
      controversialBeliefTag: data.controversialBeliefTag || "",
      contactInfo: data.contactInfo || {},
      photos: data.photos || [],
      externalLinks: data.externalLinks || [],
      event: data.event || "freedomfest", // Default to freedomfest for existing profiles
      ...data,
    } as Profile
  } catch (error) {
    console.error("Error getting profile by userId:", error)
    throw error
  }
}

// Get all profiles
export const getProfilesFromFirestore = async (constraints: QueryConstraint[] = []): Promise<Profile[]> => {
  try {
    const profilesCollection = getProfilesCollection()
    const profilesQuery = constraints.length > 0 ? query(profilesCollection, ...constraints) : profilesCollection

    const querySnapshot = await getDocs(profilesQuery)
    const profiles: Profile[] = []

    querySnapshot.forEach((doc) => {
      const data = doc.data()
      profiles.push({
        id: doc.id, // This is the slug
        slug: data.slug || doc.id, // Ensure slug is available
        name: data.name || data.displayName || "", // Support both name and displayName
        categoryTags: data.categoryTags || [],
        bio: data.bio || "",
        bioTag: data.bioTag || "",
        whyHere: data.whyHere || "",
        whyHereTag: data.whyHereTag || "",
        lookingFor: data.lookingFor || "",
        lookingForTag: data.lookingForTag || "",
        politicalBeliefs: data.politicalBeliefs || "",
        politicalBeliefsTag: data.politicalBeliefsTag || "",
        controversialBelief: data.controversialBelief || "",
        controversialBeliefTag: data.controversialBeliefTag || "",
        contactInfo: data.contactInfo || {},
        photos: data.photos || [],
        externalLinks: data.externalLinks || [],
        event: data.event || "freedomfest", // Default to freedomfest for existing profiles
        ...data,
      } as Profile)
    })

    return profiles
  } catch (error) {
    console.error("Error getting profiles:", error)
    throw error
  }
}

// Get profiles by user ID
export const getProfilesByUserId = async (userId: string): Promise<Profile[]> => {
  try {
    return getProfilesFromFirestore([where("userId", "==", userId)])
  } catch (error) {
    console.error("Error getting profiles by user ID:", error)
    throw error
  }
}

// Update a profile
export const updateProfileInFirestore = async (id: string, data: Partial<Profile>): Promise<void> => {
  try {
    const profilesCollection = getProfilesCollection()
    const profileRef = doc(profilesCollection, id)

    // If the name is being updated, we need to check if we should update the slug
    if (data.name) {
      const currentProfile = await getProfileFromFirestore(id)

      // Only update the slug if the name has changed significantly
      if (currentProfile && createSlug(currentProfile.name) !== createSlug(data.name)) {
        // Generate a new unique slug
        const newSlug = await generateUniqueSlug(data.name)

        // If the slug has changed, we need to create a new document and delete the old one
        if (newSlug !== id) {
          // Get the full current profile
          const fullProfile = await getProfileFromFirestore(id)
          if (fullProfile) {
            // Create a new profile with the updated data and new slug
            const updatedProfile = {
              ...fullProfile,
              ...data,
              displayName: data.name, // Update displayName when name changes
              slug: newSlug,
              updatedAt: serverTimestamp(),
            }

            // Create the new document with the new slug as the ID
            const newProfileRef = doc(profilesCollection, newSlug)
            await setDoc(newProfileRef, updatedProfile)

            // Delete the old document
            await deleteDoc(profileRef)

            // Return early since we've already updated the profile
            return
          }
        }
      }
    }

    // If we didn't need to change the slug, just update the existing document
    const updateData = {
      ...data,
      updatedAt: serverTimestamp(),
    }

    // Add displayName if name is being updated
    if (data.name) {
      updateData.displayName = data.name
    }

    await updateDoc(profileRef, updateData)
  } catch (error) {
    console.error("Error updating profile:", error)
    throw error
  }
}

// Delete a profile
export const deleteProfileFromFirestore = async (id: string): Promise<void> => {
  try {
    const profilesCollection = getProfilesCollection()
    await deleteDoc(doc(profilesCollection, id))
  } catch (error) {
    console.error("Error deleting profile:", error)
    throw error
  }
}

// Filter profiles by tags
export const getProfilesByTags = async (tags: string[]): Promise<Profile[]> => {
  if (!tags.length) return getProfilesFromFirestore()

  try {
    // Firestore doesn't support direct array contains any with multiple values
    // For simplicity, we'll fetch all and filter client-side
    const profiles = await getProfilesFromFirestore()
    return profiles.filter((profile) => tags.some((tag) => profile.categoryTags.includes(tag)))
  } catch (error) {
    console.error("Error getting profiles by tags:", error)
    throw error
  }
}

// Search profiles
export const searchProfiles = async (searchTerm: string): Promise<Profile[]> => {
  try {
    // Firestore doesn't support full text search natively
    // For simplicity, we'll fetch all and filter client-side
    const profiles = await getProfilesFromFirestore()
    const lowerSearchTerm = searchTerm.toLowerCase()

    return profiles.filter(
      (profile) =>
        profile.name.toLowerCase().includes(lowerSearchTerm) ||
        profile.bio.toLowerCase().includes(lowerSearchTerm) ||
        (profile.bioTag && profile.bioTag.toLowerCase().includes(lowerSearchTerm)) ||
        (profile.whyHereTag && profile.whyHereTag.toLowerCase().includes(lowerSearchTerm)) ||
        (profile.lookingForTag && profile.lookingForTag.toLowerCase().includes(lowerSearchTerm)),
    )
  } catch (error) {
    console.error("Error searching profiles:", error)
    throw error
  }
}
