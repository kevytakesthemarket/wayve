import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  sendPasswordResetEmail,
  updateProfile,
  onAuthStateChanged,
  type User,
  type UserCredential,
  GoogleAuthProvider,
  signInWithPopup,
} from "firebase/auth"
import { auth } from "../firebase"

// Sign up with email and password
export const signUp = async (email: string, password: string, displayName: string): Promise<UserCredential> => {
  try {
    if (!auth) throw new Error("Auth is not initialized")

    const userCredential = await createUserWithEmailAndPassword(auth, email, password)
    // Update the user's profile with display name
    if (userCredential.user) {
      await updateProfile(userCredential.user, {
        displayName: displayName,
      })
    }
    return userCredential
  } catch (error) {
    console.error("Error signing up:", error)
    throw error
  }
}

// Sign in with email and password
export const signIn = async (email: string, password: string): Promise<UserCredential> => {
  try {
    if (!auth) throw new Error("Auth is not initialized")
    return await signInWithEmailAndPassword(auth, email, password)
  } catch (error) {
    console.error("Error signing in:", error)
    throw error
  }
}

// Sign out
export const signOut = async (): Promise<void> => {
  try {
    if (!auth) throw new Error("Auth is not initialized")
    await firebaseSignOut(auth)
  } catch (error) {
    console.error("Error signing out:", error)
    throw error
  }
}

// Reset password
export const resetPassword = async (email: string): Promise<void> => {
  try {
    if (!auth) throw new Error("Auth is not initialized")
    await sendPasswordResetEmail(auth, email)
  } catch (error) {
    console.error("Error resetting password:", error)
    throw error
  }
}

// Sign in with Google
export const signInWithGoogle = async (): Promise<UserCredential> => {
  try {
    if (!auth) throw new Error("Auth is not initialized")
    const provider = new GoogleAuthProvider()
    return await signInWithPopup(auth, provider)
  } catch (error) {
    console.error("Error signing in with Google:", error)
    throw error
  }
}

// Get current user
export const getCurrentUser = (): User | null => {
  if (!auth) return null
  return auth.currentUser
}

// Listen to auth state changes
export const onAuthChange = (callback: (user: User | null) => void) => {
  if (!auth) {
    console.warn("Auth is not initialized")
    callback(null)
    return () => {}
  }

  try {
    return onAuthStateChanged(auth, callback)
  } catch (error) {
    console.error("Error setting up auth state listener:", error)
    callback(null)
    return () => {}
  }
}
