import { ref, uploadBytesResumable, getDownloadURL, deleteObject } from "firebase/storage"
import { storage } from "../firebase"

// Maximum number of retries
const MAX_RETRIES = 3

/**
 * Ensures a Firebase Storage URL is properly formatted for direct access
 * @param url The Firebase Storage URL
 * @returns A properly formatted URL with the alt=media parameter
 */
export const formatStorageUrl = (url: string): string => {
  if (!url) return url

  // Already has alt=media parameter
  if (url.includes("alt=media")) return url

  // Remove token if present (tokens might expire)
  let cleanUrl = url
  if (url.includes("token=")) {
    cleanUrl = url.split("&token=")[0]
  }

  // Add alt=media parameter
  return cleanUrl.includes("?") ? `${cleanUrl}&alt=media` : `${cleanUrl}?alt=media`
}

/**
 * Delete an image from Firebase Storage
 * @param storagePath The path to the file in Firebase Storage
 * @returns Promise that resolves when the file is deleted
 */
export const deleteImage = async (storagePath: string): Promise<void> => {
  if (!storagePath) {
    throw new Error("Storage path is required to delete an image")
  }

  try {
    console.log(`Deleting file from storage: ${storagePath}`)

    // Create a reference to the file
    const fileRef = ref(storage, storagePath)

    // Delete the file
    await deleteObject(fileRef)

    console.log(`Successfully deleted file: ${storagePath}`)
  } catch (error) {
    console.error(`Error deleting file: ${storagePath}`, error)
    throw error
  }
}

/**
 * Upload a single image file to Firebase Storage with progress tracking and retries
 * @param file The file to upload
 * @param userId The user ID to associate with the file
 * @param onProgress Optional callback for progress updates
 * @returns Promise with the download URL
 */
export const uploadImage = async (
  file: File,
  userId: string,
  onProgress?: (progress: number) => void,
): Promise<string> => {
  // Validate file size (max 10MB)
  const maxSize = 10 * 1024 * 1024 // 10MB
  if (file.size > maxSize) {
    throw new Error(`File size exceeds 10MB limit: ${(file.size / (1024 * 1024)).toFixed(2)}MB`)
  }

  // Implement retry logic
  let lastError: Error | null = null
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    if (attempt > 0) {
      console.log(`Retry attempt ${attempt} of ${MAX_RETRIES}...`)
      // Wait before retrying (exponential backoff)
      await new Promise((resolve) => setTimeout(resolve, 1000 * Math.pow(2, attempt - 1)))
    }

    try {
      // Create a unique filename
      const timestamp = Date.now()
      const randomId = Math.random().toString(36).substring(2, 10)
      const safeFileName = file.name.replace(/[^a-zA-Z0-9.]/g, "_").substring(0, 30)
      const filename = `${timestamp}_${randomId}_${safeFileName}`

      // Set the storage path
      const storagePath = `profiles/${userId}/photos/${filename}`
      console.log(`Uploading file to: ${storagePath}`)

      // Create a reference to the storage location
      const storageRef = ref(storage, storagePath)

      // Create the upload task with resumable upload
      const uploadTask = uploadBytesResumable(storageRef, file)

      // Return a promise that resolves when the upload is complete
      return await new Promise((resolve, reject) => {
        // Monitor upload progress
        uploadTask.on(
          "state_changed",
          (snapshot) => {
            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100
            console.log(`Upload progress: ${progress.toFixed(2)}%`)
            if (onProgress) {
              onProgress(progress)
            }
          },
          (error) => {
            console.error("Upload error:", error)
            reject(error)
          },
          async () => {
            try {
              // Get the download URL
              const downloadURL = await getDownloadURL(uploadTask.snapshot.ref)
              // Format the URL for direct access
              const formattedURL = formatStorageUrl(downloadURL)
              console.log("Upload completed. Download URL:", formattedURL)
              resolve(formattedURL)
            } catch (error) {
              console.error("Error getting download URL:", error)
              reject(new Error("Upload completed but failed to get download URL"))
            }
          },
        )
      })
    } catch (error) {
      console.error(`Upload attempt ${attempt + 1} failed:`, error)
      lastError = error instanceof Error ? error : new Error(String(error))
    }
  }

  // If we've exhausted all retries
  throw lastError || new Error("Upload failed after multiple attempts")
}

/**
 * Upload multiple image files to Firebase Storage
 * @param files Array of files to upload
 * @param userId The user ID to associate with the files
 * @param onProgress Optional callback for progress updates
 * @returns Promise with array of download URLs
 */
export const uploadImages = async (
  files: File[],
  userId: string,
  onProgress?: (overallProgress: number) => void,
): Promise<string[]> => {
  if (!files.length) {
    return []
  }

  console.log(`Uploading ${files.length} files for user ${userId}`)

  // Upload files sequentially to avoid overwhelming the connection
  const urls: string[] = []
  let totalProgress = 0

  for (let i = 0; i < files.length; i++) {
    const file = files[i]
    const fileProgress = (progress: number) => {
      // Calculate overall progress
      const fileWeight = 1 / files.length
      const weightedProgress = progress * fileWeight
      const fileContribution = weightedProgress / 100

      // Update total progress
      const previousFilesContribution = (i / files.length) * 100
      const currentProgress = previousFilesContribution + fileContribution * 100

      if (onProgress) {
        onProgress(currentProgress)
      }
    }

    // Upload the file with progress tracking
    const url = await uploadImage(file, userId, fileProgress)
    urls.push(url)

    // Update progress after file completes
    totalProgress = ((i + 1) / files.length) * 100
    if (onProgress) {
      onProgress(totalProgress)
    }
  }

  console.log(`Successfully uploaded ${urls.length} files`)
  return urls
}
