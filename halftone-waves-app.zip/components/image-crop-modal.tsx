"use client"

import type React from "react"
import { useState, useRef, useEffect, useCallback } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { X, RotateCcw, Loader2, Move } from "lucide-react"
import { uploadProfileImages } from "@/lib/profile-service"
import { useAuth } from "@/contexts/auth-context"
import { Progress } from "@/components/ui/progress"

interface ImageCropModalProps {
  isOpen: boolean
  onClose: () => void
  imageUrl: string
  onSave: (imageUrl: string) => void
  photoIndex: number
  originalFile: File
}

export function ImageCropModal({ isOpen, onClose, imageUrl, onSave, photoIndex, originalFile }: ImageCropModalProps) {
  const [error, setError] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [imageLoaded, setImageLoaded] = useState(false)
  const [fullResImageUrl, setFullResImageUrl] = useState<string | null>(null)

  // Image manipulation state
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const imageRef = useRef<HTMLImageElement>(null)
  const [scale, setScale] = useState(1)
  const [imagePosition, setImagePosition] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })

  const { user } = useAuth()

  // Fixed crop area dimensions (3:4 ratio)
  const CROP_WIDTH = 240
  const CROP_HEIGHT = 320
  const CANVAS_WIDTH = 300
  const CANVAS_HEIGHT = 400

  // Reset state when modal opens
  useEffect(() => {
    if (isOpen) {
      setError(null)
      setImageLoaded(false)
      setUploadProgress(0)
      setScale(1)
      setImagePosition({ x: 0, y: 0 })

      // Create full resolution image URL from the original file
      if (originalFile) {
        const fullResUrl = URL.createObjectURL(originalFile)
        setFullResImageUrl(fullResUrl)

        // Cleanup URL when modal closes
        return () => {
          if (fullResUrl) {
            URL.revokeObjectURL(fullResUrl)
          }
        }
      }
    }
  }, [isOpen, originalFile])

  // Canvas drawing function
  const drawCanvas = useCallback(() => {
    const canvas = canvasRef.current
    const image = imageRef.current
    if (!canvas || !image || !imageLoaded) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    canvas.width = CANVAS_WIDTH
    canvas.height = CANVAS_HEIGHT

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Calculate image dimensions to fit canvas while maintaining aspect ratio
    const imageAspect = image.naturalWidth / image.naturalHeight
    const canvasAspect = canvas.width / canvas.height

    let baseWidth, baseHeight
    if (imageAspect > canvasAspect) {
      baseWidth = canvas.width
      baseHeight = canvas.width / imageAspect
    } else {
      baseHeight = canvas.height
      baseWidth = canvas.height * imageAspect
    }

    // Apply scale
    const drawWidth = baseWidth * scale
    const drawHeight = baseHeight * scale

    // Calculate image position (centered by default, then offset by user position)
    const centerX = (canvas.width - drawWidth) / 2
    const centerY = (canvas.height - drawHeight) / 2
    const imageX = centerX + imagePosition.x
    const imageY = centerY + imagePosition.y

    // Draw image at full opacity - no darkening
    ctx.drawImage(image, imageX, imageY, drawWidth, drawHeight)

    // Calculate fixed crop area (centered)
    const cropX = (canvas.width - CROP_WIDTH) / 2
    const cropY = (canvas.height - CROP_HEIGHT) / 2

    // Draw crop border - make it prominent and clear
    ctx.strokeStyle = "#a855f7"
    ctx.lineWidth = 3
    ctx.strokeRect(cropX, cropY, CROP_WIDTH, CROP_HEIGHT)

    // Add a subtle outer glow to the crop border for better visibility
    ctx.shadowColor = "#a855f7"
    ctx.shadowBlur = 8
    ctx.strokeRect(cropX, cropY, CROP_WIDTH, CROP_HEIGHT)
    ctx.shadowBlur = 0

    // Draw corner indicators - more prominent
    const cornerSize = 24
    const cornerThickness = 4
    ctx.strokeStyle = "#ffffff"
    ctx.lineWidth = cornerThickness
    ctx.shadowColor = "#000000"
    ctx.shadowBlur = 4

    const corners = [
      { x: cropX, y: cropY }, // top-left
      { x: cropX + CROP_WIDTH, y: cropY }, // top-right
      { x: cropX, y: cropY + CROP_HEIGHT }, // bottom-left
      { x: cropX + CROP_WIDTH, y: cropY + CROP_HEIGHT }, // bottom-right
    ]

    corners.forEach((corner) => {
      // Draw L-shaped corner indicators
      ctx.beginPath()
      if (corner.x === cropX) {
        // Left side corners
        ctx.moveTo(corner.x, corner.y + (corner.y === cropY ? cornerSize : -cornerSize))
        ctx.lineTo(corner.x, corner.y)
        ctx.lineTo(corner.x + cornerSize, corner.y)
      } else {
        // Right side corners
        ctx.moveTo(corner.x, corner.y + (corner.y === cropY ? cornerSize : -cornerSize))
        ctx.lineTo(corner.x, corner.y)
        ctx.lineTo(corner.x - cornerSize, corner.y)
      }
      ctx.stroke()
    })

    ctx.shadowBlur = 0

    // Draw grid lines for better composition guidance
    ctx.strokeStyle = "rgba(255, 255, 255, 0.6)"
    ctx.lineWidth = 1
    ctx.shadowColor = "#000000"
    ctx.shadowBlur = 2

    // Rule of thirds - vertical lines
    for (let i = 1; i < 3; i++) {
      const x = cropX + (CROP_WIDTH / 3) * i
      ctx.beginPath()
      ctx.moveTo(x, cropY)
      ctx.lineTo(x, cropY + CROP_HEIGHT)
      ctx.stroke()
    }

    // Rule of thirds - horizontal lines
    for (let i = 1; i < 4; i++) {
      const y = cropY + (CROP_HEIGHT / 4) * i
      ctx.beginPath()
      ctx.moveTo(cropX, y)
      ctx.lineTo(cropX + CROP_WIDTH, y)
      ctx.stroke()
    }

    ctx.shadowBlur = 0

    // Add a subtle background pattern outside the crop area to show what will be cropped out
    ctx.fillStyle = "rgba(0, 0, 0, 0.1)"

    // Top area
    ctx.fillRect(0, 0, canvas.width, cropY)
    // Bottom area
    ctx.fillRect(0, cropY + CROP_HEIGHT, canvas.width, canvas.height - (cropY + CROP_HEIGHT))
    // Left area
    ctx.fillRect(0, cropY, cropX, CROP_HEIGHT)
    // Right area
    ctx.fillRect(cropX + CROP_WIDTH, cropY, canvas.width - (cropX + CROP_WIDTH), CROP_HEIGHT)
  }, [imageLoaded, scale, imagePosition])

  useEffect(() => {
    drawCanvas()
  }, [drawCanvas])

  // Mouse event handlers for dragging image
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true)
    setDragStart({
      x: e.clientX - imagePosition.x,
      y: e.clientY - imagePosition.y,
    })
  }

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging) return

    const newX = e.clientX - dragStart.x
    const newY = e.clientY - dragStart.y

    setImagePosition({ x: newX, y: newY })
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const handleReset = () => {
    setScale(1)
    setImagePosition({ x: 0, y: 0 })
  }

  const cropAndSaveImage = async () => {
    if (!user) {
      setError("You must be signed in to save changes")
      return
    }

    const canvas = canvasRef.current
    const image = imageRef.current
    if (!canvas || !image || !imageLoaded) {
      setError("Image not loaded properly")
      return
    }

    setIsProcessing(true)
    setError(null)
    setUploadProgress(0)

    try {
      console.log("Starting crop and upload process")

      // Create a new canvas for the cropped image
      const cropCanvas = document.createElement("canvas")
      const cropCtx = cropCanvas.getContext("2d")
      if (!cropCtx) {
        throw new Error("Could not get crop canvas context")
      }

      setUploadProgress(25)

      // Calculate the actual image dimensions and position on canvas
      const imageAspect = image.naturalWidth / image.naturalHeight
      const canvasAspect = CANVAS_WIDTH / CANVAS_HEIGHT

      let baseWidth, baseHeight
      if (imageAspect > canvasAspect) {
        baseWidth = CANVAS_WIDTH
        baseHeight = CANVAS_WIDTH / imageAspect
      } else {
        baseHeight = CANVAS_HEIGHT
        baseWidth = CANVAS_HEIGHT * imageAspect
      }

      const drawWidth = baseWidth * scale
      const drawHeight = baseHeight * scale

      const centerX = (CANVAS_WIDTH - drawWidth) / 2
      const centerY = (CANVAS_HEIGHT - drawHeight) / 2
      const imageX = centerX + imagePosition.x
      const imageY = centerY + imagePosition.y

      // Fixed crop area position
      const cropX = (CANVAS_WIDTH - CROP_WIDTH) / 2
      const cropY = (CANVAS_HEIGHT - CROP_HEIGHT) / 2

      // Calculate crop area relative to the actual image
      const scaleX = image.naturalWidth / drawWidth
      const scaleY = image.naturalHeight / drawHeight

      const sourceCropX = Math.max(0, (cropX - imageX) * scaleX)
      const sourceCropY = Math.max(0, (cropY - imageY) * scaleY)
      const sourceCropWidth = Math.min(CROP_WIDTH * scaleX, image.naturalWidth - sourceCropX)
      const sourceCropHeight = Math.min(CROP_HEIGHT * scaleY, image.naturalHeight - sourceCropY)

      console.log("Crop calculations:", {
        imageSize: { width: image.naturalWidth, height: image.naturalHeight },
        cropRect: { x: sourceCropX, y: sourceCropY, width: sourceCropWidth, height: sourceCropHeight },
        scale,
      })

      setUploadProgress(50)

      // Set crop canvas size to maintain 3:4 ratio at high resolution
      const outputWidth = 600
      const outputHeight = 800

      cropCanvas.width = outputWidth
      cropCanvas.height = outputHeight

      // Draw cropped image
      cropCtx.drawImage(
        image,
        sourceCropX,
        sourceCropY,
        sourceCropWidth,
        sourceCropHeight,
        0,
        0,
        outputWidth,
        outputHeight,
      )

      setUploadProgress(75)

      // Convert to blob
      const blob = await new Promise<Blob>((resolve, reject) => {
        cropCanvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(blob)
            } else {
              reject(new Error("Failed to create blob from canvas"))
            }
          },
          "image/jpeg",
          0.9,
        )
      })

      // Create a file from the blob
      const timestamp = Date.now()
      const originalName = originalFile.name.replace(/\.[^/.]+$/, "") || "photo"
      const croppedFile = new File([blob], `${originalName}_cropped_${timestamp}.jpg`, {
        type: "image/jpeg",
      })

      console.log("Created cropped file:", { name: croppedFile.name, size: blob.size })

      // Upload the cropped image to Firebase
      const handleProgress = (progress: number) => {
        setUploadProgress(75 + progress * 0.25) // Scale to 75-100%
      }

      const uploadedUrls = await uploadProfileImages([croppedFile], user.uid, handleProgress)

      if (uploadedUrls && uploadedUrls.length > 0) {
        console.log("Successfully uploaded cropped image:", uploadedUrls[0])
        onSave(uploadedUrls[0])
        onClose()
      } else {
        throw new Error("Failed to upload cropped image")
      }
    } catch (error) {
      console.error("Error cropping and uploading image:", error)
      let errorMessage = "Unknown error occurred"

      if (error instanceof Error) {
        errorMessage = error.message
      } else if (typeof error === "object" && error !== null) {
        errorMessage = "Failed to process image. Please try again."
      }

      setError(`Failed to save cropped image: ${errorMessage}`)
    } finally {
      setIsProcessing(false)
      setUploadProgress(0)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-sm bg-zinc-900 border-zinc-800 max-h-[90vh] overflow-y-auto">
        <div className="py-4">
          <DialogHeader className="pb-4">
            <DialogTitle className="text-white text-center">Crop Your Photo</DialogTitle>
            <p className="text-zinc-400 text-sm text-center">
              Position your image so the best part shows in the highlighted area
            </p>
          </DialogHeader>

          {error && (
            <div className="bg-red-900/20 border border-red-800 text-red-300 px-3 py-2 rounded text-sm mb-4">
              {error}
            </div>
          )}

          <div className="space-y-6">
            {/* Hidden image for loading - using full resolution */}
            <img
              ref={imageRef}
              src={fullResImageUrl || imageUrl || "/placeholder.svg"}
              alt="Source"
              className="hidden"
              onLoad={() => {
                console.log("Full resolution image loaded successfully for cropping")
                setImageLoaded(true)
              }}
              onError={(e) => {
                console.error("Image failed to load for cropping:", e)
                setError("Failed to load image for cropping")
              }}
              crossOrigin="anonymous"
            />

            {/* Canvas for cropping */}
            <div className="flex justify-center px-4">
              {!imageLoaded ? (
                <div className="w-full max-w-[300px] h-[400px] bg-black rounded-lg border-2 border-purple-500 flex items-center justify-center">
                  <div className="text-center text-zinc-400">
                    <Loader2 className="h-12 w-12 animate-spin mx-auto mb-2" />
                    <div className="text-sm">Loading full resolution image...</div>
                  </div>
                </div>
              ) : (
                <div className="relative">
                  <canvas
                    ref={canvasRef}
                    className="border-2 border-zinc-700 rounded-lg cursor-move touch-none bg-zinc-800"
                    onMouseDown={handleMouseDown}
                    onMouseMove={handleMouseMove}
                    onMouseUp={handleMouseUp}
                    onMouseLeave={handleMouseUp}
                    style={{ width: "300px", height: "400px" }}
                    onTouchStart={(e) => {
                      const touch = e.touches[0]
                      handleMouseDown({
                        clientX: touch.clientX,
                        clientY: touch.clientY,
                      } as React.MouseEvent<HTMLCanvasElement>)
                    }}
                    onTouchMove={(e) => {
                      const touch = e.touches[0]
                      handleMouseMove({
                        clientX: touch.clientX,
                        clientY: touch.clientY,
                      } as React.MouseEvent<HTMLCanvasElement>)
                    }}
                    onTouchEnd={() => handleMouseUp()}
                    onTouchCancel={() => handleMouseUp()}
                    touch-action="none"
                  />
                  <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 flex items-center text-zinc-400 text-xs">
                    <Move className="h-3 w-3 mr-1" />
                    Drag to reposition
                  </div>
                </div>
              )}
            </div>

            {/* Controls */}
            <div className="space-y-4 px-4">
              <div>
                <label className="text-sm text-zinc-300 mb-2 block">Zoom: {scale.toFixed(1)}x</label>
                <Slider
                  value={[scale]}
                  onValueChange={(value) => setScale(value[0])}
                  min={0.5}
                  max={3}
                  step={0.1}
                  className="w-full"
                  disabled={isProcessing || !imageLoaded}
                />
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={handleReset}
                className="w-full bg-zinc-800 border-zinc-700 text-zinc-300 hover:bg-zinc-700"
                disabled={isProcessing || !imageLoaded}
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                Reset Position & Zoom
              </Button>
            </div>

            {/* Progress bar */}
            {isProcessing && (
              <div className="space-y-2 px-4">
                <div className="flex justify-between text-xs text-purple-300">
                  <span>Processing and uploading...</span>
                  <span>{Math.round(uploadProgress)}%</span>
                </div>
                <Progress value={uploadProgress} className="h-1" />
              </div>
            )}

            {/* Action buttons */}
            <div className="flex gap-3 px-4 pt-2">
              <Button
                variant="outline"
                onClick={onClose}
                className="flex-1 bg-zinc-800 border-zinc-700 text-zinc-300 hover:bg-zinc-700"
                disabled={isProcessing}
              >
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
              <Button
                onClick={cropAndSaveImage}
                className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
                disabled={isProcessing || !imageLoaded}
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Apply Crop"
                )}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
