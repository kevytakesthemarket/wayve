"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { useRouter } from "next/navigation"
import type { Profile } from "@/types/profile"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronLeft, ChevronRight, Mail, MessageCircle, Twitter, X, LinkIcon } from "lucide-react"
import { cn } from "@/lib/utils"
import { motion, AnimatePresence } from "framer-motion"
import { ensureValidImageUrl } from "@/lib/utils"
import { MessageButton } from "@/components/message-button"
import { useAuth } from "@/contexts/auth-context"
import Image from "next/image"

interface ProfileCardProps {
  profile: Profile
  onExpand?: (id: string) => void
  expanded?: boolean
  className?: string
  disableNavigation?: boolean
  highlightedSection?: string | null
}

// Enhanced function to check if a URL is a Firebase Storage URL
const isFirebaseStorageUrl = (url: string): boolean => {
  return (
    url &&
    (url.includes("firebasestorage.googleapis.com") || url.includes("firebasestorage.app") || url.startsWith("gs://"))
  )
}

export function ProfileCard({
  profile,
  onExpand,
  expanded = false,
  className,
  disableNavigation = false,
  highlightedSection = null,
}: ProfileCardProps) {
  const router = useRouter()
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0)
  const [activeTag, setActiveTag] = useState<string | null>(highlightedSection)
  const tagsContainerRef = useRef<HTMLDivElement>(null)
  const [imageError, setImageError] = useState(false)
  const { user } = useAuth()

  const [touchStart, setTouchStart] = useState<number | null>(null)
  const [touchEnd, setTouchEnd] = useState<number | null>(null)
  const [isDragging, setIsDragging] = useState(false)

  // Ensure profile has all required arrays
  const safeProfile = {
    ...profile,
    photos: profile.photos || [],
    categoryTags: profile.categoryTags || [],
  }

  // Log the photo URLs when the component mounts
  useEffect(() => {
    console.log(`Profile Card - Photos for ${profile.name}:`, profile.photos)
  }, [profile.name, profile.photos])

  // Create fixed section tags for the main four pills we want to display
  const mainSectionTags = [
    { key: "bioTag", tag: profile.bioTag, content: profile.bio, title: "Who I Am", description: "Who I Am" },
    {
      key: "whyHereTag",
      tag: profile.whyHereTag,
      content: profile.whyHere,
      title: "Why I'm Here",
      description: "Why I'm Here",
    },
    {
      key: "lookingForTag",
      tag: profile.lookingForTag,
      content: profile.lookingFor,
      title: "What I'm Looking For",
      description: "Seeking",
    },
    {
      key: "politicalBeliefsTag",
      tag: profile.politicalBeliefsTag,
      content: profile.politicalBeliefs,
      title: "Beliefs",
      description: "Beliefs",
    },
  ]

  // Add any additional tags (like controversialBeliefTag)
  const additionalTags =
    profile.controversialBeliefTag && profile.controversialBelief
      ? [
          {
            key: "controversialBeliefTag",
            tag: profile.controversialBeliefTag,
            content: profile.controversialBelief,
            title: "Controversial Belief",
            description: "Controversial Belief",
          },
        ]
      : []

  // Combine all section tags
  const sectionTags = [...mainSectionTags, ...additionalTags]

  const nextPhoto = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (currentPhotoIndex < safeProfile.photos.length - 1) {
      setCurrentPhotoIndex(currentPhotoIndex + 1)
      setImageError(false)
    }
  }

  const prevPhoto = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (currentPhotoIndex > 0) {
      setCurrentPhotoIndex(currentPhotoIndex - 1)
      setImageError(false)
    }
  }

  // Touch handlers for mobile swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null)
    setTouchStart(e.targetTouches[0].clientX)
    setIsDragging(false)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!touchStart) return
    setTouchEnd(e.targetTouches[0].clientX)

    // Mark as dragging if moved more than 10px
    const distance = Math.abs(e.targetTouches[0].clientX - touchStart)
    if (distance > 10) {
      setIsDragging(true)
    }
  }

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return

    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > 50
    const isRightSwipe = distance < -50

    if (isLeftSwipe && currentPhotoIndex < safeProfile.photos.length - 1) {
      setCurrentPhotoIndex(currentPhotoIndex + 1)
      setImageError(false)
    }

    if (isRightSwipe && currentPhotoIndex > 0) {
      setCurrentPhotoIndex(currentPhotoIndex - 1)
      setImageError(false)
    }

    // Reset touch state
    setTouchStart(null)
    setTouchEnd(null)
    setIsDragging(false)
  }

  // Prevent card click when dragging
  const handleImageClick = (e: React.MouseEvent) => {
    if (isDragging) {
      e.stopPropagation()
    }
  }

  // Update the handleCardClick function to navigate to the user's profile
  const handleCardClick = () => {
    if (disableNavigation) {
      // If navigation is disabled, just use the expand functionality
      if (onExpand) {
        onExpand(profile.id)
      }
      return
    }

    // Navigate to the profile page using the slug or id
    router.push(`/${profile.slug || profile.id}`)
  }

  // Updated handleTagClick to navigate to profile page with section hash
  const handleTagClick = (e: React.MouseEvent, tag: string) => {
    e.stopPropagation()

    if (disableNavigation) {
      // If in expanded view or navigation disabled, just toggle the active tag
      setActiveTag(activeTag === tag ? null : tag)
      return
    }

    // If not expanded and navigation enabled, navigate to profile with section hash
    router.push(`/${profile.slug || profile.id}#${tag}`)
  }

  const closeTagDetail = (e: React.MouseEvent) => {
    e.stopPropagation()
    setActiveTag(null)
  }

  // Get the current photo URL with fallback and crop settings
  const currentPhotoUrl =
    safeProfile.photos && safeProfile.photos.length > 0
      ? ensureValidImageUrl(safeProfile.photos[currentPhotoIndex])
      : "/placeholder.svg"

  // Get crop settings for current photo
  const getCurrentPhotoCropSettings = () => {
    if (profile.cropSettings && profile.cropSettings.length > currentPhotoIndex) {
      const settings = profile.cropSettings[currentPhotoIndex]
      console.log(`Applied crop settings for photo ${currentPhotoIndex}:`, settings)
      return settings
    }
    return { cropX: 0, cropY: 0, cropScale: 1 }
  }

  const currentCropSettings = getCurrentPhotoCropSettings()

  // Handle image error
  const handleImageError = () => {
    console.error("Error loading image:", currentPhotoUrl)
    setImageError(true)
  }

  // Category tag color mapping
  const getCategoryTagColor = (tag: string) => {
    const politicalTags = [
      "Libertarian",
      "Conservative",
      "Republican",
      "Democrat",
      "Ancap",
      "Minarchist",
      "Progressive",
      "Centrist",
      "Voluntaryist",
    ]
    const occupationTags = [
      "Entrepreneur",
      "Developer",
      "Investor",
      "Farmer",
      "Artist",
      "Scientist",
      "Writer",
      "Educator",
      "Student",
    ]
    const interestTags = [
      "Crypto",
      "AI",
      "Climate",
      "Space",
      "Biotech",
      "Philosophy",
      "Economics",
      "Privacy",
      "Community",
    ]
    const organizationTags = ["Students for Liberty"]

    if (organizationTags.includes(tag)) {
      return "bg-white/20 text-white border-white/30 font-medium"
    } else if (politicalTags.includes(tag)) {
      return "bg-purple-500/20 text-purple-300 border-purple-500/30"
    } else if (occupationTags.includes(tag)) {
      return "bg-blue-500/20 text-blue-300 border-blue-500/30"
    } else if (interestTags.includes(tag)) {
      return "bg-green-500/20 text-green-300 border-green-500/30"
    }
    return "bg-zinc-700/50 text-zinc-300 border-zinc-600/30"
  }

  // Create a direct image URL using fetch instead of img tag
  // Remove the existing useEffect for fetching images and the imageDataUrl state
  // Replace the image rendering code with a simpler approach that handles CORS issues

  // Remove these lines:
  // const [imageDataUrl, setImageDataUrl] = useState<string | null>(null)

  // Remove the entire useEffect that contains fetchImage

  // Replace the image rendering code in the return statement with this:

  return (
    <Card
      className={cn(
        "overflow-hidden rounded-3xl transition-all duration-300",
        "transform-gpu perspective-card",
        expanded ? "w-full max-w-md mx-auto" : "w-full max-w-md mx-auto",
        "card-skeuomorphic",
        "cursor-pointer",
        className,
      )}
      onClick={handleCardClick}
    >
      {/* Category tags bar above the image */}
      <div className="bg-black rounded-t-3xl">
        <div className="relative px-3 py-3">
          {/* Scrollable container with touch scrolling */}
          <div
            ref={tagsContainerRef}
            className="flex overflow-x-auto scrollbar-hide gap-1.5 px-2 py-0.5 scroll-smooth touch-pan-x"
            onClick={(e) => e.stopPropagation()}
            style={{
              WebkitOverflowScrolling: "touch",
              scrollbarWidth: "none",
              msOverflowStyle: "none",
            }}
          >
            {safeProfile.categoryTags && safeProfile.categoryTags.length > 0 ? (
              safeProfile.categoryTags.map((tag) => (
                <span
                  key={tag}
                  className={cn(
                    "px-2 py-0.5 text-xs rounded-full border whitespace-nowrap flex-shrink-0 flex items-center",
                    getCategoryTagColor(tag),
                  )}
                >
                  {tag === "Students for Liberty" && (
                    <Image
                      src="/images/sfl.png"
                      alt="Students for Liberty"
                      width={12}
                      height={12}
                      className="mr-1 rounded-full"
                    />
                  )}
                  {tag}
                </span>
              ))
            ) : (
              <span className="px-2 py-0.5 text-xs rounded-full border whitespace-nowrap flex-shrink-0 bg-zinc-700/50 text-zinc-300 border-zinc-600/30">
                No tags
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Image container without the overlaid tags */}
      <div
        className="relative aspect-[3/4] w-full overflow-hidden rounded-b-3xl card-photo-frame"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onClick={handleImageClick}
      >
        {imageError ? (
          <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-900 text-zinc-400">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="64"
              height="64"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mb-4"
            >
              <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"></path>
              <path d="m10 15 5-5"></path>
              <path d="m15 15-5-5"></path>
            </svg>
            <p className="text-sm">Image could not be loaded</p>
          </div>
        ) : (
          <img
            src={currentPhotoUrl || "/placeholder.svg"}
            alt={`${profile.name}'s photo`}
            className={cn(
              "w-full h-full object-cover transition-transform duration-200",
              isDragging ? "scale-[0.98]" : "",
            )}
            style={{
              transform: `translate(${currentCropSettings.cropX * 2}px, ${currentCropSettings.cropY * 2}px) scale(${currentCropSettings.cropScale})`,
              transformOrigin: "center",
            }}
            onError={() => {
              console.error(`Error loading image: ${currentPhotoUrl}`)
              setImageError(true)
            }}
          />
        )}

        {profile.photos && profile.photos.length > 1 && (
          <>
            <button
              onClick={prevPhoto}
              disabled={currentPhotoIndex === 0}
              className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/70 text-white rounded-full p-1 backdrop-blur-sm disabled:opacity-30 skeuomorphic-button"
              aria-label="Previous photo"
            >
              <ChevronLeft size={20} />
            </button>
            <button
              onClick={nextPhoto}
              disabled={currentPhotoIndex === profile.photos.length - 1}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/70 text-white rounded-full p-1 backdrop-blur-sm disabled:opacity-30 skeuomorphic-button"
              aria-label="Next photo"
            >
              <ChevronRight size={20} />
            </button>
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1">
              {profile.photos.map((_, index) => (
                <div
                  key={index}
                  className={`w-1.5 h-1.5 rounded-full ${
                    index === currentPhotoIndex ? "bg-white" : "bg-white/50"
                  } skeuomorphic-dot`}
                />
              ))}
            </div>
          </>
        )}
      </div>

      <CardContent className="p-6 text-center card-content-skeuomorphic">
        <h2 className="text-xl font-bold text-zinc-100 mb-2 embossed-text">{profile.name}</h2>

        {!expanded && (
          <div className="flex flex-wrap gap-2 justify-center mb-4">
            {sectionTags.slice(0, 4).map((item, index) => (
              <div key={item.key} className="relative">
                <button
                  onClick={(e) => handleTagClick(e, item.key)}
                  className={cn(
                    "px-3 py-1 text-xs rounded-full transition-all border border-purple-500 flex items-center",
                    activeTag === item.key
                      ? "bg-purple-500 text-white"
                      : "bg-zinc-800 text-purple-300 hover:bg-zinc-700",
                  )}
                >
                  <span className="text-purple-400 mr-1">✦</span>
                  <span className="whitespace-nowrap">{item.tag || `Tag ${index + 1}`}</span>
                  <span className="whitespace-nowrap text-white/80 ml-1">
                    — {item.description || `Description ${index + 1}`}
                  </span>
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Message button - show after section tags in non-expanded view */}
        {!expanded && profile.userId && (
          <div className="mb-4">
            <MessageButton userId={profile.userId} userName={profile.name} />
          </div>
        )}

        <AnimatePresence>
          {activeTag && !expanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="relative mb-4 overflow-hidden"
            >
              <div className="p-3 rounded-xl bg-zinc-800/80 text-left">
                <div className="flex justify-between items-center mb-1">
                  <h3 className="text-zinc-300 font-medium text-sm">
                    {sectionTags.find((t) => t.key === activeTag)?.title}
                  </h3>
                  <button onClick={closeTagDetail} className="text-zinc-400 hover:text-zinc-200">
                    <X size={14} />
                  </button>
                </div>
                <p className="text-zinc-400 text-sm">{sectionTags.find((t) => t.key === activeTag)?.content}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {expanded && (
          <div className="space-y-4 text-left text-sm">
            {sectionTags.map((item) => (
              <div
                key={item.key}
                id={item.key}
                className={cn(
                  "p-3 rounded-xl skeuomorphic-inset-panel transition-all duration-300",
                  highlightedSection === item.key ? "ring-2 ring-purple-500 bg-zinc-800" : "",
                )}
              >
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-zinc-300 font-medium embossed-text-subtle">{item.title}</h3>
                  <span className="px-2 py-0.5 text-xs rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    <span className="text-purple-400 mr-1">✦</span>
                    {item.tag}
                  </span>
                </div>
                <p className="text-zinc-400 whitespace-pre-line">{item.content}</p>
              </div>
            ))}

            {profile.contactInfo && Object.values(profile.contactInfo).some(Boolean) && (
              <div className="p-3 rounded-xl skeuomorphic-inset-panel">
                <h3 className="text-zinc-300 font-medium embossed-text-subtle">Contact</h3>
                <div className="flex flex-wrap gap-3 mt-1">
                  {profile.contactInfo.telegram && (
                    <div className="flex items-center text-zinc-300 skeuomorphic-button-pill">
                      <MessageCircle size={16} className="mr-1" />
                      <span>{profile.contactInfo.telegram}</span>
                    </div>
                  )}
                  {profile.contactInfo.twitter && (
                    <div className="flex items-center text-zinc-300 skeuomorphic-button-pill">
                      <Twitter size={16} className="mr-1" />
                      <span>{profile.contactInfo.twitter}</span>
                    </div>
                  )}
                  {profile.contactInfo.email && (
                    <div className="flex items-center text-zinc-300 skeuomorphic-button-pill">
                      <Mail size={16} className="mr-1" />
                      <span>{profile.contactInfo.email}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {profile.externalLinks && profile.externalLinks.length > 0 && (
              <div className="p-3 rounded-xl skeuomorphic-inset-panel">
                <h3 className="text-zinc-300 font-medium embossed-text-subtle mb-2">Links</h3>
                <div className="space-y-2">
                  {profile.externalLinks.map((link, index) => (
                    <a
                      key={index}
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block p-2 bg-zinc-800/50 rounded-lg hover:bg-zinc-800 transition-colors"
                    >
                      <div className="flex items-center">
                        <LinkIcon size={14} className="text-purple-400 mr-2 flex-shrink-0" />
                        <span className="text-purple-300 font-medium text-sm">{link.title || link.url}</span>
                      </div>
                      {link.description && <p className="text-zinc-400 text-xs mt-1 ml-6">{link.description}</p>}
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {!expanded && !activeTag && (
          <div className="mt-2">
            <div
              className="relative inline-block px-4 py-2 rounded-full text-zinc-300 text-sm font-medium tracking-wide uppercase animate-pulse"
              style={{
                background: "linear-gradient(145deg, #27272a, #18181b)",
                boxShadow: `
                  0 0 15px rgba(168, 85, 247, 0.7), 
                  0 0 30px rgba(168, 85, 247, 0.5),
                  0 0 45px rgba(168, 85, 247, 0.3),
                  inset 0 1px 0 rgba(255, 255, 255, 0.05),
                  inset 0 -1px 0 rgba(0, 0, 0, 0.4),
                  0 2px 4px rgba(0, 0, 0, 0.5),
                  0 1px 2px rgba(0, 0, 0, 0.7)
                `,
                border: "1px solid rgba(39, 39, 42, 0.8)",
              }}
            >
              view full profile
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
