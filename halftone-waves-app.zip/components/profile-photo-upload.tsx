"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { X, Loader2, AlertCircle, Info, Plus, Camera, Trash2 } from "lucide-react"
import { deleteProfileImage, updateProfile } from "@/lib/profile-service"
import { useAuth } from "@/contexts/auth-context"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { cn } from "@/lib/utils"
import { compressImages } from "@/lib/image-utils"
import { ensureValidImageUrl, extractStoragePathFromUrl } from "@/lib/utils"
import { motion } from "framer-motion"
import { ImageCropModal } from "@/components/image-crop-modal"

interface ProfilePhotoUploadProps {
  initialPhotos?: string[]
  onPhotosChange: (photos: string[]) => void
  maxPhotos?: number
  minPhotos?: number
  id?: string
  profileId?: string // Add profile ID to save directly to database
}

export function ProfilePhotoUpload({
  initialPhotos = [],
  onPhotosChange,
  maxPhotos = 3,
  minPhotos = 3,
  id,
  profileId,
}: ProfilePhotoUploadProps) {
  const [photos, setPhotos] = useState<string[]>(initialPhotos)
  const [uploading, setUploading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [validationError, setValidationError] = useState<string | null>(null)
  const [imageErrors, setImageErrors] = useState<Record<number, boolean>>({})
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null)
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null)
  const [deleting, setDeleting] = useState<Record<number, boolean>>({})
  const [isInitialLoad, setIsInitialLoad] = useState(true)

  // New state for crop modal
  const [showCropModal, setShowCropModal] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)

  const fileInputRef = useRef<HTMLInputElement>(null)
  const { user } = useAuth()

  // Update photos when initialPhotos changes (for editing)
  useEffect(() => {
    setPhotos(initialPhotos)
    setImageErrors({}) // Reset image errors when photos change
    setIsInitialLoad(true) // Mark as initial load to prevent auto-save
  }, [initialPhotos])

  // Auto-save photos to database whenever photos array changes (except on initial load)
  useEffect(() => {
    const savePhotosToDatabase = async () => {
      if (!profileId || !user || isInitialLoad) {
        if (isInitialLoad) {
          setIsInitialLoad(false) // Mark initial load as complete
        }
        return
      }

      setSaving(true)
      try {
        await updateProfile(profileId, { photos })
        console.log("Photos automatically saved to database:", photos)
      } catch (error) {
        console.error("Error auto-saving photos:", error)
        setError(`Failed to save photos: ${error instanceof Error ? error.message : "Unknown error"}`)
      } finally {
        setSaving(false)
      }
    }

    savePhotosToDatabase()
  }, [photos, profileId, user, isInitialLoad])

  // Validate minimum photo requirement
  useEffect(() => {
    if (photos.length < minPhotos) {
      setValidationError(`Please upload 3 photos of yourself`)
    } else {
      setValidationError(null)
    }

    // Notify parent component of changes
    onPhotosChange(photos)
  }, [photos, minPhotos, onPhotosChange])

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files.length) return

    if (!user) {
      setError("You must be signed in to upload photos")
      return
    }

    setError(null)

    try {
      const files = Array.from(e.target.files)
      const remainingSlots = maxPhotos - photos.length
      const filesToUpload = files.slice(0, remainingSlots)

      if (filesToUpload.length === 0) {
        return
      }

      // Validate file types
      const invalidFiles = filesToUpload.filter((file) => !file.type.startsWith("image/"))
      if (invalidFiles.length > 0) {
        throw new Error(`Invalid file type(s). Only images are allowed.`)
      }

      // Check file sizes
      const largeFiles = filesToUpload.filter((file) => file.size > 10 * 1024 * 1024)
      if (largeFiles.length > 0) {
        throw new Error(`Some files exceed the 10MB size limit. Please resize your images.`)
      }

      // Compress image before showing crop modal
      console.log("Compressing image...")
      const compressedFiles = await compressImages([filesToUpload[0]], 1200, 0.7)

      // Create preview URL for the crop modal
      const reader = new FileReader()
      reader.onload = (event) => {
        if (event.target?.result) {
          setPreviewUrl(event.target.result as string)
          setSelectedFile(compressedFiles[0])
          setShowCropModal(true)
        }
      }
      reader.readAsDataURL(compressedFiles[0])
    } catch (error) {
      console.error("Error in handleFileChange:", error)
      setError(`Failed to process image: ${error instanceof Error ? error.message : "Unknown error"}`)
    } finally {
      // Reset the file input
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    }
  }

  const handleCropComplete = (imageUrl: string) => {
    setShowCropModal(false)
    setSelectedFile(null)
    setPreviewUrl(null)

    // Add the new photo to the list (this will trigger auto-save)
    setPhotos((prev) => [...prev, imageUrl])
    console.log("Photo added to list and will be auto-saved:", imageUrl)
  }

  const handleCropCancel = () => {
    setShowCropModal(false)
    setSelectedFile(null)
    setPreviewUrl(null)
  }

  const removePhoto = async (index: number) => {
    if (!user) return

    const photoUrl = photos[index]

    // Mark this photo as being deleted
    setDeleting((prev) => ({ ...prev, [index]: true }))

    try {
      // Delete from Firebase Storage
      const storagePath = extractStoragePathFromUrl(photoUrl)
      if (storagePath) {
        await deleteProfileImage(storagePath)
        console.log(`Deleted photo from Firebase Storage: ${storagePath}`)
      } else {
        console.warn(`Could not extract storage path from URL: ${photoUrl}`)
      }

      // Remove from local state (this will trigger auto-save to database)
      const newPhotos = [...photos]
      newPhotos.splice(index, 1)
      setPhotos(newPhotos)

      console.log(`Photo removed from list and will be auto-saved. Remaining photos:`, newPhotos)
    } catch (error) {
      console.error("Error deleting photo:", error)
      setError(`Failed to delete photo: ${error instanceof Error ? error.message : "Unknown error"}`)
    } finally {
      // Also remove from image errors and deleting state
      const newImageErrors = { ...imageErrors }
      delete newImageErrors[index]
      setImageErrors(newImageErrors)

      setDeleting((prev) => {
        const newDeleting = { ...prev }
        delete newDeleting[index]
        return newDeleting
      })
    }
  }

  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click()
    }
  }

  const handleImageError = (index: number) => {
    console.warn(`Image at index ${index} failed to load:`, photos[index])
    setImageErrors((prev) => ({ ...prev, [index]: true }))
  }

  // Drag and drop reordering
  const handleDragStart = (index: number) => {
    setDraggedIndex(index)
  }

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault()
    setDragOverIndex(index)
  }

  const handleDrop = (e: React.DragEvent, index: number) => {
    e.preventDefault()
    if (draggedIndex === null) return

    // Reorder the photos array
    const newPhotos = [...photos]
    const draggedPhoto = newPhotos[draggedIndex]

    newPhotos.splice(draggedIndex, 1)
    newPhotos.splice(index, 0, draggedPhoto)

    setPhotos(newPhotos) // This will trigger auto-save
    setDraggedIndex(null)
    setDragOverIndex(null)
  }

  const handleDragEnd = () => {
    setDraggedIndex(null)
    setDragOverIndex(null)
  }

  return (
    <div className="space-y-4">
      {error && (
        <Alert variant="destructive" className="bg-red-900/20 border-red-800 text-red-300">
          <AlertCircle className="h-4 w-4 mr-2" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {validationError && (
        <Alert className="bg-purple-900/20 border-purple-800 text-purple-300">
          <AlertCircle className="h-4 w-4 mr-2" />
          <AlertDescription>{validationError}</AlertDescription>
        </Alert>
      )}

      <Alert className="bg-purple-900/20 border-purple-800 text-purple-300">
        <Info className="h-4 w-4 mr-2" />
        <AlertDescription>
          Please upload 3 photos of yourself. These should be clear photos that show your face. Photos are saved
          automatically after cropping. To recrop a photo, delete it and upload a new one. Drag and drop to reorder.
        </AlertDescription>
      </Alert>

      {/* Auto-save indicator */}
      {saving && (
        <Alert className="bg-blue-900/20 border-blue-800 text-blue-300">
          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          <AlertDescription>Saving photos...</AlertDescription>
        </Alert>
      )}

      {/* Main photo grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Existing photos */}
        {photos.map((photo, index) => {
          const hasError = imageErrors[index]
          const isDeleting = deleting[index]

          return (
            <motion.div
              key={photo}
              layoutId={`photo-${photo}`}
              draggable
              onDragStart={() => handleDragStart(index)}
              onDragOver={(e) => handleDragOver(e, index)}
              onDrop={(e) => handleDrop(e, index)}
              onDragEnd={handleDragEnd}
              className={cn(
                "relative rounded-xl overflow-hidden border-2 transition-all aspect-[3/4]",
                hasError ? "border-red-600 bg-red-900/20" : "border-purple-500",
                dragOverIndex === index && "border-dashed border-purple-400 bg-purple-900/20",
                draggedIndex === index && "opacity-50",
              )}
            >
              {hasError ? (
                <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center">
                  <AlertCircle className="h-8 w-8 text-red-500 mb-2" />
                  <p className="text-red-300 text-sm">Image failed to load</p>
                  <Button variant="destructive" size="sm" className="mt-2" onClick={() => removePhoto(index)}>
                    <Trash2 className="h-4 w-4 mr-1" /> Remove
                  </Button>
                </div>
              ) : (
                <>
                  {/* Image */}
                  <img
                    src={ensureValidImageUrl(photo) || "/placeholder.svg"}
                    alt={`Photo ${index + 1}`}
                    className="w-full h-full object-cover transition-transform duration-200"
                    onError={() => handleImageError(index)}
                  />
                  {/* Delete button */}
                  <div className="absolute top-3 right-3">
                    <Button
                      variant="destructive"
                      size="icon"
                      className="h-9 w-9 rounded-full bg-black/80 hover:bg-red-600/90 border border-white/20 backdrop-blur-sm"
                      onClick={() => removePhoto(index)}
                      disabled={isDeleting || uploading || saving}
                    >
                      {isDeleting ? (
                        <Loader2 className="h-4 w-4 animate-spin text-white" />
                      ) : (
                        <X className="h-4 w-4 text-white" />
                      )}
                    </Button>
                  </div>

                  {/* Photo number badge */}
                  <div className="absolute bottom-3 left-3">
                    <span className="bg-purple-500/90 backdrop-blur-sm px-3 py-1 rounded-full text-white text-sm font-medium border border-white/20">
                      {index + 1}/{photos.length}
                    </span>
                  </div>
                </>
              )}
            </motion.div>
          )
        })}

        {/* Upload button tile */}
        {photos.length < maxPhotos && (
          <motion.div
            layoutId="upload-button"
            className={cn(
              "rounded-xl border-2 border-dashed flex flex-col items-center justify-center p-4 aspect-[3/4]",
              photos.length < minPhotos
                ? "border-purple-500 bg-purple-900/10 animate-pulse"
                : "border-purple-500/50 bg-purple-900/5",
            )}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/jpeg,image/png,image/webp,image/gif"
              className="hidden"
              id={id}
            />

            <Button
              variant="outline"
              size="lg"
              className={cn(
                "h-16 w-16 rounded-full mb-3",
                "border-purple-500 bg-purple-900/20 text-purple-300 hover:bg-purple-900/30",
              )}
              onClick={triggerFileInput}
              disabled={uploading || saving}
            >
              {uploading || saving ? <Loader2 className="h-6 w-6 animate-spin" /> : <Plus className="h-6 w-6" />}
            </Button>

            <h3 className="text-sm font-medium mb-1 text-purple-300">
              {photos.length < minPhotos ? "Required" : "Add Photo"}
            </h3>

            <p className="text-zinc-400 text-xs text-center">
              {photos.length < minPhotos
                ? `At least ${minPhotos} photos required`
                : `${photos.length}/${maxPhotos} photos`}
            </p>
          </motion.div>
        )}
      </div>

      {/* Quick actions */}
      <div className="flex flex-wrap gap-2 justify-center mt-2">
        <Button
          variant="outline"
          size="sm"
          onClick={triggerFileInput}
          disabled={uploading || saving || photos.length >= maxPhotos}
          className="bg-purple-900/20 text-purple-300 border-purple-500/50 hover:bg-purple-900/30"
        >
          <Camera className="mr-2 h-4 w-4" />
          {uploading || saving ? "Processing..." : "Upload Photo"}
        </Button>

        {photos.length > 0 && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              // Delete all photos from Firebase before clearing
              Promise.all(
                photos.map(async (photo) => {
                  const storagePath = extractStoragePathFromUrl(photo)
                  if (storagePath && user) {
                    try {
                      await deleteProfileImage(storagePath)
                    } catch (error) {
                      console.error(`Failed to delete photo: ${storagePath}`, error)
                    }
                  }
                }),
              ).finally(() => {
                setPhotos([]) // This will trigger auto-save
              })
            }}
            disabled={uploading || saving || Object.keys(deleting).length > 0}
            className="bg-red-900/20 text-red-300 border-red-500/50 hover:bg-red-900/30"
          >
            <Trash2 className="mr-2 h-4 w-4" />
            Clear All
          </Button>
        )}
      </div>

      {/* Crop Modal */}
      {showCropModal && previewUrl && selectedFile && (
        <ImageCropModal
          isOpen={showCropModal}
          onClose={handleCropCancel}
          imageUrl={previewUrl}
          onSave={handleCropComplete}
          photoIndex={photos.length}
          originalFile={selectedFile}
        />
      )}
    </div>
  )
}
