"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Info } from "lucide-react"
import { isFirebaseStorageUrl, isValidUrl } from "@/lib/utils"

interface ImageDebuggerProps {
  imageUrl: string
}

export function ImageDebugger({ imageUrl }: ImageDebuggerProps) {
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading")
  const [errorDetails, setErrorDetails] = useState<string | null>(null)
  const [fixedUrl, setFixedUrl] = useState<string | null>(null)

  useEffect(() => {
    if (!imageUrl) {
      setStatus("error")
      setErrorDetails("No image URL provided")
      return
    }

    // Check if URL is valid
    if (!isValidUrl(imageUrl)) {
      setStatus("error")
      setErrorDetails("Invalid URL format")
      return
    }

    // Test image loading
    const img = new Image()
    img.crossOrigin = "anonymous"

    img.onload = () => {
      setStatus("success")
    }

    img.onerror = () => {
      setStatus("error")

      // Try to fix Firebase Storage URLs
      if (isFirebaseStorageUrl(imageUrl)) {
        const newUrl = imageUrl.includes("?") ? `${imageUrl}&alt=media` : `${imageUrl}?alt=media`
        setFixedUrl(newUrl)

        // Test the fixed URL
        const fixedImg = new Image()
        fixedImg.crossOrigin = "anonymous"
        fixedImg.onload = () => {
          setStatus("success")
          setErrorDetails("Fixed with alt=media parameter")
        }
        fixedImg.src = newUrl
      } else {
        setErrorDetails("Image failed to load")
      }
    }

    img.src = imageUrl
  }, [imageUrl])

  return (
    <Card className="mb-4">
      <CardHeader>
        <CardTitle className="text-sm">Image Debugger</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-xs break-all bg-zinc-800 p-2 rounded">
          <p>Original URL: {imageUrl || "None"}</p>
          {fixedUrl && <p className="mt-1">Fixed URL: {fixedUrl}</p>}
        </div>

        {status === "loading" && (
          <Alert className="bg-blue-900/20 border-blue-800 text-blue-300">
            <Info className="h-4 w-4 mr-2" />
            <AlertDescription>Testing image loading...</AlertDescription>
          </Alert>
        )}

        {status === "success" && (
          <Alert className="bg-green-900/20 border-green-800 text-green-300">
            <Info className="h-4 w-4 mr-2" />
            <AlertDescription>
              Image loaded successfully
              {errorDetails && ` (${errorDetails})`}
            </AlertDescription>
          </Alert>
        )}

        {status === "error" && (
          <Alert className="bg-red-900/20 border-red-800 text-red-300">
            <AlertCircle className="h-4 w-4 mr-2" />
            <AlertDescription>{errorDetails || "Unknown error"}</AlertDescription>
          </Alert>
        )}

        <div className="bg-zinc-800/50 p-2 rounded">
          <p className="text-xs mb-2">Preview:</p>
          <div className="h-40 flex items-center justify-center border border-zinc-700 rounded overflow-hidden">
            {status === "success" || fixedUrl ? (
              <img
                src={fixedUrl || imageUrl}
                alt="Debug preview"
                className="max-h-full max-w-full object-contain"
                crossOrigin="anonymous"
              />
            ) : (
              <div className="text-zinc-500 text-sm">Image not available</div>
            )}
          </div>
        </div>

        {status === "error" && isFirebaseStorageUrl(imageUrl) && (
          <div className="text-xs text-zinc-400">
            <p className="font-medium mb-1">Common Firebase Storage Issues:</p>
            <ul className="list-disc pl-4 space-y-1">
              <li>Missing "alt=media" parameter in URL</li>
              <li>CORS not configured properly</li>
              <li>Storage rules blocking access</li>
              <li>Token expired or invalid</li>
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
