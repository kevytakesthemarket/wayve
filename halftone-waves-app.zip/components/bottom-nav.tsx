"use client"

import { Users, User, MessageCircle } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"
import { useAuth } from "@/contexts/auth-context"
import { useEffect, useState } from "react"
import { getProfilesByUserId } from "@/lib/firebase/db"
import { subscribeToUserConversations } from "@/lib/firebase/messaging"
import type { Conversation } from "@/types/message"

export function BottomNav() {
  const pathname = usePathname()
  const { user } = useAuth()
  const [userProfile, setUserProfile] = useState<{ id: string } | null>(null)
  const [loading, setLoading] = useState(true)
  const [isVisible, setIsVisible] = useState(true)
  const [lastScrollY, setLastScrollY] = useState(0)
  const [unreadCount, setUnreadCount] = useState(0)

  // Fetch the user's profile when they're logged in
  useEffect(() => {
    const fetchUserProfile = async () => {
      setLoading(true)
      if (user?.uid) {
        try {
          const profiles = await getProfilesByUserId(user.uid)
          if (profiles && profiles.length > 0) {
            setUserProfile(profiles[0])
          } else {
            setUserProfile(null)
          }
        } catch (error) {
          console.error("Error fetching user profile:", error)
          setUserProfile(null)
        }
      } else {
        setUserProfile(null)
      }
      setLoading(false)
    }

    fetchUserProfile()
  }, [user])

  // Subscribe to conversations to get unread count
  useEffect(() => {
    if (!user?.uid) {
      setUnreadCount(0)
      return
    }

    console.log("Setting up conversation subscription for user:", user.uid)

    const unsubscribe = subscribeToUserConversations(user.uid, (conversations: Conversation[]) => {
      console.log("Received conversations:", conversations)

      // Calculate total unread messages for this user
      const totalUnread = conversations.reduce((total, conversation) => {
        const userUnreadCount = conversation.unreadCount?.[user.uid] || 0
        console.log(`Conversation ${conversation.id}: ${userUnreadCount} unread`)
        return total + userUnreadCount
      }, 0)

      console.log("Total unread messages:", totalUnread)
      setUnreadCount(totalUnread)
    })

    return () => {
      console.log("Cleaning up conversation subscription")
      unsubscribe()
    }
  }, [user?.uid])

  // Handle scroll to show/hide navigation
  useEffect(() => {
    // Don't show navigation on messaging pages at all
    if (pathname.startsWith("/messages")) {
      setIsVisible(false)
      return
    }

    const handleScroll = () => {
      const currentScrollY = window.scrollY

      // Only hide/show if we've scrolled more than 10px to avoid jitter
      if (Math.abs(currentScrollY - lastScrollY) < 10) {
        return
      }

      // Show nav when scrolling up, hide when scrolling down
      // Always show if we're near the top of the page
      if (currentScrollY < 100) {
        setIsVisible(true)
      } else if (currentScrollY > lastScrollY) {
        // Scrolling down
        setIsVisible(false)
      } else {
        // Scrolling up
        setIsVisible(true)
      }

      setLastScrollY(currentScrollY)
    }

    // Throttle scroll events for better performance
    let ticking = false
    const throttledHandleScroll = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          handleScroll()
          ticking = false
        })
        ticking = true
      }
    }

    window.addEventListener("scroll", throttledHandleScroll, { passive: true })
    return () => window.removeEventListener("scroll", throttledHandleScroll)
  }, [lastScrollY, pathname])

  // Determine the profile button path and text
  const profilePath = user ? (userProfile ? `/${userProfile.id}` : "/new/create") : "/new/signin?redirect=/new/create"

  const profileText = user ? (userProfile ? "My Profile" : "Add Profile") : "Add Profile"

  const messagesPath = user ? "/messages" : "/new/signin?redirect=/messages"

  const isProfileActive = pathname === "/new/create" || (userProfile && pathname === `/${userProfile.id}`)

  const isMessagesActive = pathname.startsWith("/messages")

  return (
    <motion.div
      className="fixed bottom-0 left-0 right-0 w-full h-16 bg-zinc-900 border-t-2 border-purple-500 flex items-center justify-around px-4 z-[100] shadow-lg"
      initial={{ y: 100, opacity: 0 }}
      animate={{
        y: isVisible ? 0 : 100,
        opacity: isVisible ? 1 : 0,
      }}
      transition={{
        type: "spring",
        stiffness: 300,
        damping: 30,
        duration: 0.3,
      }}
    >
      <div className="flex w-full max-w-md mx-auto justify-around">
        <Link
          href="/"
          className={cn(
            "flex flex-col items-center justify-center text-xs font-medium transition-colors px-5 py-2 rounded-full",
            pathname === "/"
              ? "text-purple-300 bg-zinc-800"
              : "text-zinc-400 hover:text-purple-300 bg-zinc-800 hover:bg-zinc-700",
          )}
        >
          <Users className="h-5 w-5 mb-1" />
          <span>Browse</span>
        </Link>

        <Link
          href={messagesPath}
          className={cn(
            "flex flex-col items-center justify-center text-xs font-medium transition-colors px-4 py-2 rounded-full relative",
            isMessagesActive
              ? "text-green-300 bg-zinc-800"
              : "text-zinc-400 hover:text-green-300 bg-zinc-800 hover:bg-zinc-700",
          )}
        >
          <div className="relative">
            <MessageCircle className="h-5 w-5 mb-1" />
            {unreadCount > 0 && (
              <div className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
                {unreadCount > 99 ? "99+" : unreadCount}
              </div>
            )}
          </div>
          <span>Messages</span>
        </Link>

        <Link
          href={profilePath}
          className={cn(
            "flex flex-col items-center justify-center text-xs font-medium transition-colors px-5 py-2 rounded-full",
            isProfileActive
              ? "text-blue-300 bg-zinc-800"
              : "text-zinc-400 hover:text-blue-300 bg-zinc-800 hover:bg-zinc-700",
          )}
        >
          <User className="h-5 w-5 mb-1" />
          <span>{loading ? "Profile" : profileText}</span>
        </Link>
      </div>
    </motion.div>
  )
}
