"use client"

import { useState } from "react"
import { X, User, HelpCircle, Search, Lightbulb, AlertTriangle, Info } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

export function TagLegend() {
  const [isOpen, setIsOpen] = useState(false)
  const [isDismissed, setIsDismissed] = useState(false)

  if (isDismissed) return null

  return (
    <div className="fixed bottom-20 right-4 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="bg-zinc-900 border border-zinc-800 rounded-xl shadow-xl p-4 mb-2 w-[280px]"
          >
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-zinc-200 font-medium">Tag Guide</h3>
              <button onClick={() => setIsOpen(false)} className="text-zinc-400 hover:text-zinc-200">
                <X size={16} />
              </button>
            </div>
            <p className="text-zinc-400 text-xs mb-3">
              Each colored tag represents different information about the profile:
            </p>
            <div className="space-y-2">
              <div className="flex items-center text-blue-300 text-xs">
                <User size={12} className="mr-2" />
                <span className="font-medium">Who I Am</span>
              </div>
              <div className="flex items-center text-purple-300 text-xs">
                <HelpCircle size={12} className="mr-2" />
                <span className="font-medium">Why I'm Here</span>
              </div>
              <div className="flex items-center text-green-300 text-xs">
                <Search size={12} className="mr-2" />
                <span className="font-medium">What I'm Looking For</span>
              </div>
              <div className="flex items-center text-yellow-300 text-xs">
                <Lightbulb size={12} className="mr-2" />
                <span className="font-medium">Political Beliefs</span>
              </div>
              <div className="flex items-center text-red-300 text-xs">
                <AlertTriangle size={12} className="mr-2" />
                <span className="font-medium">Controversial Belief</span>
              </div>
            </div>
            <button
              onClick={() => setIsDismissed(true)}
              className="w-full mt-3 text-xs text-zinc-400 hover:text-zinc-300"
            >
              Don't show again
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-full p-2 shadow-lg"
        aria-label="Tag information"
      >
        <Info size={20} />
      </button>
    </div>
  )
}
