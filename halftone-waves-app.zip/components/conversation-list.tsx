"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { subscribeToUserConversations, getConversationWithProfile } from "@/lib/firebase/messaging"
import type { Conversation, ConversationWithProfile } from "@/types/message"
import { Card, CardContent } from "@/components/ui/card"
import { MessageCircle, User, Eye } from "lucide-react"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"

export function ConversationList() {
  const { user } = useAuth()
  const router = useRouter()
  const [conversations, setConversations] = useState<ConversationWithProfile[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user?.uid) {
      setLoading(false)
      return
    }

    const unsubscribe = subscribeToUserConversations(user.uid, async (rawConversations) => {
      // Fetch profile info for each conversation
      const conversationsWithProfiles = await Promise.all(
        rawConversations.map(async (conversation) => {
          return await getConversationWithProfile(conversation, user.uid)
        }),
      )

      setConversations(conversationsWithProfiles)
      setLoading(false)
    })

    return unsubscribe
  }, [user?.uid])

  const formatTimestamp = (timestamp: any) => {
    if (!timestamp) return ""

    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp)
    const now = new Date()
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60)

    if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } else if (diffInHours < 168) {
      // 7 days
      return date.toLocaleDateString([], { weekday: "short" })
    } else {
      return date.toLocaleDateString([], { month: "short", day: "numeric" })
    }
  }

  const handleConversationClick = (conversation: Conversation) => {
    const otherUserId = conversation.participants.find((id) => id !== user?.uid)
    if (otherUserId) {
      router.push(`/messages/${otherUserId}`)
    }
  }

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] text-center">
        <MessageCircle className="h-16 w-16 text-zinc-600 mb-4" />
        <h3 className="text-lg font-medium text-zinc-300 mb-2">Sign in to view messages</h3>
        <p className="text-zinc-500">Connect with other users and start conversations</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="bg-zinc-800/50 border-zinc-700 backdrop-blur-sm">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-zinc-700 rounded-lg animate-pulse" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-zinc-700 rounded animate-pulse" />
                  <div className="h-3 bg-zinc-700 rounded w-3/4 animate-pulse" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  if (conversations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] text-center">
        <MessageCircle className="h-16 w-16 text-zinc-600 mb-4" />
        <h3 className="text-lg font-medium text-zinc-300 mb-2">No conversations yet</h3>
        <p className="text-zinc-500">Start a conversation by messaging someone from their profile</p>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {conversations.map(({ conversation, otherUserProfile }, index) => {
        const unreadCount = user?.uid ? conversation.unreadCount[user.uid] || 0 : 0
        const lastMessage = conversation.lastMessage

        // Get other user info - prioritize stored names, then fallback to profile
        const otherUserId = conversation.participants.find((id) => id !== user?.uid)
        const otherUserName = conversation.participantNames?.[otherUserId!] || otherUserProfile?.name || "Unknown User"
        const otherUserPhoto = conversation.participantPhotos?.[otherUserId!] || otherUserProfile?.photos?.[0] || null

        return (
          <motion.div
            key={conversation.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card
              className="bg-zinc-800/50 border-zinc-700 hover:bg-zinc-700/50 transition-colors cursor-pointer backdrop-blur-sm"
              onClick={() => handleConversationClick(conversation)}
            >
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  {/* Profile Picture - 50px square with rounded corners */}
                  <div className="relative">
                    {otherUserPhoto ? (
                      <img
                        src={otherUserPhoto || "/placeholder.svg"}
                        alt={otherUserName}
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-lg bg-zinc-700 flex items-center justify-center">
                        <User className="h-6 w-6 text-zinc-400" />
                      </div>
                    )}
                    {unreadCount > 0 && (
                      <div className="absolute -top-1 -right-1 bg-purple-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                        {unreadCount > 9 ? "9+" : unreadCount}
                      </div>
                    )}
                  </div>

                  {/* Conversation Info */}
                  <div className="flex-1 min-w-0 mr-2">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className={cn("font-medium truncate", unreadCount > 0 ? "text-zinc-100" : "text-zinc-300")}>
                        {otherUserName}
                      </h3>
                      {lastMessage && (
                        <span className="text-xs text-zinc-500 flex-shrink-0">
                          {formatTimestamp(lastMessage.timestamp)}
                        </span>
                      )}
                    </div>

                    {lastMessage && (
                      <p
                        className={cn(
                          "text-sm truncate",
                          unreadCount > 0 ? "text-zinc-300 font-medium" : "text-zinc-500",
                        )}
                      >
                        {lastMessage.senderId === user?.uid ? "You: " : ""}
                        {lastMessage.content}
                      </p>
                    )}
                  </div>
                  {/* View Profile Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      const otherUserId = conversation.participants.find((id) => id !== user?.uid)
                      if (otherUserId) {
                        router.push(`/${otherUserId}`)
                      }
                    }}
                    className="flex-shrink-0 p-2 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-700/50 rounded-lg transition-colors"
                    title="View Profile"
                  >
                    <Eye className="h-4 w-4" />
                  </button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )
      })}
    </div>
  )
}
