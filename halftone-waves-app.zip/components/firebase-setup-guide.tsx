"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronUp, Copy, Check } from "lucide-react"

export function FirebaseSetupGuide() {
  const [expanded, setExpanded] = useState(false)
  const [copied, setCopied] = useState(false)

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const firestoreRules = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Allow public read access to all profiles
    match /profiles/{profileId} {
      allow read: if true;
      allow write: if request.auth != null && (
        // New document with userId matching the authenticated user
        (resource == null && request.resource.data.userId == request.auth.uid) ||
        // Existing document with userId matching the authenticated user
        (resource != null && resource.data.userId == request.auth.uid)
      );
    }
    
    // Default deny
    match /{document=**} {
      allow read, write: if false;
    }
  }
}`

  const storageRules = `rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    // Allow users to read any profile photo
    match /profiles/{userId}/photos/{fileName} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Default deny
    match /{allPaths=**} {
      allow read, write: if false;
    }
  }
}`

  return (
    <Card className="w-full max-w-md mx-auto mb-6 bg-black/90 backdrop-blur-md border-0 shadow-xl card-extruded-matte">
      <CardHeader className="border-b border-zinc-800">
        <CardTitle className="text-white flex justify-between items-center">
          <span>Firebase Setup Guide</span>
          <Button variant="ghost" size="sm" onClick={() => setExpanded(!expanded)}>
            {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </Button>
        </CardTitle>
        <CardDescription className="text-zinc-400">
          Configure your Firebase project to work with this application
        </CardDescription>
      </CardHeader>

      {expanded && (
        <CardContent className="p-4 space-y-4">
          <p className="text-zinc-300 text-sm">
            To fix the permission error, you need to update your Firebase security rules. Follow these steps:
          </p>

          <Tabs defaultValue="firestore">
            <TabsList className="grid w-full grid-cols-2 bg-zinc-800">
              <TabsTrigger value="firestore">Firestore Rules</TabsTrigger>
              <TabsTrigger value="storage">Storage Rules</TabsTrigger>
            </TabsList>
            <TabsContent value="firestore" className="mt-4">
              <div className="relative">
                <pre className="bg-zinc-900 p-3 rounded-md text-xs text-zinc-300 overflow-x-auto">{firestoreRules}</pre>
                <Button
                  size="sm"
                  variant="ghost"
                  className="absolute top-2 right-2 h-8 w-8 p-0"
                  onClick={() => handleCopy(firestoreRules)}
                >
                  {copied ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
                </Button>
              </div>
              <p className="text-xs text-zinc-400 mt-2">
                1. Go to Firebase Console &gt; Firestore Database &gt; Rules
                <br />
                2. Replace the rules with the above code
                <br />
                3. Click "Publish"
              </p>
            </TabsContent>
            <TabsContent value="storage" className="mt-4">
              <div className="relative">
                <pre className="bg-zinc-900 p-3 rounded-md text-xs text-zinc-300 overflow-x-auto">{storageRules}</pre>
                <Button
                  size="sm"
                  variant="ghost"
                  className="absolute top-2 right-2 h-8 w-8 p-0"
                  onClick={() => handleCopy(storageRules)}
                >
                  {copied ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
                </Button>
              </div>
              <p className="text-xs text-zinc-400 mt-2">
                1. Go to Firebase Console &gt; Storage &gt; Rules
                <br />
                2. Replace the rules with the above code
                <br />
                3. Click "Publish"
              </p>
            </TabsContent>
          </Tabs>

          <div className="bg-zinc-800/50 p-3 rounded-md">
            <h3 className="text-sm font-medium text-zinc-300 mb-1">Additional Setup</h3>
            <ul className="text-xs text-zinc-400 space-y-1 list-disc pl-4">
              <li>Enable Email/Password authentication in Firebase Console &gt; Authentication &gt; Sign-in method</li>
              <li>Create Firestore Database if you haven't already (start in test mode)</li>
              <li>Create Storage bucket if you haven't already (start in test mode)</li>
            </ul>
          </div>
        </CardContent>
      )}
    </Card>
  )
}
