"use client"

import { useState } from "react"

interface CorsImageProps {
  src: string
  alt: string
  className?: string
  onError?: () => void
}

export function CorsImage({ src, alt, className, onError }: CorsImageProps) {
  const [error, setError] = useState(false)

  if (error) {
    return (
      <div className={`flex items-center justify-center bg-zinc-900 ${className}`}>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-zinc-400"
        >
          <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"></path>
          <path d="m10 15 5-5"></path>
          <path d="m15 15-5-5"></path>
        </svg>
      </div>
    )
  }

  // Add referrerPolicy and crossOrigin to help with CORS
  return (
    <img
      src={src || "/placeholder.svg"}
      alt={alt}
      className={className}
      onError={() => {
        console.error(`Error loading image: ${src}`)
        setError(true)
        if (onError) onError()
      }}
      crossOrigin="anonymous"
      referrerPolicy="no-referrer"
    />
  )
}
