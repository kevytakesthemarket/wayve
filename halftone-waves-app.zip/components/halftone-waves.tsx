"use client"

import { useEffect, useRef } from "react"
import { useMobile } from "@/hooks/use-mobile"

export default function HalftoneWaves() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const isMobile = useMobile()

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d", { alpha: false })
    if (!ctx) return

    let animationFrameId: number
    let time = 0
    // Remove these lines:
    // let lastScrollY = window.scrollY
    // let scrollTimeout: NodeJS.Timeout | null = null

    // Set canvas to viewport size only, not document height
    const resizeCanvas = () => {
      // Get the device pixel ratio
      const dpr = window.devicePixelRatio || 1

      // Set canvas size to viewport dimensions
      const viewportWidth = window.innerWidth
      const viewportHeight = window.innerHeight

      // Set the canvas width and height accounting for the device pixel ratio
      canvas.width = viewportWidth * dpr
      canvas.height = viewportHeight * dpr

      // Scale the context to ensure correct drawing operations
      ctx.scale(dpr, dpr)

      // Set the CSS size of the canvas
      canvas.style.width = `${viewportWidth}px`
      canvas.style.height = `${viewportHeight}px`
    }

    // Helper function to draw rounded rectangles
    const roundedRect = (
      ctx: CanvasRenderingContext2D,
      x: number,
      y: number,
      width: number,
      height: number,
      radius: number,
    ) => {
      ctx.beginPath()
      ctx.moveTo(x + radius, y)
      ctx.lineTo(x + width - radius, y)
      ctx.quadraticCurveTo(x + width, y, x + width, y + radius)
      ctx.lineTo(x + width, y + height - radius)
      ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height)
      ctx.lineTo(x + radius, y + height)
      ctx.quadraticCurveTo(x, y + height, x, y + height - radius)
      ctx.lineTo(x, y + radius)
      ctx.quadraticCurveTo(x, y, x + radius, y)
      ctx.closePath()
    }

    // Optimize the wave drawing function
    const drawDiagonalWaves = () => {
      // Get the CSS size of the canvas (not the actual pixel size)
      const rect = canvas.getBoundingClientRect()
      const cssWidth = rect.width
      const cssHeight = rect.height

      // Keep the same grid size on both mobile and desktop for visual consistency
      const gridSize = 15

      // Calculate visible rows and columns with a small buffer
      const rows = Math.ceil(cssHeight / gridSize) + 4
      const cols = Math.ceil(cssWidth / gridSize) + 4

      // Create diagonal wave pattern - same parameters for visual consistency
      for (let y = -2; y < rows; y++) {
        for (let x = -2; x < cols; x++) {
          // Base position
          const baseX = x * gridSize
          const baseY = y * gridSize

          // Calculate diagonal wave offset - same on both devices for visual consistency
          const diagonalPos = (x + y) * 0.17

          // Only adjust the speed, not the pattern or appearance
          const timeMultiplier = isMobile ? 0.55 : 1.0 // Mobile runs at 55% speed
          const adjustedTime = time * timeMultiplier

          const waveOffset = Math.sin(diagonalPos - adjustedTime * 1.5) * 15

          // Apply diagonal offset to both x and y
          const centerX = baseX - waveOffset
          const centerY = baseY + waveOffset

          // Create wave intensity based on diagonal position - same on both devices
          const wave1 = Math.sin(diagonalPos * 0.9 + adjustedTime * 0.9) * 0.5 + 0.5
          const wave2 = Math.cos(diagonalPos * 0.7 - adjustedTime * 0.7) * 0.3 + 0.7
          const intensity = (wave1 + wave2) / 2

          // Size variation based on wave position - same on both devices
          const size = gridSize * intensity * 0.7

          // Purple-blue gradient colors - same on both devices
          const red = Math.floor(100 + intensity * 100)
          const green = Math.floor(50 + intensity * 50)
          const blue = Math.floor(180 + intensity * 75)

          // Draw rounded square - same appearance, just slower rotation on mobile
          ctx.save()
          ctx.translate(centerX, centerY)
          ctx.rotate(diagonalPos * 0.12 + adjustedTime * 0.25)

          // Enable anti-aliasing for smoother rendering
          ctx.imageSmoothingEnabled = true
          ctx.imageSmoothingQuality = "high"

          roundedRect(ctx, -size / 2, -size / 2, size, size, size * 0.3)

          ctx.fillStyle = `rgba(${red}, ${green}, ${blue}, ${intensity * 0.8})`
          ctx.fill()
          ctx.restore()
        }
      }
    }

    // Throttled animation function to improve performance
    const animate = () => {
      // Use a solid color fill first to prevent accumulation of artifacts
      ctx.fillStyle = "rgb(25, 10, 50)"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Then apply the semi-transparent overlay for the fade effect
      ctx.fillStyle = "rgba(25, 10, 50, 0.2)"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      drawDiagonalWaves()

      // Only adjust the speed, not the visual appearance
      time += 0.045 // Same time increment for both, but we use timeMultiplier inside the drawing function

      animationFrameId = requestAnimationFrame(animate)
    }

    // Handle scroll events with throttling
    // Replace the handleScroll function with this simplified version:
    const handleScroll = () => {
      // No need to do anything - the fixed position canvas will stay in place
    }

    // Initial setup
    resizeCanvas()
    animate()

    // Add event listeners
    window.addEventListener("resize", resizeCanvas)
    window.addEventListener("orientationchange", resizeCanvas)
    window.addEventListener("scroll", handleScroll)

    return () => {
      cancelAnimationFrame(animationFrameId)
      window.removeEventListener("resize", resizeCanvas)
      window.removeEventListener("orientationchange", resizeCanvas)
      window.removeEventListener("scroll", handleScroll)
      // Remove this line from the cleanup function:
      // if (scrollTimeout) clearTimeout(scrollTimeout)
    }
  }, [isMobile])

  return (
    <canvas
      ref={canvasRef}
      className="fixed top-0 left-0 w-full -z-10 bg-gradient-to-b from-purple-900 to-blue-950"
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100vh",
        pointerEvents: "none",
      }}
    />
  )
}
