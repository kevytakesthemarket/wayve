"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { Loader2 } from "lucide-react"

interface AuthGuardProps {
  children: React.ReactNode
  requireAuth?: boolean
}

export function AuthGuard({ children, requireAuth = true }: AuthGuardProps) {
  const { user, loading } = useAuth()
  const router = useRouter()
  const pathname = usePathname()
  const [isChecking, setIsChecking] = useState(true)

  useEffect(() => {
    if (!loading) {
      if (requireAuth && !user) {
        // Save the current path to redirect back after login
        if (pathname !== "/new/signin" && pathname !== "/new/signup" && pathname !== "/new/reset-password") {
          sessionStorage.setItem("redirectAfterLogin", pathname)
        }
        router.push("/new/signin")
      } else if (!requireAuth && user) {
        // If user is logged in and tries to access auth pages, redirect to home
        if (pathname === "/new/signin" || pathname === "/new/signup" || pathname === "/new/reset-password") {
          const redirectPath = sessionStorage.getItem("redirectAfterLogin") || "/"
          sessionStorage.removeItem("redirectAfterLogin")
          router.push(redirectPath)
        }
      }
      setIsChecking(false)
    }
  }, [user, loading, requireAuth, router, pathname])

  if (loading || isChecking) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
      </div>
    )
  }

  // If requireAuth is true and user is null, the useEffect will handle the redirect
  return <>{children}</>
}
