"use client"

import { useState, useRef, useEffect } from "react"
import type { Profile } from "@/types/profile"
import { ProfileCard } from "./profile-card"
import { motion, type PanInfo, useAnimation } from "framer-motion"

interface CardStackProps {
  profiles: Profile[]
}

export function CardStack({ profiles }: CardStackProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const controls = useAnimation()
  const constraintsRef = useRef(null)

  const handleDragEnd = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    const threshold = 100

    if (info.offset.x > threshold) {
      // Swiped right
      controls.start({ x: "100%", opacity: 0, rotateZ: 5 })
      setTimeout(() => {
        nextProfile()
      }, 300)
    } else if (info.offset.x < -threshold) {
      // Swiped left
      controls.start({ x: "-100%", opacity: 0, rotateZ: -5 })
      setTimeout(() => {
        nextProfile()
      }, 300)
    } else {
      // Return to center
      controls.start({ x: 0, opacity: 1, rotateZ: 0 })
    }
  }

  const nextProfile = () => {
    if (currentIndex < profiles.length - 1) {
      setCurrentIndex(currentIndex + 1)
    } else {
      setCurrentIndex(0) // Loop back to the first profile
    }
    controls.set({ x: 0, opacity: 1, rotateZ: 0 })
  }

  const handleExpand = (id: string) => {
    if (expandedId === id) {
      setExpandedId(null)
    } else {
      setExpandedId(id)
    }
  }

  // Reset expanded state when changing profiles
  useEffect(() => {
    setExpandedId(null)
  }, [currentIndex])

  if (profiles.length === 0) {
    return <div className="text-white text-center mt-10">No profiles found</div>
  }

  const currentProfile = profiles[currentIndex]

  return (
    <div className="relative w-full flex items-center justify-center" ref={constraintsRef}>
      {expandedId ? (
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
        >
          <ProfileCard
            profile={currentProfile}
            expanded={true}
            onExpand={handleExpand}
            className="max-h-[80vh] overflow-y-auto"
            disableNavigation={true}
          />
        </motion.div>
      ) : (
        <motion.div
          drag="x"
          dragConstraints={constraintsRef}
          onDragEnd={handleDragEnd}
          animate={controls}
          initial={{ opacity: 1, x: 0, rotateZ: 0 }}
          whileDrag={{ scale: 1.02, rotateZ: 0 }}
          dragTransition={{ bounceStiffness: 600, bounceDamping: 20 }}
          className="touch-none"
          style={{ transformStyle: "preserve-3d" }}
        >
          <ProfileCard profile={currentProfile} onExpand={handleExpand} />
        </motion.div>
      )}
    </div>
  )
}
