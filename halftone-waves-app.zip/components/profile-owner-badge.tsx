"use client"

import { useAuth } from "@/contexts/auth-context"
import { Badge } from "@/components/ui/badge"
import { User } from "lucide-react"

interface ProfileOwnerBadgeProps {
  profileUserId?: string
}

export function ProfileOwnerBadge({ profileUserId }: ProfileOwnerBadgeProps) {
  const { user } = useAuth()

  // Only show the badge if the profile belongs to the current user
  if (!user || !profileUserId || user.uid !== profileUserId) {
    return null
  }

  return (
    <Badge variant="outline" className="bg-green-900/30 text-green-300 border-green-700 flex items-center gap-1">
      <User size={12} />
      <span>Your Profile</span>
    </Badge>
  )
}
