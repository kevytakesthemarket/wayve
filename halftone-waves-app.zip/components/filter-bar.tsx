"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Search, Filter, X } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { CATEGORY_TAGS } from "@/lib/profile-service"
import { cn } from "@/lib/utils"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"

interface FilterBarProps {
  onFilterChange: (filters: {
    search: string
    tags: string[]
  }) => void
  initialFilters?: {
    search: string
    tags: string[]
  }
}

export function FilterBar({ onFilterChange, initialFilters = { search: "", tags: [] } }: FilterBarProps) {
  const [search, setSearch] = useState(initialFilters.search)
  const [showFilters, setShowFilters] = useState(false)
  const [selectedTags, setSelectedTags] = useState<string[]>(initialFilters.tags)
  const filtersRef = useRef<HTMLDivElement>(null)

  // Handle outside click to close filters
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (filtersRef.current && !filtersRef.current.contains(event.target as Node)) {
        setShowFilters(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newSearch = e.target.value
    setSearch(newSearch)
    onFilterChange({
      search: newSearch,
      tags: selectedTags,
    })
  }

  // Handle tag selection
  const toggleTag = (tag: string) => {
    const newTags = selectedTags.includes(tag) ? selectedTags.filter((t) => t !== tag) : [...selectedTags, tag]

    setSelectedTags(newTags)
    onFilterChange({
      search,
      tags: newTags,
    })
  }

  // Clear all filters
  const clearFilters = () => {
    setSearch("")
    setSelectedTags([])
    onFilterChange({
      search: "",
      tags: [],
    })
  }

  // Get all tags from all categories
  const allTags = [
    ...CATEGORY_TAGS.POLITICAL,
    ...CATEGORY_TAGS.OCCUPATION,
    ...CATEGORY_TAGS.INTERESTS,
    ...CATEGORY_TAGS.ORGANIZATION,
  ]

  // Category tag color mapping
  const getTagColor = (tag: string, isSelected: boolean) => {
    const baseClasses = "px-2 py-1 text-xs rounded-full border transition-all cursor-pointer"

    if (CATEGORY_TAGS.ORGANIZATION.includes(tag)) {
      return isSelected
        ? `${baseClasses} bg-white text-black border-white font-medium`
        : `${baseClasses} bg-white/10 text-white border-white/30 hover:bg-white/20`
    } else if (CATEGORY_TAGS.POLITICAL.includes(tag)) {
      return isSelected
        ? `${baseClasses} bg-purple-500 text-white border-purple-500`
        : `${baseClasses} bg-purple-500/10 text-purple-300 border-purple-500/30 hover:bg-purple-500/20`
    } else if (CATEGORY_TAGS.OCCUPATION.includes(tag)) {
      return isSelected
        ? `${baseClasses} bg-blue-500 text-white border-blue-500`
        : `${baseClasses} bg-blue-500/10 text-blue-300 border-blue-500/30 hover:bg-blue-500/20`
    } else if (CATEGORY_TAGS.INTERESTS.includes(tag)) {
      return isSelected
        ? `${baseClasses} bg-green-500 text-white border-green-500`
        : `${baseClasses} bg-green-500/10 text-green-300 border-green-500/30 hover:bg-green-500/20`
    }

    return isSelected
      ? `${baseClasses} bg-zinc-500 text-white border-zinc-500`
      : `${baseClasses} bg-zinc-700/50 text-zinc-300 border-zinc-600/30 hover:bg-zinc-700`
  }

  return (
    <div className="w-full max-w-md mx-auto px-4 mb-6 relative">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-zinc-400" />
          <Input
            type="text"
            placeholder="Search profiles..."
            value={search}
            onChange={handleSearchChange}
            onClick={() => setShowFilters(true)}
            className="pl-9 bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500 rounded-xl"
          />
          {search && (
            <button
              onClick={() => {
                setSearch("")
                onFilterChange({
                  search: "",
                  tags: selectedTags,
                })
              }}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-zinc-400 hover:text-zinc-300"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <Button
          variant="outline"
          size="icon"
          onClick={() => setShowFilters(!showFilters)}
          className={cn(
            "bg-zinc-800 border-zinc-700 text-zinc-300 hover:bg-zinc-700 hover:text-zinc-200",
            selectedTags.length > 0 && "text-purple-300 border-purple-500/50",
          )}
        >
          <Filter className="h-4 w-4" />
        </Button>
        {(search || selectedTags.length > 0) && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilters}
            className="text-zinc-400 hover:text-zinc-300 hover:bg-zinc-800"
          >
            Clear
          </Button>
        )}
      </div>

      <AnimatePresence>
        {showFilters && (
          <motion.div
            ref={filtersRef}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-full left-0 right-0 mt-2 p-4 bg-zinc-900 border border-zinc-800 rounded-xl shadow-xl z-50"
          >
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-zinc-300 font-medium">Filter by Tags</h3>
              <button onClick={() => setShowFilters(false)} className="text-zinc-400 hover:text-zinc-300">
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <h4 className="text-purple-400 text-xs font-medium mb-1">Political</h4>
                <div className="flex flex-wrap gap-1.5">
                  {CATEGORY_TAGS.POLITICAL.map((tag) => (
                    <span
                      key={tag}
                      onClick={() => toggleTag(tag)}
                      className={getTagColor(tag, selectedTags.includes(tag))}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-blue-400 text-xs font-medium mb-1">Occupation</h4>
                <div className="flex flex-wrap gap-1.5">
                  {CATEGORY_TAGS.OCCUPATION.map((tag) => (
                    <span
                      key={tag}
                      onClick={() => toggleTag(tag)}
                      className={getTagColor(tag, selectedTags.includes(tag))}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-green-400 text-xs font-medium mb-1">Interests</h4>
                <div className="flex flex-wrap gap-1.5">
                  {CATEGORY_TAGS.INTERESTS.map((tag) => (
                    <span
                      key={tag}
                      onClick={() => toggleTag(tag)}
                      className={getTagColor(tag, selectedTags.includes(tag))}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-white text-xs font-medium mb-1">Organization</h4>
                <div className="flex flex-wrap gap-1.5">
                  {CATEGORY_TAGS.ORGANIZATION.map((tag) => (
                    <span
                      key={tag}
                      onClick={() => toggleTag(tag)}
                      className={`${getTagColor(tag, selectedTags.includes(tag))} flex items-center`}
                    >
                      {tag === "Students for Liberty" && (
                        <Image
                          src="/images/sfl.png"
                          alt="Students for Liberty"
                          width={12}
                          height={12}
                          className="mr-1 rounded-full"
                        />
                      )}
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {selectedTags.length > 0 && (
              <div className="mt-3 p-2 bg-zinc-800/50 rounded-lg">
                <div className="flex justify-between items-center mb-1">
                  <h4 className="text-zinc-300 text-xs font-medium">Selected Tags</h4>
                  <button
                    onClick={() => {
                      setSelectedTags([])
                      onFilterChange({
                        search,
                        tags: [],
                      })
                    }}
                    className="text-zinc-500 hover:text-zinc-300 text-xs"
                  >
                    Clear All
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {selectedTags.map((tag) => (
                    <div
                      key={tag}
                      className="flex items-center bg-zinc-700 text-white text-xs px-2 py-0.5 rounded-full"
                    >
                      {tag}
                      <button onClick={() => toggleTag(tag)} className="ml-1 text-zinc-400 hover:text-white">
                        <X size={12} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
