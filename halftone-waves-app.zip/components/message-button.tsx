"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { MessageCircle, User } from "lucide-react"
import { createOrGetConversation } from "@/lib/firebase/messaging"
import { getProfilesByUserId, getProfileFromFirestore } from "@/lib/firebase/db"
import { auth } from "@/lib/firebase"

interface MessageButtonProps {
  userId: string
  userName: string
  className?: string
}

export function MessageButton({ userId, userName, className }: MessageButtonProps) {
  const { user } = useAuth()
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [hasProfile, setHasProfile] = useState<boolean | null>(null)

  // Check if current user has a profile
  useEffect(() => {
    const checkUserProfile = async () => {
      if (!user?.uid) {
        setHasProfile(null)
        return
      }

      try {
        const profiles = await getProfilesByUserId(user.uid)
        setHasProfile(profiles.length > 0)
      } catch (error) {
        console.error("Error checking user profile:", error)
        setHasProfile(false)
      }
    }

    checkUserProfile()
  }, [user?.uid])

  const handleMessage = async (e: React.MouseEvent) => {
    e.stopPropagation()

    // 🔒 VALIDATION - Check for required parameters
    if (!userId) {
      console.error("❌ userId is undefined")
      alert("Error: User ID is missing")
      return
    }

    if (!userName) {
      console.error("❌ userName is undefined")
      alert("Error: User name is missing")
      return
    }

    console.log("🔍 DEBUG - Message Button Parameters:")
    console.log("userId:", userId, "type:", typeof userId)
    console.log("userName:", userName, "type:", typeof userName)

    // 🔒 COMPREHENSIVE AUTHENTICATION CHECK
    console.log("🔍 DEBUG - Message Button Authentication Check:")
    console.log("user from context:", user?.uid)
    console.log("auth.currentUser:", auth.currentUser?.uid)

    // Check if user is authenticated in context
    if (!user?.uid) {
      console.log("❌ No user in auth context, redirecting to sign in")
      sessionStorage.setItem("messageTarget", JSON.stringify({ userId, userName }))
      router.push("/new/signin")
      return
    }

    // Check if Firebase auth is available
    if (!auth.currentUser?.uid) {
      console.log("❌ No Firebase auth user, redirecting to sign in")
      sessionStorage.setItem("messageTarget", JSON.stringify({ userId, userName }))
      router.push("/new/signin")
      return
    }

    // Verify both auth states match
    if (user.uid !== auth.currentUser.uid) {
      console.error("❌ Auth state mismatch!", {
        contextUID: user.uid,
        firebaseUID: auth.currentUser.uid,
      })
      alert("Authentication error. Please sign in again.")
      router.push("/new/signin")
      return
    }

    console.log("✅ User is properly authenticated:", user.uid)

    // 🧪 DEBUG: Log authentication state
    console.log("🔍 DEBUG - Authentication Check:")
    console.log("auth.currentUser?.uid:", auth.currentUser?.uid)
    console.log("user?.uid from context:", user?.uid)
    console.log("user object:", user)

    // Check authentication first
    // if (!user?.uid || !auth.currentUser?.uid) {
    //   console.log("❌ User not authenticated, redirecting to sign in")
    //   sessionStorage.setItem("messageTarget", JSON.stringify({ userId, userName }))
    //   router.push("/new/signin")
    //   return
    // }

    // Verify auth UIDs match
    // if (user.uid !== auth.currentUser.uid) {
    //   console.error("❌ Auth UID mismatch!", {
    //     contextUID: user.uid,
    //     authUID: auth.currentUser.uid,
    //   })
    //   alert("Authentication error. Please sign in again.")
    //   router.push("/new/signin")
    //   return
    // }

    // Check if trying to message yourself
    if (user.uid === userId) {
      console.log("❌ Cannot message yourself")
      return
    }

    // Check if user has a profile
    if (hasProfile === false) {
      console.log("❌ User has no profile, redirecting to create profile")
      sessionStorage.setItem("messageTarget", JSON.stringify({ userId, userName }))
      router.push("/new/create?redirect=message")
      return
    }

    // Wait for profile check to complete
    if (hasProfile === null) {
      console.log("⏳ Still checking if user has profile...")
      return
    }

    setLoading(true)
    try {
      console.log(`🎯 Starting conversation flow:`)
      console.log(`   Authenticated user: ${user.uid}`)
      console.log(`   Target user: ${userId} (${userName})`)

      // Resolve target user ID if it's a slug
      let targetUserId = userId
      if (userId.length < 20) {
        try {
          const profile = await getProfileFromFirestore(userId)
          if (profile?.userId) {
            console.log(`✅ Resolved slug ${userId} to userId: ${profile.userId}`)
            targetUserId = profile.userId
          } else {
            console.log(`⚠️ Could not resolve slug ${userId}, using as-is`)
          }
        } catch (error) {
          console.error(`❌ Failed to resolve slug ${userId}:`, error)
        }
      }

      console.log(`🚀 Creating conversation between:`)
      console.log(`   Auth user: ${user.uid}`)
      console.log(`   Target user: ${targetUserId}`)

      // Create conversation with authenticated user's UID
      const conversationId = await createOrGetConversation(user.uid, targetUserId)
      console.log(`✅ Conversation created: ${conversationId}`)

      // Navigate to the chat page using the original userId (which might be a slug)
      router.push(`/messages/${userId}`)
    } catch (error) {
      console.error("❌ Error creating conversation:", error)

      let errorMessage = "Failed to start conversation. "
      if (error instanceof Error) {
        if (error.message.includes("permission") || error.message.includes("insufficient")) {
          errorMessage += "Permission denied. Please make sure you're signed in and have a profile."
        } else if (error.message.includes("auth")) {
          errorMessage += "Authentication error. Please sign in again."
        } else {
          errorMessage += `Error: ${error.message}`
        }
      }

      alert(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  // Don't show message button on your own profile
  if (user?.uid && user.uid === userId) {
    return null
  }

  // Show different states based on user status
  if (!user?.uid) {
    return (
      <Button onClick={handleMessage} className={`bg-purple-600 hover:bg-purple-700 text-white ${className}`} size="sm">
        <MessageCircle className="h-4 w-4 mr-2" />
        Message {userName}
      </Button>
    )
  }

  if (hasProfile === null) {
    return (
      <Button disabled className={`bg-gray-600 text-white ${className}`} size="sm">
        <MessageCircle className="h-4 w-4 mr-2" />
        Loading...
      </Button>
    )
  }

  if (hasProfile === false) {
    return (
      <Button onClick={handleMessage} className={`bg-orange-600 hover:bg-orange-700 text-white ${className}`} size="sm">
        <User className="h-4 w-4 mr-2" />
        Complete Profile to Message
      </Button>
    )
  }

  return (
    <Button
      onClick={handleMessage}
      disabled={loading}
      className={`bg-purple-600 hover:bg-purple-700 text-white ${className}`}
      size="sm"
    >
      <MessageCircle className="h-4 w-4 mr-2" />
      {loading ? "Loading..." : `Message ${userName}`}
    </Button>
  )
}
