"use client"

import { motion } from "framer-motion"
import type { Profile } from "@/types/profile"
import { ProfileCard } from "./profile-card"

interface ProfileListProps {
  profiles: Profile[]
}

export function ProfileList({ profiles }: ProfileListProps) {
  if (profiles.length === 0) {
    return (
      <div className="text-white text-center mt-10 p-6 bg-zinc-800/50 rounded-xl">
        <h3 className="text-xl font-medium mb-2">No profiles found</h3>
        <p className="text-zinc-400">Try adjusting your filters or search criteria</p>
      </div>
    )
  }

  return (
    <div className="w-full space-y-6 pb-8">
      {profiles.map((profile, index) => (
        <motion.div
          key={profile.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1, duration: 0.3 }}
        >
          <ProfileCard profile={profile} />
        </motion.div>
      ))}
    </div>
  )
}
