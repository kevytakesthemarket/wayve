"use client"

import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { User, LogOut } from "lucide-react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { getProfilesByUserId } from "@/lib/firebase/db"
import { useEffect } from "react"

export function TopNav() {
  const { user, signOut } = useAuth()
  const [showUserMenu, setShowUserMenu] = useState(false)
  const [userProfile, setUserProfile] = useState<{ id: string } | null>(null)
  const router = useRouter()

  // Fetch the user's profile when they're logged in
  useEffect(() => {
    const fetchUserProfile = async () => {
      if (user?.uid) {
        try {
          const profiles = await getProfilesByUserId(user.uid)
          if (profiles && profiles.length > 0) {
            setUserProfile(profiles[0])
          } else {
            setUserProfile(null)
          }
        } catch (error) {
          console.error("Error fetching user profile:", error)
          setUserProfile(null)
        }
      } else {
        setUserProfile(null)
      }
    }

    fetchUserProfile()
  }, [user])

  const handleSignOut = async () => {
    try {
      await signOut()
      setShowUserMenu(false)
    } catch (error) {
      console.error("Error signing out:", error)
    }
  }

  const goToProfile = () => {
    if (userProfile) {
      router.push(`/${userProfile.id}`)
    } else {
      router.push("/new/create")
    }
    setShowUserMenu(false)
  }

  return (
    <motion.div
      className="fixed top-0 left-0 right-0 w-full h-24 bg-zinc-900 border-b-2 border-purple-500 flex items-center justify-between px-4 z-[100] shadow-lg"
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.1, type: "spring", stiffness: 300, damping: 30 }}
    >
      <div className="w-1/4 flex justify-start">{/* Empty div for balance */}</div>

      <div className="w-2/4 flex justify-center">
        <Link href="/" className="flex items-center">
          <div className="relative h-20 w-80">
            <Image
              src="/images/wayve-logo-script-compressed.png"
              alt="wayve.bio"
              fill
              className="object-contain"
              priority
            />
          </div>
        </Link>
      </div>

      <div className="w-1/4 flex justify-end">
        {/* User status and menu */}
        <div className="relative">
          {user ? (
            <div className="flex items-center">
              <Button
                variant="ghost"
                size="sm"
                className="text-zinc-300 hover:text-white flex items-center gap-2"
                onClick={() => setShowUserMenu(!showUserMenu)}
              >
                <User size={18} />
                <span className="hidden sm:inline">{user.displayName || user.email}</span>
              </Button>

              {/* User dropdown menu */}
              {showUserMenu && (
                <div className="absolute right-0 top-full mt-2 w-48 bg-zinc-800 border border-zinc-700 rounded-lg shadow-lg overflow-hidden z-50">
                  <div className="p-2 border-b border-zinc-700 text-xs text-zinc-400">
                    Signed in as <span className="font-medium text-zinc-300">{user.email}</span>
                  </div>
                  <div className="p-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start text-zinc-300 hover:text-white hover:bg-zinc-700"
                      onClick={goToProfile}
                    >
                      <User size={16} className="mr-2" />
                      {userProfile ? "View My Profile" : "Create Profile"}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start text-zinc-300 hover:text-white hover:bg-zinc-700"
                      onClick={handleSignOut}
                    >
                      <LogOut size={16} className="mr-2" />
                      Sign Out
                    </Button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <Link href="/new/signin">
              <Button variant="outline" size="sm" className="text-zinc-300 hover:text-white">
                Sign In
              </Button>
            </Link>
          )}
        </div>
      </div>
    </motion.div>
  )
}
