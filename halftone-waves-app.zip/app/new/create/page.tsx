"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createProfile } from "@/lib/profile-service"
import { CATEGORY_TAGS } from "@/lib/profile-service"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import HalftoneWaves from "@/components/halftone-waves"
import { TopNav } from "@/components/top-nav"
import { ArrowLeft, Loader2, X, Info, AlertCircle, CheckCircle, Plus, LinkIcon, Trash2 } from "lucide-react"
import { motion } from "framer-motion"
import { ProfilePhotoUpload } from "@/components/profile-photo-upload"
import { useAuth } from "@/contexts/auth-context"
import { AuthGuard } from "@/components/auth-guard"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Define an interface for the form data
interface ProfileFormData {
  name: string
  bio: string
  bioTag: string
  whyHere: string
  whyHereTag: string
  lookingFor: string
  lookingForTag: string
  politicalBeliefs: string
  politicalBeliefsTag: string
  controversialBelief: string
  controversialBeliefTag: string
  telegram: string
  twitter: string
  email: string
}

export default function CreateProfilePage() {
  const router = useRouter()
  const { user } = useAuth()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [photos, setPhotos] = useState<string[]>([])
  const [selectedCategoryTags, setSelectedCategoryTags] = useState<string[]>([])
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [formValid, setFormValid] = useState(false)
  const [validationErrors, setValidationErrors] = useState<string[]>([])
  const [activeTab, setActiveTab] = useState("basics")
  const [externalLinks, setExternalLinks] = useState<Array<{ title: string; url: string; description?: string }>>([])
  const [linkErrors, setLinkErrors] = useState<{ [key: number]: string }>({})

  // Create state for form data that persists between tab changes
  const [formData, setFormData] = useState<ProfileFormData>({
    name: "",
    bio: "",
    bioTag: "",
    whyHere: "",
    whyHereTag: "",
    lookingFor: "",
    lookingForTag: "",
    politicalBeliefs: "",
    politicalBeliefsTag: "",
    controversialBelief: "",
    controversialBeliefTag: "",
    telegram: "",
    twitter: "",
    email: "",
  })

  // Handle input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  // Validate form
  useEffect(() => {
    const errors: string[] = []

    // Check photos
    if (photos.length < 3) {
      errors.push("At least 3 photos are required")
    }

    // Check required fields based on the active tab
    if (activeTab === "basics") {
      if (!formData.name) errors.push("Name is required")
      if (!formData.bio) errors.push("Bio is required")
      if (!formData.bioTag) errors.push("Bio tag is required")
    } else if (activeTab === "details") {
      if (!formData.whyHere) errors.push("Why I'm Here is required")
      if (!formData.whyHereTag) errors.push("Why I'm Here tag is required")
      if (!formData.lookingFor) errors.push("What I'm Looking For is required")
      if (!formData.lookingForTag) errors.push("What I'm Looking For tag is required")
    }

    setValidationErrors(errors)
    setFormValid(errors.length === 0)
  }, [photos, activeTab, formData])

  // Add a new external link
  const addExternalLink = () => {
    setExternalLinks([...externalLinks, { title: "", url: "", description: "" }])
  }

  // Remove an external link
  const removeExternalLink = (index: number) => {
    const newLinks = [...externalLinks]
    newLinks.splice(index, 1)
    setExternalLinks(newLinks)

    // Remove any errors for this link
    const newLinkErrors = { ...linkErrors }
    delete newLinkErrors[index]
    setLinkErrors(newLinkErrors)
  }

  // Update an external link
  const updateExternalLink = (index: number, field: "title" | "url" | "description", value: string) => {
    const newLinks = [...externalLinks]
    newLinks[index] = { ...newLinks[index], [field]: value }

    // Validate URL
    if (field === "url") {
      const newLinkErrors = { ...linkErrors }
      if (value && !isValidUrl(value)) {
        newLinkErrors[index] = "Please enter a valid URL (include http:// or https://)"
      } else {
        delete newLinkErrors[index]
      }
      setLinkErrors(newLinkErrors)
    }

    setExternalLinks(newLinks)
  }

  // Handle tab change with scroll to top
  const handleTabChange = (newTab: string) => {
    setActiveTab(newTab)
    // Scroll to top when changing tabs
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (!user) {
      setError("You must be signed in to create a profile")
      router.push("/new/signin")
      return
    }

    // Validate photos
    if (photos.length < 3) {
      setError("Please upload at least 3 photos")
      setActiveTab("basics") // Switch to the photos tab
      return
    }

    // Check required fields
    const requiredFields: (keyof ProfileFormData)[] = [
      "name",
      "bio",
      "bioTag",
      "whyHere",
      "whyHereTag",
      "lookingFor",
      "lookingForTag",
    ]

    const missingFields = requiredFields.filter((field) => !formData[field])

    if (missingFields.length > 0) {
      // Determine which tab has the missing field
      if (["name", "bio", "bioTag"].some((field) => missingFields.includes(field as keyof ProfileFormData))) {
        setActiveTab("basics")
      } else {
        setActiveTab("details")
      }

      setError("Please fill in all required fields")
      return
    }

    setIsSubmitting(true)
    setError(null)
    setSuccess(null)

    try {
      // Show immediate feedback
      setSuccess("Creating your profile...")

      const profileData = {
        name: formData.name,
        categoryTags: selectedCategoryTags,
        bio: formData.bio,
        bioTag: formData.bioTag,
        whyHere: formData.whyHere,
        whyHereTag: formData.whyHereTag,
        lookingFor: formData.lookingFor,
        lookingForTag: formData.lookingForTag,
        politicalBeliefs: formData.politicalBeliefs || "",
        politicalBeliefsTag: formData.politicalBeliefsTag || "",
        controversialBelief: formData.controversialBelief || "",
        controversialBeliefTag: formData.controversialBeliefTag || "",
        contactInfo: {
          telegram: formData.telegram || "",
          twitter: formData.twitter || "",
          email: formData.email || "",
        },
        photos: photos,
        externalLinks: externalLinks,
      }

      // Create the profile with user ID
      const createdProfile = await createProfile(profileData, user.uid)

      // Show success message
      setSuccess("Profile created successfully!")

      // Check if user should be redirected to messaging after profile creation
      const redirectAfterProfile = sessionStorage.getItem("redirectAfterProfile")
      if (redirectAfterProfile) {
        sessionStorage.removeItem("redirectAfterProfile")
        router.push(redirectAfterProfile)
        return
      }

      // Navigate to home page after a short delay
      setTimeout(() => {
        router.push("/")
      }, 1500)
    } catch (error) {
      console.error("Error creating profile:", error)
      setError(`Failed to create profile: ${error instanceof Error ? error.message : "Unknown error"}`)
    } finally {
      setIsSubmitting(false)
    }
  }

  const toggleCategoryTag = (tag: string) => {
    if (selectedCategoryTags.includes(tag)) {
      setSelectedCategoryTags(selectedCategoryTags.filter((t) => t !== tag))
    } else {
      setSelectedCategoryTags([...selectedCategoryTags, tag])
    }
  }

  // Category tag color mapping
  const getCategoryTagColor = (tag: string, isSelected: boolean) => {
    const politicalTags = CATEGORY_TAGS.POLITICAL
    const occupationTags = CATEGORY_TAGS.OCCUPATION
    const interestTags = CATEGORY_TAGS.INTERESTS

    const baseClasses = "px-2 py-1 text-xs rounded-full border transition-all cursor-pointer"

    if (politicalTags.includes(tag)) {
      return isSelected
        ? `${baseClasses} bg-purple-500 text-white border-purple-500`
        : `${baseClasses} bg-purple-500/10 text-purple-300 border-purple-500/30 hover:bg-purple-500/20`
    } else if (occupationTags.includes(tag)) {
      return isSelected
        ? `${baseClasses} bg-purple-500 text-white border-purple-500`
        : `${baseClasses} bg-purple-500/10 text-purple-300 border-purple-500/30 hover:bg-purple-500/20`
    } else if (interestTags.includes(tag)) {
      return isSelected
        ? `${baseClasses} bg-purple-500 text-white border-purple-500`
        : `${baseClasses} bg-purple-500/10 text-purple-300 border-purple-500/30 hover:bg-purple-500/20`
    }
    return isSelected
      ? `${baseClasses} bg-purple-500 text-white border-purple-500`
      : `${baseClasses} bg-zinc-700/50 text-zinc-300 border-zinc-600/30 hover:bg-zinc-700`
  }

  // Simplified tag selection by category
  const renderTagSection = (category: "POLITICAL" | "OCCUPATION" | "INTERESTS" | "ORGANIZATION", title: string) => {
    return (
      <div className="mb-3">
        <h4 className="text-purple-400 text-xs font-medium mb-1">{title}</h4>
        <div className="flex flex-wrap gap-1.5">
          {CATEGORY_TAGS[category].map((tag) => (
            <span
              key={tag}
              onClick={() => toggleCategoryTag(tag)}
              className={getCategoryTagColor(tag, selectedCategoryTags.includes(tag))}
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    )
  }

  // Function to validate URL format
  const isValidUrl = (url: string) => {
    try {
      new URL(url)
      return true
    } catch (e) {
      return false
    }
  }

  return (
    <AuthGuard>
      <HalftoneWaves />
      <TopNav />

      <div className="min-h-screen pb-8 pt-28 px-4 max-w-md mx-auto">
        <Button variant="ghost" size="sm" className="text-white mb-4" onClick={() => router.push("/")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>

        {!user && (
          <Alert className="mb-4 bg-amber-900/20 border-amber-800 text-amber-300">
            <Info className="h-4 w-4 mr-2" />
            <AlertDescription>You must be signed in to create a profile.</AlertDescription>
          </Alert>
        )}

        {error && (
          <Alert className="mb-4 bg-red-900/20 border-red-800 text-red-300">
            <AlertCircle className="h-4 w-4 mr-2" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-4 bg-green-900/20 border-green-800 text-green-300">
            <CheckCircle className="h-4 w-4 mr-2" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <Card className="rounded-3xl overflow-hidden bg-black/90 backdrop-blur-md border-0 shadow-xl card-extruded-matte">
            <CardHeader className="border-b border-zinc-800">
              <CardTitle className="text-center text-white">Create Your Profile</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              {validationErrors.length > 0 && (
                <Alert className="mb-4 bg-amber-900/20 border-amber-800 text-amber-300">
                  <AlertCircle className="h-4 w-4 mr-2" />
                  <AlertDescription>
                    <div className="font-medium mb-1">Please fix the following issues:</div>
                    <ul className="list-disc pl-5 space-y-1">
                      {validationErrors.map((error, index) => (
                        <li key={index}>{error}</li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-4" noValidate>
                <Tabs defaultValue="basics" className="w-full" onValueChange={handleTabChange} value={activeTab}>
                  <TabsList className="grid grid-cols-3 mb-4">
                    <TabsTrigger value="basics">Basics</TabsTrigger>
                    <TabsTrigger value="details">Details</TabsTrigger>
                    <TabsTrigger value="optional">Optional</TabsTrigger>
                  </TabsList>

                  <TabsContent value="basics" className="space-y-4" data-tab="basics">
                    {/* Photos section */}
                    <div className="space-y-2">
                      <Label className="text-zinc-300 text-lg font-medium flex items-center">
                        Profile Photos <span className="text-amber-400 ml-1">*</span>
                      </Label>
                      <ProfilePhotoUpload
                        initialPhotos={photos}
                        onPhotosChange={setPhotos}
                        maxPhotos={3}
                        minPhotos={3}
                        id="photo-upload-trigger"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-zinc-300">
                        Name or Alias <span className="text-amber-400">*</span>
                      </Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        className="bg-zinc-800/70 border-zinc-700 text-white placeholder:text-zinc-500 rounded-xl"
                        placeholder="Your name"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bio" className="text-zinc-300">
                        Who I Am <span className="text-amber-400">*</span>
                      </Label>
                      <Textarea
                        id="bio"
                        name="bio"
                        value={formData.bio}
                        onChange={handleInputChange}
                        className="bg-zinc-800/70 border-zinc-700 text-white placeholder:text-zinc-500 min-h-[80px] rounded-xl"
                        placeholder="A short bio about yourself"
                      />
                      <p className="text-xs text-zinc-500 italic">
                        Line breaks will be preserved when your profile is viewed.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bioTag" className="text-zinc-300 text-sm flex items-center">
                        <span className="text-purple-400 mr-2">✦</span> Summarize in 2-4 words
                        <span className="text-amber-400 ml-1">*</span>
                      </Label>
                      <Input
                        id="bioTag"
                        name="bioTag"
                        value={formData.bioTag}
                        onChange={handleInputChange}
                        maxLength={30}
                        className="bg-zinc-800/70 border-zinc-700 text-white placeholder:text-zinc-500 rounded-xl"
                        placeholder="e.g., Crypto Builder"
                      />
                    </div>

                    <div className="flex justify-end">
                      <Button
                        type="button"
                        onClick={() => handleTabChange("details")}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        Next <ArrowLeft className="ml-2 h-4 w-4 rotate-180" />
                      </Button>
                    </div>
                  </TabsContent>

                  <TabsContent value="details" className="space-y-4" data-tab="details">
                    <div className="space-y-2">
                      <Label htmlFor="whyHere" className="text-zinc-300">
                        Why I'm Here <span className="text-amber-400">*</span>
                      </Label>
                      <Textarea
                        id="whyHere"
                        name="whyHere"
                        value={formData.whyHere}
                        onChange={handleInputChange}
                        className="bg-zinc-800/70 border-zinc-700 text-white placeholder:text-zinc-500 min-h-[80px] rounded-xl"
                        placeholder="Why you're attending"
                      />
                      <p className="text-xs text-zinc-500 italic">
                        Line breaks will be preserved when your profile is viewed.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="whyHereTag" className="text-zinc-300 text-sm flex items-center">
                        <span className="text-purple-400 mr-2">✦</span> Summarize in 2-4 words
                        <span className="text-amber-400 ml-1">*</span>
                      </Label>
                      <Input
                        id="whyHereTag"
                        name="whyHereTag"
                        value={formData.whyHereTag}
                        onChange={handleInputChange}
                        maxLength={30}
                        className="bg-zinc-800/70 border-zinc-700 text-white placeholder:text-zinc-500 rounded-xl"
                        placeholder="e.g., Network Growth"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="lookingFor" className="text-zinc-300">
                        What I'm Looking For <span className="text-amber-400">*</span>
                      </Label>
                      <Textarea
                        id="lookingFor"
                        name="lookingFor"
                        value={formData.lookingFor}
                        onChange={handleInputChange}
                        className="bg-zinc-800/70 border-zinc-700 text-white placeholder:text-zinc-500 min-h-[80px] rounded-xl"
                        placeholder="What you hope to find or achieve"
                      />
                      <p className="text-xs text-zinc-500 italic">
                        Line breaks will be preserved when your profile is viewed.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="lookingForTag" className="text-zinc-300 text-sm flex items-center">
                        <span className="text-purple-400 mr-2">✦</span> Summarize in 2-4 words
                        <span className="text-amber-400">*</span>
                      </Label>
                      <Input
                        id="lookingForTag"
                        name="lookingForTag"
                        value={formData.lookingForTag}
                        onChange={handleInputChange}
                        maxLength={30}
                        className="bg-zinc-800/70 border-zinc-700 text-white placeholder:text-zinc-500 rounded-xl"
                        placeholder="e.g., DeFi Partners"
                      />
                    </div>

                    <div className="space-y-3">
                      <Label className="text-zinc-300 mb-2 block">
                        Select Tags <span className="text-zinc-500 text-xs">(Select all that apply)</span>
                      </Label>

                      {renderTagSection("POLITICAL", "Political")}
                      {renderTagSection("OCCUPATION", "Occupation")}
                      {renderTagSection("INTERESTS", "Interests")}

                      <div className="mb-3">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="text-purple-400 text-xs font-medium">Organization</h4>
                          <div className="text-zinc-500 text-xs">(For members & scholarship recipients)</div>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {CATEGORY_TAGS.ORGANIZATION.map((tag) => (
                            <span
                              key={tag}
                              onClick={() => toggleCategoryTag(tag)}
                              className={
                                tag === "Students for Liberty"
                                  ? selectedCategoryTags.includes(tag)
                                    ? "px-2 py-1 text-xs rounded-full border transition-all cursor-pointer bg-white text-black border-white flex items-center gap-1"
                                    : "px-2 py-1 text-xs rounded-full border transition-all cursor-pointer bg-white/10 text-white border-white/30 hover:bg-white/20 flex items-center gap-1"
                                  : getCategoryTagColor(tag, selectedCategoryTags.includes(tag))
                              }
                            >
                              {tag === "Students for Liberty" && (
                                <img
                                  src="/images/sfl.png"
                                  alt="Students for Liberty"
                                  className="w-3 h-3 rounded-full"
                                />
                              )}
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>

                      {selectedCategoryTags.length > 0 && (
                        <div className="p-3 bg-purple-900/10 rounded-xl border border-purple-800/20">
                          <div className="flex justify-between items-center mb-1">
                            <h4 className="text-purple-300 text-xs font-medium">Selected Tags</h4>
                            <button
                              type="button"
                              onClick={() => setSelectedCategoryTags([])}
                              className="text-purple-400 hover:text-purple-300 text-xs"
                            >
                              Clear All
                            </button>
                          </div>
                          <div className="flex flex-wrap gap-1.5">
                            {selectedCategoryTags.map((tag) => (
                              <div
                                key={tag}
                                className="flex items-center bg-purple-600/30 text-purple-200 text-xs px-2 py-0.5 rounded-full border border-purple-500/30"
                              >
                                {tag}
                                <button
                                  type="button"
                                  onClick={() => toggleCategoryTag(tag)}
                                  className="ml-1 text-purple-300 hover:text-white"
                                >
                                  <X size={12} />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="flex justify-between">
                      <Button
                        type="button"
                        onClick={() => handleTabChange("basics")}
                        variant="outline"
                        className="border-zinc-700 text-zinc-300"
                      >
                        <ArrowLeft className="mr-2 h-4 w-4" /> Back
                      </Button>
                      <Button
                        type="button"
                        onClick={() => handleTabChange("optional")}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        Next <ArrowLeft className="ml-2 h-4 w-4 rotate-180" />
                      </Button>
                    </div>
                  </TabsContent>

                  <TabsContent value="optional" className="space-y-4" data-tab="optional">
                    {/* External Links Section */}
                    <div className="space-y-4 pt-2">
                      <div className="flex justify-between items-center">
                        <Label className="text-zinc-300">External Links (Optional)</Label>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={addExternalLink}
                          className="text-purple-300 border-purple-700 hover:bg-purple-900/30"
                        >
                          <Plus size={16} className="mr-1" /> Add Link
                        </Button>
                      </div>

                      {externalLinks.length > 0 ? (
                        <div className="space-y-4">
                          {externalLinks.map((link, index) => (
                            <div
                              key={index}
                              className="p-4 bg-zinc-800/50 rounded-xl border border-zinc-700/50 space-y-3"
                            >
                              <div className="flex justify-between items-start">
                                <div className="flex items-center">
                                  <LinkIcon size={16} className="text-purple-400 mr-2" />
                                  <span className="text-zinc-300 text-sm">Link #{index + 1}</span>
                                </div>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => removeExternalLink(index)}
                                  className="text-red-400 hover:text-red-300 hover:bg-red-900/20 p-1 h-auto"
                                >
                                  <Trash2 size={16} />
                                </Button>
                              </div>

                              <div className="space-y-3">
                                <div>
                                  <Label htmlFor={`link-title-${index}`} className="text-zinc-400 text-xs">
                                    Title
                                  </Label>
                                  <Input
                                    id={`link-title-${index}`}
                                    value={link.title}
                                    onChange={(e) => updateExternalLink(index, "title", e.target.value)}
                                    className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500 rounded-lg mt-1"
                                    placeholder="e.g., My Washington Post Article"
                                  />
                                </div>

                                <div>
                                  <Label htmlFor={`link-url-${index}`} className="text-zinc-400 text-xs">
                                    URL
                                  </Label>
                                  <Input
                                    id={`link-url-${index}`}
                                    value={link.url}
                                    onChange={(e) => updateExternalLink(index, "url", e.target.value)}
                                    className={`bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500 rounded-lg mt-1 ${
                                      linkErrors[index] ? "border-red-500" : ""
                                    }`}
                                    placeholder="https://example.com/my-article"
                                  />
                                  {linkErrors[index] && (
                                    <p className="text-red-400 text-xs mt-1">{linkErrors[index]}</p>
                                  )}
                                </div>

                                <div>
                                  <Label htmlFor={`link-description-${index}`} className="text-zinc-400 text-xs">
                                    Description (Optional)
                                  </Label>
                                  <Textarea
                                    id={`link-description-${index}`}
                                    value={link.description || ""}
                                    onChange={(e) => updateExternalLink(index, "description", e.target.value)}
                                    className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500 rounded-lg mt-1 min-h-[60px]"
                                    placeholder="A brief description of this link"
                                  />
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center p-4 bg-zinc-800/30 rounded-xl border border-dashed border-zinc-700/50">
                          <LinkIcon size={24} className="text-zinc-500 mx-auto mb-2" />
                          <p className="text-zinc-500 text-sm">No external links added yet</p>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={addExternalLink}
                            className="mt-2 text-purple-300 border-purple-700 hover:bg-purple-900/30"
                          >
                            <Plus size={16} className="mr-1" /> Add Link
                          </Button>
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="politicalBeliefs" className="text-zinc-300">
                        Beliefs (Optional)
                      </Label>
                      <Textarea
                        id="politicalBeliefs"
                        name="politicalBeliefs"
                        value={formData.politicalBeliefs}
                        onChange={handleInputChange}
                        className="bg-zinc-800/70 border-zinc-700 text-white placeholder:text-zinc-500 min-h-[80px] rounded-xl"
                        placeholder="Your beliefs or values"
                      />
                      <p className="text-xs text-zinc-500 italic">
                        Line breaks will be preserved when your profile is viewed.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="politicalBeliefsTag" className="text-zinc-300 text-sm flex items-center">
                        <span className="text-purple-400 mr-2">✦</span> Summarize in 2-4 words
                      </Label>
                      <Input
                        id="politicalBeliefsTag"
                        name="politicalBeliefsTag"
                        value={formData.politicalBeliefsTag}
                        onChange={handleInputChange}
                        maxLength={30}
                        className="bg-zinc-800/70 border-zinc-700 text-white placeholder:text-zinc-500 rounded-xl"
                        placeholder="e.g., Ancap Agorist"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="controversialBelief" className="text-zinc-300">
                        Most Controversial Belief (Optional)
                      </Label>
                      <Textarea
                        id="controversialBelief"
                        name="controversialBelief"
                        value={formData.controversialBelief}
                        onChange={handleInputChange}
                        className="bg-zinc-800/70 border-zinc-700 text-white placeholder:text-zinc-500 min-h-[80px] rounded-xl"
                        placeholder="A belief that might be controversial"
                      />
                      <p className="text-xs text-zinc-500 italic">
                        Line breaks will be preserved when your profile is viewed.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="controversialBeliefTag" className="text-zinc-300 text-sm flex items-center">
                        <span className="text-purple-400 mr-2">✦</span> Summarize in 2-4 words
                      </Label>
                      <Input
                        id="controversialBeliefTag"
                        name="controversialBeliefTag"
                        value={formData.controversialBeliefTag}
                        onChange={handleInputChange}
                        maxLength={30}
                        className="bg-zinc-800/70 border-zinc-700 text-white placeholder:text-zinc-500 rounded-xl"
                        placeholder="e.g., Taxation Theft"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-zinc-300">Contact Info (Optional)</Label>
                      <div className="grid grid-cols-2 gap-2">
                        <Input
                          id="telegram"
                          name="telegram"
                          value={formData.telegram}
                          onChange={handleInputChange}
                          className="bg-zinc-800/70 border-zinc-700 text-white placeholder:text-zinc-500 rounded-xl"
                          placeholder="Telegram @username"
                        />
                        <Input
                          id="twitter"
                          name="twitter"
                          value={formData.twitter}
                          onChange={handleInputChange}
                          className="bg-zinc-800/70 border-zinc-700 text-white placeholder:text-zinc-500 rounded-xl"
                          placeholder="X/Twitter @username"
                        />
                      </div>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="bg-zinc-800/70 border-zinc-700 text-white placeholder:text-zinc-500 rounded-xl"
                        placeholder="Email: your@email.com"
                      />
                    </div>

                    <div className="flex justify-between">
                      <Button
                        type="button"
                        onClick={() => handleTabChange("details")}
                        variant="outline"
                        className="border-zinc-700 text-zinc-300"
                      >
                        <ArrowLeft className="mr-2 h-4 w-4" /> Back
                      </Button>
                      <Button
                        type="submit"
                        className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-medium"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Creating...
                          </>
                        ) : (
                          "Create Profile"
                        )}
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </form>
            </CardContent>
            <CardFooter className="border-t border-zinc-800 p-4">
              <div className="w-full text-center text-xs text-zinc-500">
                <span className="text-amber-400">*</span> Required fields
              </div>
            </CardFooter>
          </Card>
        </motion.div>
      </div>
    </AuthGuard>
  )
}
