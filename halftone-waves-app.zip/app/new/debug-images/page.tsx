"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { getProfilesByUserId } from "@/lib/firebase/db"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ImageDebugger } from "@/components/image-debugger"
import HalftoneWaves from "@/components/halftone-waves"
import { TopNav } from "@/components/top-nav"
import { BottomNav } from "@/components/bottom-nav"
import { Loader2 } from "lucide-react"

export default function DebugImagesPage() {
  const { user } = useAuth()
  const [loading, setLoading] = useState(true)
  const [profileImages, setProfileImages] = useState<string[]>([])
  const [customUrl, setCustomUrl] = useState("")
  const [testUrls, setTestUrls] = useState<string[]>([])

  useEffect(() => {
    const fetchUserImages = async () => {
      if (user?.uid) {
        try {
          const profiles = await getProfilesByUserId(user.uid)
          if (profiles && profiles.length > 0) {
            const allImages = profiles.flatMap((profile) => profile.photos || [])
            setProfileImages(allImages)
          }
        } catch (error) {
          console.error("Error fetching user profile images:", error)
        }
      }
      setLoading(false)
    }

    fetchUserImages()
  }, [user])

  const handleAddCustomUrl = () => {
    if (customUrl && !testUrls.includes(customUrl)) {
      setTestUrls([...testUrls, customUrl])
      setCustomUrl("")
    }
  }

  return (
    <>
      <HalftoneWaves />
      <TopNav />

      <div className="min-h-screen flex flex-col pb-28 pt-28 px-4">
        <div className="w-full max-w-md mx-auto">
          <h1 className="text-2xl font-bold text-white mb-6">Image Loading Debugger</h1>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Add Custom URL to Test</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Input
                  value={customUrl}
                  onChange={(e) => setCustomUrl(e.target.value)}
                  placeholder="Paste image URL to test"
                  className="bg-zinc-800/70 border-zinc-700 text-white"
                />
                <Button onClick={handleAddCustomUrl}>Add</Button>
              </div>
            </CardContent>
          </Card>

          {loading ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
            </div>
          ) : (
            <>
              {testUrls.length > 0 && (
                <div className="mb-6">
                  <h2 className="text-lg font-medium text-white mb-3">Custom URLs</h2>
                  {testUrls.map((url, index) => (
                    <ImageDebugger key={`custom-${index}`} imageUrl={url} />
                  ))}
                </div>
              )}

              {profileImages.length > 0 ? (
                <div>
                  <h2 className="text-lg font-medium text-white mb-3">Your Profile Images</h2>
                  {profileImages.map((url, index) => (
                    <ImageDebugger key={`profile-${index}`} imageUrl={url} />
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="p-6 text-center text-zinc-400">
                    No profile images found. Add a custom URL to test image loading.
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </div>
      </div>

      <BottomNav />
    </>
  )
}
