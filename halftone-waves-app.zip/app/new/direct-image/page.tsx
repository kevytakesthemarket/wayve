export default function DirectImagePage() {
  const imageUrl =
    "https://firebasestorage.googleapis.com/v0/b/wayve-freedomfest.firebasestorage.app/o/profiles%2FJTz0lryHfyZ9DzDD3hdTcI2iNxL2%2Fphotos%2F1747889490441_b0z40vrb_IMG_4650.jpeg?alt=media"

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Direct Image Display</h1>

      <div className="border rounded-lg p-4 mb-4">
        <img
          src={imageUrl || "/placeholder.svg"}
          alt="Direct Firebase Storage Image"
          className="max-w-full h-auto rounded-lg"
        />
      </div>

      <div className="mt-4 p-4 bg-gray-100 rounded-lg overflow-auto">
        <p className="text-sm break-all">{imageUrl}</p>
      </div>
    </div>
  )
}
