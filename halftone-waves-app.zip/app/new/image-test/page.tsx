"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import HalftoneWaves from "@/components/halftone-waves"
import { TopNav } from "@/components/top-nav"
import { BottomNav } from "@/components/bottom-nav"

export default function ImageTestPage() {
  // The Firebase Storage image URL
  const imageUrl =
    "https://firebasestorage.googleapis.com/v0/b/wayve-freedomfest.firebasestorage.app/o/profiles%2FJTz0lryHfyZ9DzDD3hdTcI2iNxL2%2Fphotos%2F1747889490441_b0z40vrb_IMG_4650.jpeg?alt=media&token=a0f53f5a-dbe9-425b-955c-d2e939a20514"

  return (
    <>
      <HalftoneWaves />
      <TopNav />

      <div className="min-h-screen flex flex-col pb-28 pt-28 px-4">
        <div className="w-full max-w-md mx-auto">
          <Card className="overflow-hidden">
            <CardHeader>
              <CardTitle>Firebase Storage Image</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg overflow-hidden bg-zinc-800 flex items-center justify-center p-4">
                {/* Just a simple image tag with the URL */}
                <img
                  src={imageUrl || "/placeholder.svg"}
                  alt="Firebase Storage Image"
                  className="max-w-full max-h-full object-contain"
                />
              </div>

              <div className="text-sm text-zinc-400 mt-2">
                <p className="font-medium mb-1">Image URL:</p>
                <div className="bg-zinc-800 p-2 rounded text-xs break-all">{imageUrl}</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <BottomNav />
    </>
  )
}
