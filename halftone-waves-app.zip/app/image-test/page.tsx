"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Loader2 } from "lucide-react"

export default function ImageTestRedirectPage() {
  const router = useRouter()

  useEffect(() => {
    router.replace("/new/image-test")
  }, [router])

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-purple-500" />
        <p className="text-zinc-400">Redirecting to image test page...</p>
      </div>
    </div>
  )
}
