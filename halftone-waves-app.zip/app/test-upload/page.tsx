"use client"

import type React from "react"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useState, useRef } from "react"
import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage"
import { storage } from "@/lib/firebase"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Loader2, CheckCircle, AlertCircle, Upload, ImageIcon } from "lucide-react"
import HalftoneWaves from "@/components/halftone-waves"
import { TopNav } from "@/components/top-nav"

export default function TestUploadPage() {
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const router = useRouter()

  useEffect(() => {
    // Redirect to the new test upload page after a short delay
    const timer = setTimeout(() => {
      router.replace("/new/test-upload")
    }, 3000)

    return () => clearTimeout(timer)
  }, [router])

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !e.target.files.length) return

    const file = e.target.files[0]
    setUploading(true)
    setUploadProgress(0)
    setError(null)
    setUploadedImageUrl(null)

    try {
      // Create a unique filename
      const timestamp = Date.now()
      const randomId = Math.random().toString(36).substring(2, 10)
      const safeFileName = file.name.replace(/[^a-zA-Z0-9.]/g, "_").substring(0, 30)
      const filename = `${timestamp}_${randomId}_${safeFileName}`

      // Set the storage path - using a public test folder
      const storagePath = `test-uploads/${filename}`
      console.log(`Uploading file to: ${storagePath}`)

      // Create a reference to the storage location
      const storageRef = ref(storage, storagePath)

      // Create the upload task with resumable upload
      const uploadTask = uploadBytesResumable(storageRef, file)

      // Monitor upload progress
      uploadTask.on(
        "state_changed",
        (snapshot) => {
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100
          console.log(`Upload progress: ${progress.toFixed(2)}%`)
          setUploadProgress(progress)
        },
        (error) => {
          console.error("Upload error:", error)
          setError(`Upload failed: ${error.message}`)
          setUploading(false)
        },
        async () => {
          try {
            // Get the download URL
            const downloadURL = await getDownloadURL(uploadTask.snapshot.ref)
            console.log("Upload completed. Download URL:", downloadURL)
            setUploadedImageUrl(downloadURL)
            setUploading(false)
          } catch (error: any) {
            console.error("Error getting download URL:", error)
            setError(`Upload completed but failed to get download URL: ${error.message}`)
            setUploading(false)
          }
        },
      )
    } catch (error: any) {
      console.error("Error in handleFileChange:", error)
      setError(`Failed to upload image: ${error.message}`)
      setUploading(false)
    }
  }

  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click()
    }
  }

  return (
    <>
      <HalftoneWaves />
      <TopNav />

      <div className="min-h-screen flex items-center justify-center px-4 py-24">
        <Card className="w-full max-w-md rounded-3xl overflow-hidden bg-black/90 backdrop-blur-md border-0 shadow-xl card-extruded-matte">
          <CardHeader className="border-b border-zinc-800">
            <CardTitle className="text-center text-white">Firebase Storage Test</CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            <div className="text-center">
              <p className="text-zinc-300 mb-4">Test Firebase storage by uploading an image without authentication.</p>

              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/jpeg,image/png,image/webp,image/gif"
                className="hidden"
              />

              <Button
                onClick={triggerFileInput}
                disabled={uploading}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 rounded-xl"
              >
                {uploading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" />
                    Select & Upload Image
                  </>
                )}
              </Button>
            </div>

            {uploading && (
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-zinc-400">
                  <span>Uploading...</span>
                  <span>{Math.round(uploadProgress)}%</span>
                </div>
                <Progress value={uploadProgress} className="h-2" />
              </div>
            )}

            {error && (
              <Alert className="bg-red-900/20 border-red-800 text-red-300">
                <AlertCircle className="h-4 w-4 mr-2" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {uploadedImageUrl && (
              <div className="space-y-4">
                <Alert className="bg-green-900/20 border-green-800 text-green-300">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  <AlertDescription>Image uploaded successfully!</AlertDescription>
                </Alert>

                <div className="space-y-2">
                  <p className="text-zinc-400 text-sm">Image URL:</p>
                  <div className="bg-zinc-800/50 p-2 rounded-md text-zinc-300 text-xs break-all">
                    {uploadedImageUrl}
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-zinc-400 text-sm">Preview:</p>
                  <div className="bg-zinc-800/50 p-2 rounded-md flex justify-center">
                    <img
                      src={uploadedImageUrl || "/placeholder.svg"}
                      alt="Uploaded image"
                      className="max-h-60 rounded-md"
                      onError={(e) => {
                        e.currentTarget.src = "/placeholder.svg"
                        console.error("Error loading image preview")
                      }}
                    />
                  </div>
                </div>
              </div>
            )}

            {!uploading && !uploadedImageUrl && !error && (
              <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-zinc-700 rounded-xl">
                <ImageIcon className="h-12 w-12 text-zinc-600 mb-2" />
                <p className="text-zinc-500 text-center">No image uploaded yet</p>
              </div>
            )}
          </CardContent>
          <CardFooter className="border-t border-zinc-800 p-4">
            <div className="w-full text-center text-xs text-zinc-500">
              This test uploads directly to Firebase Storage without authentication
            </div>
          </CardFooter>
        </Card>
      </div>
    </>
  )
}
