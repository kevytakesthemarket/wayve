"use client"

import { ConversationList } from "@/components/conversation-list"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TopNav } from "@/components/top-nav"
import { BottomNav } from "@/components/bottom-nav"
import HalftoneWaves from "@/components/halftone-waves"

export default function MessagesPage() {
  return (
    <div className="min-h-screen bg-black text-white relative">
      {/* Halftone Background */}
      <div className="fixed inset-0 z-0">
        <HalftoneWaves />
      </div>

      {/* Top Navigation */}
      <TopNav />

      {/* Main Content with proper margins */}
      <div className="relative z-10 container mx-auto px-4 pt-24 pb-32">
        <Card className="bg-zinc-900/90 border-zinc-800 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-zinc-100 flex items-center gap-2">
              <span>Messages</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ConversationList />
          </CardContent>
        </Card>
      </div>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  )
}
