"use client"

import type React from "react"

import { useEffect, useState, useRef } from "react"
import { useParams, useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { subscribeToMessages, sendMessage, markMessagesAsRead, createOrGetConversation } from "@/lib/firebase/messaging"
import { getProfileFromFirestore, getProfilesByUserId } from "@/lib/firebase/db"
import type { Message } from "@/types/message"
import type { Profile } from "@/types/profile"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Send, User, MessageCircle, ExternalLink } from "lucide-react"
import { cn } from "@/lib/utils"
import { BottomNav } from "@/components/bottom-nav"

export default function ChatPage() {
  const params = useParams()
  const router = useRouter()
  const { user } = useAuth()
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [otherUserProfile, setOtherUserProfile] = useState<Profile | null>(null)
  const [conversationId, setConversationId] = useState<string | null>(null)
  const [userHasProfile, setUserHasProfile] = useState<boolean | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const otherUserId = params.userId as string

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    // Use setTimeout to ensure DOM has updated
    setTimeout(() => {
      if (messagesEndRef.current) {
        messagesEndRef.current.scrollIntoView({ behavior: "smooth", block: "end" })
      }
      // Fallback for mobile - scroll the messages container to bottom
      const messagesContainer = document.querySelector(".messages-container")
      if (messagesContainer) {
        messagesContainer.scrollTop = messagesContainer.scrollHeight
      }
    }, 100)
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // Check if current user has a profile
  useEffect(() => {
    const checkUserProfile = async () => {
      if (!user?.uid) {
        setUserHasProfile(null)
        return
      }

      try {
        const profiles = await getProfilesByUserId(user.uid)
        setUserHasProfile(profiles.length > 0)
      } catch (error) {
        console.error("Error checking user profile:", error)
        setUserHasProfile(false)
      }
    }

    checkUserProfile()
  }, [user?.uid])

  // Fetch other user's profile immediately (even before user is signed in)
  useEffect(() => {
    const fetchOtherUserProfile = async () => {
      try {
        console.log(`🔍 Fetching profile for user: ${otherUserId}`)

        // Try to get profile by document ID first
        let profile = await getProfileFromFirestore(otherUserId)

        if (!profile) {
          console.log(`❌ No profile found with document ID ${otherUserId}`)
          // If it's a Firebase Auth UID, try to find by userId field
          if (otherUserId.length > 20) {
            console.log(`🔍 Trying to find profile by userId field...`)
            const { collection, query, where, getDocs } = await import("firebase/firestore")
            const { db } = await import("@/lib/firebase")

            const profilesCollection = collection(db!, "profiles")
            const q = query(profilesCollection, where("userId", "==", otherUserId))
            const querySnapshot = await getDocs(q)

            if (!querySnapshot.empty) {
              const doc = querySnapshot.docs[0]
              const data = doc.data()
              profile = {
                id: doc.id,
                ...data,
              } as Profile
              console.log(`✅ Found profile by userId field:`, profile)
            }
          }
        } else {
          console.log(`✅ Found profile by document ID:`, profile)
        }

        setOtherUserProfile(profile)
      } catch (error) {
        console.error("❌ Error fetching other user profile:", error)
      }
    }

    if (otherUserId) {
      fetchOtherUserProfile()
    }
  }, [otherUserId])

  // Initialize conversation and messaging (only if signed in and has profile)
  useEffect(() => {
    if (!user?.uid || !otherUserId || userHasProfile === false) {
      setLoading(false)
      return
    }

    const initializeChat = async () => {
      try {
        // Create or get conversation
        const convId = await createOrGetConversation(user.uid, otherUserId)
        setConversationId(convId)
        setLoading(false)
      } catch (error) {
        console.error("Error initializing chat:", error)
        setLoading(false)
      }
    }

    if (userHasProfile === true) {
      initializeChat()
    }
  }, [user?.uid, otherUserId, userHasProfile])

  // Subscribe to messages
  useEffect(() => {
    if (!conversationId) return

    const unsubscribe = subscribeToMessages(conversationId, (newMessages) => {
      setMessages(newMessages)

      // Mark messages as read
      if (user?.uid) {
        markMessagesAsRead(conversationId, user.uid)
      }
    })

    return unsubscribe
  }, [conversationId, user?.uid])

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newMessage.trim() || !user?.uid || sending || !userHasProfile) return

    setSending(true)
    try {
      await sendMessage(user.uid, otherUserId, newMessage.trim())
      setNewMessage("")
      inputRef.current?.focus()
      // Scroll to bottom after sending message
      scrollToBottom()
    } catch (error) {
      console.error("Error sending message:", error)
    } finally {
      setSending(false)
    }
  }

  const formatTimestamp = (timestamp: any) => {
    if (!timestamp) return ""

    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp)
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  // Show sign-in prompt if not authenticated
  if (!user) {
    return (
      <div className="h-screen bg-black text-white flex flex-col">
        {/* Fixed Header */}
        <div className="fixed top-0 left-0 right-0 z-50 bg-zinc-900 border-b border-zinc-800">
          <div className="flex items-center gap-3 p-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => router.back()}
              className="text-zinc-400 hover:text-zinc-200"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>

            {otherUserProfile ? (
              <>
                {otherUserProfile.photos?.[0] ? (
                  <img
                    src={otherUserProfile.photos[0] || "/placeholder.svg"}
                    alt={otherUserProfile.name}
                    className="w-10 h-10 rounded-lg object-cover"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-lg bg-zinc-700 flex items-center justify-center">
                    <User className="h-5 w-5 text-zinc-400" />
                  </div>
                )}
                <div className="flex-1">
                  <h1 className="font-medium text-zinc-100 text-sm">{otherUserProfile.name}</h1>
                  <p className="text-xs text-zinc-400">Sign in to message</p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => router.push(`/${otherUserId}`)}
                  className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 text-xs"
                >
                  <ExternalLink className="h-3 w-3 mr-1" />
                  View Profile
                </Button>
              </>
            ) : (
              <div className="flex items-center gap-3 flex-1">
                <div className="w-10 h-10 rounded-lg bg-zinc-700 animate-pulse" />
                <div className="flex-1">
                  <div className="h-4 w-20 bg-zinc-700 rounded animate-pulse mb-1" />
                  <div className="h-3 w-24 bg-zinc-700 rounded animate-pulse" />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex items-center justify-center p-4 mt-16 mb-20">
          <Card className="bg-zinc-900 border-zinc-800 max-w-md w-full">
            <CardContent className="p-6 text-center">
              <MessageCircle className="h-16 w-16 mx-auto mb-4 text-zinc-600" />
              <h2 className="text-xl font-medium mb-2">Sign in to start messaging</h2>
              <p className="text-zinc-400 mb-6">
                {otherUserProfile ? `Message ${otherUserProfile.name}` : "Start a conversation"}
              </p>
              <div className="space-y-3">
                <Button
                  onClick={() => router.push(`/new/signin?redirect=${encodeURIComponent(window.location.pathname)}`)}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  Sign In
                </Button>
                <Button
                  onClick={() => router.push(`/new/signup?redirect=${encodeURIComponent(window.location.pathname)}`)}
                  variant="outline"
                  className="w-full border-zinc-700 text-zinc-300 hover:bg-zinc-800"
                >
                  Sign Up
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Bottom Navigation */}
        <BottomNav />
      </div>
    )
  }

  // Show profile creation prompt if user doesn't have a profile
  if (userHasProfile === false) {
    return (
      <div className="h-screen bg-black text-white flex flex-col">
        {/* Fixed Header */}
        <div className="fixed top-0 left-0 right-0 z-50 bg-zinc-900 border-b border-zinc-800">
          <div className="flex items-center gap-3 p-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => router.back()}
              className="text-zinc-400 hover:text-zinc-200"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="font-medium text-zinc-100">Complete Your Profile</h1>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex items-center justify-center p-4 mt-16 mb-20">
          <Card className="bg-zinc-900 border-zinc-800 max-w-md w-full">
            <CardContent className="p-6 text-center">
              <User className="h-16 w-16 mx-auto mb-4 text-zinc-600" />
              <h2 className="text-xl font-medium mb-2">Create your profile first</h2>
              <p className="text-zinc-400 mb-6">
                You need to complete your profile before you can message other users.
              </p>
              <Button
                onClick={() => {
                  // Store the message target for after profile creation
                  sessionStorage.setItem(
                    "messageTarget",
                    JSON.stringify({ userId: otherUserId, userName: otherUserProfile?.name || "User" }),
                  )
                  router.push("/new/create?redirect=message")
                }}
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                Create Profile
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Bottom Navigation */}
        <BottomNav />
      </div>
    )
  }

  if (loading || userHasProfile === null) {
    return (
      <div className="h-screen bg-black text-white flex flex-col">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500 mx-auto mb-4"></div>
            <p className="text-zinc-400">Loading conversation...</p>
          </div>
        </div>
        <BottomNav />
      </div>
    )
  }

  return (
    <div className="h-screen bg-black text-white flex flex-col">
      {/* Fixed Header */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-zinc-900 border-b border-zinc-800 h-16">
        <div className="flex items-center gap-3 p-4">
          <Button variant="ghost" size="sm" onClick={() => router.back()} className="text-zinc-400 hover:text-zinc-200">
            <ArrowLeft className="h-4 w-4" />
          </Button>

          {otherUserProfile ? (
            <>
              {otherUserProfile.photos?.[0] ? (
                <img
                  src={otherUserProfile.photos[0] || "/placeholder.svg"}
                  alt={otherUserProfile.name}
                  className="w-10 h-10 rounded-lg object-cover"
                />
              ) : (
                <div className="w-10 h-10 rounded-lg bg-zinc-700 flex items-center justify-center">
                  <User className="h-5 w-5 text-zinc-400" />
                </div>
              )}
              <div className="flex-1">
                <h1 className="font-medium text-zinc-100 text-sm">{otherUserProfile.name}</h1>
                <p className="text-xs text-zinc-400">Active now</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => router.push(`/${otherUserId}`)}
                className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 text-xs"
              >
                <ExternalLink className="h-3 w-3 mr-1" />
                View Profile
              </Button>
            </>
          ) : (
            <div className="flex items-center gap-3 flex-1">
              <div className="w-10 h-10 rounded-lg bg-zinc-700 animate-pulse" />
              <div className="flex-1">
                <div className="h-4 w-20 bg-zinc-700 rounded animate-pulse mb-1" />
                <div className="h-3 w-16 bg-zinc-700 rounded animate-pulse" />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Messages Area - takes remaining space between header and input */}
      <div className="flex-1 overflow-y-auto px-4 pt-16 pb-20 messages-container">
        {messages.length === 0 ? (
          <div className="text-center text-zinc-500 mt-8">
            <MessageCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No messages yet. Start the conversation!</p>
          </div>
        ) : (
          <div className="space-y-4 py-4">
            {messages.map((message) => {
              const isOwn = message.senderId === user.uid

              return (
                <div key={message.id} className={cn("flex", isOwn ? "justify-end" : "justify-start")}>
                  <div
                    className={cn(
                      "max-w-[70%] rounded-lg px-4 py-2",
                      isOwn ? "bg-purple-600 text-white" : "bg-zinc-800 text-zinc-100",
                    )}
                  >
                    <p className="text-sm">{message.content}</p>
                    <p className={cn("text-xs mt-1", isOwn ? "text-purple-200" : "text-zinc-500")}>
                      {formatTimestamp(message.timestamp)}
                    </p>
                  </div>
                </div>
              )
            })}
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Fixed Message Input - Always at bottom, never scrolls */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-zinc-900 border-t border-zinc-800">
        <div className="p-4">
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <Input
              ref={inputRef}
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              className="flex-1 bg-zinc-800 border-zinc-700 text-zinc-100 placeholder-zinc-500"
              disabled={sending || !userHasProfile}
            />
            <Button
              type="submit"
              disabled={!newMessage.trim() || sending || !userHasProfile}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  )
}
