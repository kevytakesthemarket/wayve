"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { AdminAuthGuard } from "@/components/admin-auth-guard"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Copy, Users, MessageCircle, Mail, CheckCircle, Info, GraduationCap } from "lucide-react"
import { getProfiles } from "@/lib/profile-service"
import { getUserConversations } from "@/lib/firebase/messaging"
import type { Profile } from "@/types/profile"
import type { Conversation } from "@/types/message"
import { useAuth } from "@/contexts/auth-context"
import HalftoneWaves from "@/components/halftone-waves"
import { TopNav } from "@/components/top-nav"

export default function AdminPage() {
  const router = useRouter()
  const { user } = useAuth()
  const [allProfiles, setAllProfiles] = useState<Profile[]>([])
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)
  const [activeTab, setActiveTab] = useState("overview")

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)

        // Fetch all profiles from both events
        const [freedomfestProfiles, feeProfiles] = await Promise.all([getProfiles("freedomfest"), getProfiles("fee")])

        const allFetchedProfiles = [...freedomfestProfiles, ...feeProfiles]
        setAllProfiles(allFetchedProfiles)

        // Fetch conversations if user is available
        if (user?.uid) {
          const userConversations = await getUserConversations(user.uid)
          setConversations(userConversations)
        }
      } catch (error) {
        console.error("Error fetching admin data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [user])

  // Separate profiles by event
  const freedomfestProfiles = allProfiles.filter((p) => p.event === "freedomfest")
  const feeProfiles = allProfiles.filter((p) => p.event === "fee")

  // Get profiles with unread messages
  const getProfilesWithUnreadMessages = (eventProfiles: Profile[]) => {
    return eventProfiles.filter((profile) => {
      return conversations.some((conv) => {
        const unreadCount = conv.unreadCount?.[user?.uid || ""] || 0
        return unreadCount > 0 && conv.participants.includes(profile.userId || "")
      })
    })
  }

  const freedomfestUnreadProfiles = getProfilesWithUnreadMessages(freedomfestProfiles)
  const feeUnreadProfiles = getProfilesWithUnreadMessages(feeProfiles)

  // Get all emails from profiles with unread messages
  const getAllEmailsFromUnreadProfiles = (eventProfiles: Profile[]) => {
    const unreadProfiles = getProfilesWithUnreadMessages(eventProfiles)
    return unreadProfiles
      .map((profile) => profile.contactInfo?.email)
      .filter((email): email is string => Boolean(email))
  }

  const freedomfestEmails = getAllEmailsFromUnreadProfiles(freedomfestProfiles)
  const feeEmails = getAllEmailsFromUnreadProfiles(feeProfiles)

  const copyEmailsToClipboard = async (emails: string[], eventName: string) => {
    const emailList = emails.join(", ")
    try {
      await navigator.clipboard.writeText(emailList)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("Failed to copy emails:", err)
    }
  }

  const renderEventSection = (
    eventProfiles: Profile[],
    unreadProfiles: Profile[],
    emails: string[],
    eventName: string,
    eventIcon: React.ReactNode,
  ) => (
    <div className="space-y-6">
      {/* Event Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-zinc-900/50 border-zinc-700">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              {eventIcon}
              <div>
                <p className="text-sm text-zinc-400">Total {eventName} Profiles</p>
                <p className="text-2xl font-bold text-white">{eventProfiles.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900/50 border-zinc-700">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <MessageCircle className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm text-zinc-400">Profiles with Unread Messages</p>
                <p className="text-2xl font-bold text-white">{unreadProfiles.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-zinc-900/50 border-zinc-700">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Mail className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm text-zinc-400">Available Emails</p>
                <p className="text-2xl font-bold text-white">{emails.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Email Copy Section */}
      {emails.length > 0 ? (
        <Card className="bg-zinc-900/50 border-zinc-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Mail className="h-5 w-5" />
              {eventName} Emails for Mass Communication
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="bg-blue-900/20 border-blue-800 text-blue-300">
              <Info className="h-4 w-4" />
              <AlertDescription>
                These are emails from {eventName} attendees who have unread messages. Perfect for follow-up campaigns.
              </AlertDescription>
            </Alert>

            <div className="flex items-center justify-between">
              <span className="text-zinc-400">
                {emails.length} email{emails.length !== 1 ? "s" : ""} ready for copy
              </span>
              <Button
                onClick={() => copyEmailsToClipboard(emails, eventName)}
                className="bg-blue-600 hover:bg-blue-700 text-white"
                disabled={copied}
              >
                {copied ? (
                  <>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="mr-2 h-4 w-4" />
                    Copy All Emails
                  </>
                )}
              </Button>
            </div>

            <div className="bg-zinc-800/50 p-3 rounded-lg max-h-32 overflow-y-auto">
              <p className="text-sm text-zinc-300 font-mono break-all">{emails.join(", ")}</p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="bg-zinc-900/50 border-zinc-700">
          <CardContent className="p-6 text-center">
            <Mail className="h-12 w-12 text-zinc-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-white mb-2">No {eventName} Emails Available</h3>
            <p className="text-zinc-400">
              No {eventName} attendees with unread messages have provided email addresses yet.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Profiles with Unread Messages */}
      {unreadProfiles.length > 0 && (
        <Card className="bg-zinc-900/50 border-zinc-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <MessageCircle className="h-5 w-5" />
              {eventName} Profiles with Unread Messages
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {unreadProfiles.map((profile) => {
                const unreadCount = conversations
                  .filter((conv) => conv.participants.includes(profile.userId || ""))
                  .reduce((total, conv) => total + (conv.unreadCount?.[user?.uid || ""] || 0), 0)

                return (
                  <div key={profile.id} className="flex items-center justify-between p-3 bg-zinc-800/30 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center text-white font-medium">
                        {profile.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="text-white font-medium">{profile.name}</p>
                        <p className="text-zinc-400 text-sm">{profile.contactInfo?.email || "No email"}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary" className="bg-red-900/30 text-red-300">
                        {unreadCount} unread
                      </Badge>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => router.push(`/messages/${profile.userId}`)}
                        className="border-zinc-600 text-zinc-300 hover:bg-zinc-700"
                      >
                        View Chat
                      </Button>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )

  if (loading) {
    return (
      <AdminAuthGuard>
        <HalftoneWaves />
        <TopNav />
        <div className="min-h-screen pt-28 pb-16 px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center py-10">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500 mx-auto mb-4"></div>
              <p className="text-zinc-400">Loading admin dashboard...</p>
            </div>
          </div>
        </div>
      </AdminAuthGuard>
    )
  }

  return (
    <AdminAuthGuard>
      <HalftoneWaves />
      <TopNav />
      <div className="min-h-screen pt-28 pb-16 px-4">
        <div className="max-w-6xl mx-auto space-y-6">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">Admin Dashboard</h1>
            <p className="text-zinc-400">Manage profiles and communications across events</p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="freedomfest">FreedomFest</TabsTrigger>
              <TabsTrigger value="fee">FEE Students</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-zinc-900/50 border-zinc-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Users className="h-5 w-5 text-purple-500" />
                      FreedomFest
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Total Profiles</span>
                      <span className="text-white font-medium">{freedomfestProfiles.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Unread Messages</span>
                      <span className="text-white font-medium">{freedomfestUnreadProfiles.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Available Emails</span>
                      <span className="text-white font-medium">{freedomfestEmails.length}</span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-zinc-900/50 border-zinc-700">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <GraduationCap className="h-5 w-5 text-blue-500" />
                      FEE Student Seminar
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Total Profiles</span>
                      <span className="text-white font-medium">{feeProfiles.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Unread Messages</span>
                      <span className="text-white font-medium">{feeUnreadProfiles.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-zinc-400">Available Emails</span>
                      <span className="text-white font-medium">{feeEmails.length}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {(freedomfestEmails.length > 0 || feeEmails.length > 0) && (
                <Card className="bg-zinc-900/50 border-zinc-700">
                  <CardHeader>
                    <CardTitle className="text-white">Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {freedomfestEmails.length > 0 && (
                      <Button
                        onClick={() => copyEmailsToClipboard(freedomfestEmails, "FreedomFest")}
                        className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                        disabled={copied}
                      >
                        {copied ? (
                          <>
                            <CheckCircle className="mr-2 h-4 w-4" />
                            Copied FreedomFest Emails!
                          </>
                        ) : (
                          <>
                            <Copy className="mr-2 h-4 w-4" />
                            Copy All FreedomFest Emails ({freedomfestEmails.length})
                          </>
                        )}
                      </Button>
                    )}

                    {feeEmails.length > 0 && (
                      <Button
                        onClick={() => copyEmailsToClipboard(feeEmails, "FEE")}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                        disabled={copied}
                      >
                        {copied ? (
                          <>
                            <CheckCircle className="mr-2 h-4 w-4" />
                            Copied FEE Emails!
                          </>
                        ) : (
                          <>
                            <Copy className="mr-2 h-4 w-4" />
                            Copy All FEE Emails ({feeEmails.length})
                          </>
                        )}
                      </Button>
                    )}
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="freedomfest">
              {renderEventSection(
                freedomfestProfiles,
                freedomfestUnreadProfiles,
                freedomfestEmails,
                "FreedomFest",
                <Users className="h-5 w-5 text-purple-500" />,
              )}
            </TabsContent>

            <TabsContent value="fee">
              {renderEventSection(
                feeProfiles,
                feeUnreadProfiles,
                feeEmails,
                "FEE Student Seminar",
                <GraduationCap className="h-5 w-5 text-blue-500" />,
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AdminAuthGuard>
  )
}
