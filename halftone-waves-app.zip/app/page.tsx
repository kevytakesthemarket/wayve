"use client"

import { useEffect, useState, useMemo, useCallback, useRef } from "react"
import { getProfiles } from "@/lib/profile-service"
import type { Profile } from "@/types/profile"
import HalftoneWaves from "@/components/halftone-waves"
import { ProfileList } from "@/components/profile-list"
import { BottomNav } from "@/components/bottom-nav"
import { TopNav } from "@/components/top-nav"
import { FilterBar } from "@/components/filter-bar"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2 } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { getCurrentEventConfig, CURRENT_EVENT } from "@/lib/environment" // Import CURRENT_EVENT

// Fisher-Yates shuffle algorithm to randomize array order
const shuffleArray = <T,>(array: T[]): T[] => {
  const shuffled = [...array]
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]
  }
  return shuffled
}

export default function HomePage() {
  const [profiles, setProfiles] = useState<Profile[]>([]) // Now holds only profiles for CURRENT_EVENT
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [filters, setFilters] = useState({
    search: "",
    tags: [] as string[],
  })
  const [visibleCount, setVisibleCount] = useState(5)
  const { user } = useAuth()
  const profilesRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Fetch profiles for the CURRENT_EVENT only
    const fetchProfilesForCurrentEvent = async () => {
      setLoading(true)
      setError(null)
      try {
        console.log(`Fetching profiles for ${CURRENT_EVENT}...`)

        // Check if we have cached profiles for the current event in sessionStorage
        const cachedProfiles = sessionStorage.getItem(`shuffledProfiles_${CURRENT_EVENT}`)
        const hasShuffled = sessionStorage.getItem(`hasShuffled_${CURRENT_EVENT}`)

        if (cachedProfiles && hasShuffled) {
          // Use cached shuffled profiles
          console.log(`Using cached shuffled profiles for ${CURRENT_EVENT}`)
          setProfiles(JSON.parse(cachedProfiles))
        } else {
          // Fetch fresh profiles for the current event and shuffle them
          const fetchedProfiles = await getProfiles(CURRENT_EVENT)
          console.log(`Fetched ${fetchedProfiles.length} profiles for ${CURRENT_EVENT}`)
          const shuffledProfiles = shuffleArray(fetchedProfiles)

          // Cache the shuffled profiles for the current event
          sessionStorage.setItem(`shuffledProfiles_${CURRENT_EVENT}`, JSON.stringify(shuffledProfiles))
          sessionStorage.setItem(`hasShuffled_${CURRENT_EVENT}`, "true")

          setProfiles(shuffledProfiles)
        }
      } catch (error) {
        console.error("Error fetching profiles:", error)
        setError("Failed to load profiles. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    fetchProfilesForCurrentEvent()
  }, []) // Dependency array is empty as CURRENT_EVENT is a constant

  // Filter profiles based on search and tags (profiles state already contains only CURRENT_EVENT profiles)
  const filteredProfiles = useMemo(() => {
    const filtered = profiles.filter((profile) => {
      // Filter out current user's own profile
      if (user?.uid && (profile.userId === user.uid || profile.id === user.uid)) {
        return false
      }

      // Filter by search term
      const searchMatch =
        !filters.search ||
        profile.name.toLowerCase().includes(filters.search.toLowerCase()) ||
        profile.bio.toLowerCase().includes(filters.search.toLowerCase()) ||
        (profile.bioTag && profile.bioTag.toLowerCase().includes(filters.search.toLowerCase())) ||
        (profile.whyHereTag && profile.whyHereTag.toLowerCase().includes(filters.search.toLowerCase())) ||
        (profile.lookingForTag && profile.lookingForTag.toLowerCase().includes(filters.search.toLowerCase()))

      // Filter by tags
      const tagMatch = filters.tags.length === 0 || filters.tags.some((tag) => profile.categoryTags.includes(tag))

      return searchMatch && tagMatch
    })

    return filtered.slice(0, visibleCount)
  }, [profiles, filters, user?.uid, visibleCount])

  // Get total count of filtered profiles (without pagination)
  const totalFilteredCount = useMemo(() => {
    return profiles.filter((profile) => {
      // Filter out current user's own profile
      if (user?.uid && (profile.userId === user.uid || profile.id === user.uid)) {
        return false
      }

      // Filter by search term
      const searchMatch =
        !filters.search ||
        profile.name.toLowerCase().includes(filters.search.toLowerCase()) ||
        profile.bio.toLowerCase().includes(filters.search.toLowerCase()) ||
        (profile.bioTag && profile.bioTag.toLowerCase().includes(filters.search.toLowerCase())) ||
        (profile.whyHereTag && profile.whyHereTag.toLowerCase().includes(filters.search.toLowerCase())) ||
        (profile.lookingForTag && profile.lookingForTag.toLowerCase().includes(filters.search.toLowerCase()))

      // Filter by tags
      const tagMatch = filters.tags.length === 0 || filters.tags.some((tag) => profile.categoryTags.includes(tag))

      return searchMatch && tagMatch
    }).length
  }, [profiles, filters, user?.uid])

  const loadMore = () => {
    setVisibleCount((prev) => prev + 5)
  }

  // Use useCallback to memoize the filter change handler
  const handleFilterChange = useCallback((newFilters: { search: string; tags: string[] }) => {
    setFilters(newFilters)
    setVisibleCount(5) // Reset to show first 5 when filters change
  }, [])

  // Scroll to first profile
  const scrollToProfiles = () => {
    profilesRef.current?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    })
  }

  // Get current event config for welcome message
  const currentEventConfig = getCurrentEventConfig()

  return (
    <>
      <HalftoneWaves />
      <TopNav />

      <div className="min-h-screen flex flex-col pb-28 pt-28">
        {/* Fixed filter bar container */}
        <div className="fixed top-24 left-0 right-0 z-30 pt-4 pb-2">
          <div className="w-full max-w-md mx-auto px-4">
            <FilterBar onFilterChange={handleFilterChange} initialFilters={filters} />
          </div>
        </div>

        {/* Spacer to replace the original filter bar position */}
        <div className="h-16"></div>

        {!user && (
          <div className="w-full max-w-md mx-auto px-4 mb-4">
            <div className="bg-black border-2 border-purple-500 rounded-2xl p-6 text-center">
              <div className="mb-6">
                <h2
                  className="text-4xl font-bold italic text-purple-400 mb-4 font-serif tracking-wide"
                  style={{ fontFamily: 'Georgia, "Times New Roman", serif' }}
                >
                  Welcome To Wayve
                </h2>
                <p className="text-white text-sm leading-relaxed mb-3">{currentEventConfig.description}</p>
                <p className="text-white text-sm leading-relaxed">{currentEventConfig.tagline}</p>
              </div>
              <div className="space-y-3">
                <button
                  onClick={scrollToProfiles}
                  className="block w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-medium py-3 px-6 rounded-xl transition-all duration-200 transform hover:scale-105"
                >
                  Discover People
                </button>
                <a
                  href="/new/signup"
                  className="block w-full border border-purple-400/30 text-purple-200 hover:text-white hover:border-purple-400/50 font-medium py-3 px-6 rounded-xl transition-all duration-200"
                >
                  Create Profile
                </a>
                <a
                  href="/new/signin"
                  className="inline-block text-purple-300 hover:text-white text-sm underline transition-colors duration-200"
                >
                  Already have an account? Sign in
                </a>
              </div>
            </div>
          </div>
        )}

        <main className="flex-1 flex flex-col items-center px-4">
          <div className="w-full max-w-md" ref={profilesRef}>
            {error && (
              <Alert className="mb-4 bg-amber-900/20 border-amber-800 text-amber-300">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {loading ? (
              <div className="text-center py-10">
                <Loader2 className="h-8 w-8 animate-spin text-purple-500 mx-auto mb-2" />
                <p className="text-zinc-400">Loading profiles...</p>
              </div>
            ) : (
              <>
                <ProfileList profiles={filteredProfiles} />
                {visibleCount < totalFilteredCount && (
                  <div className="text-center py-6">
                    <button
                      onClick={loadMore}
                      className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-medium py-3 px-8 rounded-xl transition-all duration-200 transform hover:scale-105"
                    >
                      Load More ({totalFilteredCount - visibleCount} remaining)
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </main>
      </div>

      <BottomNav />
    </>
  )
}
