// Detect if we're in a preview environment
export const isPreviewEnvironment = (): boolean => {
  // Check for explicit environment variable
  if (process.env.NEXT_PUBLIC_VERCEL_ENV === "production") {
    return false
  }

  // Check for preview or development environment variables
  if (
    process.env.NEXT_PUBLIC_VERCEL_ENV === "preview" ||
    process.env.NEXT_PUBLIC_VERCEL_ENV === "development" ||
    process.env.NODE_ENV === "development"
  ) {
    return true
  }

  // Check for preview domains
  if (typeof window !== "undefined") {
    const hostname = window.location.hostname
    if (hostname.includes("vercel.app") || hostname.includes("localhost") || hostname.includes("127.0.0.1")) {
      return true
    }
  }

  // Default to false for safety
  return false
}

// Log the current environment
export const logEnvironment = (): void => {
  console.log(`Environment: ${process.env.NEXT_PUBLIC_VERCEL_ENV || "not set"}`)
  console.log(`Node Environment: ${process.env.NODE_ENV || "not set"}`)
  console.log(`Is Preview Environment: ${isPreviewEnvironment()}`)
  if (typeof window !== "undefined") {
    console.log(`Hostname: ${window.location.hostname}`)
  }
}
