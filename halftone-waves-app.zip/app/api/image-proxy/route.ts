import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  // Get the URL from the query parameter
  const url = request.nextUrl.searchParams.get("url")

  if (!url) {
    return new NextResponse("Missing URL parameter", { status: 400 })
  }

  try {
    // Decode the URL
    const decodedUrl = decodeURIComponent(url)

    // Ensure the URL has alt=media parameter if it's a Firebase Storage URL
    let fetchUrl = decodedUrl
    if (fetchUrl.includes("firebasestorage") && !fetchUrl.includes("alt=media")) {
      fetchUrl = fetchUrl.includes("?") ? `${fetchUrl}&alt=media` : `${fetchUrl}?alt=media`
    }

    // Fetch the image with a timeout
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

    const response = await fetch(fetchUrl, {
      headers: {
        Origin: request.headers.get("origin") || "https://wayve.bio",
      },
      signal: controller.signal,
      cache: "force-cache",
    })

    clearTimeout(timeoutId)

    if (!response.ok) {
      return new NextResponse(`Failed to fetch image: ${response.status} ${response.statusText}`, {
        status: response.status,
      })
    }

    // Get the image data
    const imageData = await response.arrayBuffer()

    // Get the content type
    const contentType = response.headers.get("content-type") || "image/jpeg"

    // Return the image with appropriate headers
    return new NextResponse(imageData, {
      headers: {
        "Content-Type": contentType,
        "Cache-Control": "public, max-age=86400",
        "Access-Control-Allow-Origin": "*",
      },
    })
  } catch (error) {
    console.error("Error proxying image:", error)
    return new NextResponse(`Error proxying image: ${error instanceof Error ? error.message : "Unknown error"}`, {
      status: 500,
    })
  }
}
