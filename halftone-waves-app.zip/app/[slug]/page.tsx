"use client"

import { useEffect, useState, useRef } from "react"
import { useParams, useRouter } from "next/navigation"
import { getProfile, updateProfile } from "@/lib/profile-service"
import type { Profile } from "@/types/profile"
import HalftoneWaves from "@/components/halftone-waves"
import { ProfileCard } from "@/components/profile-card"
import { BottomNav } from "@/components/bottom-nav"
import { TopNav } from "@/components/top-nav"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Edit, Loader2, Save, X, AlertCircle, CheckCircle } from "lucide-react"
import { motion } from "framer-motion"
import { ProfileOwnerBadge } from "@/components/profile-owner-badge"
import { useAuth } from "@/contexts/auth-context"
import { ProfileEditor } from "@/components/profile-editor"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { MessageButton } from "@/components/message-button"

export default function ProfilePage() {
  const params = useParams()
  const router = useRouter()
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [highlightedSection, setHighlightedSection] = useState<string | null>(null)
  const [isEditMode, setIsEditMode] = useState(false)
  const [editedProfile, setEditedProfile] = useState<Profile | null>(null)
  const [formValid, setFormValid] = useState(true)

  // Function to update edited profile without causing unnecessary re-renders
  const updateEditedProfile = (updatedProfile: Profile) => {
    // Only update if there are actual changes
    setEditedProfile((prev) => {
      if (JSON.stringify(prev) === JSON.stringify(updatedProfile)) {
        return prev // No changes, return the previous state
      }

      // Check if the profile has at least 1 photo (we'll validate more in the save function)
      setFormValid(updatedProfile.photos && updatedProfile.photos.length >= 1)

      return updatedProfile // Changes detected, update the state
    })
  }

  const profileRef = useRef<HTMLDivElement>(null)
  const { user } = useAuth()

  useEffect(() => {
    if (params.slug) {
      const slug = Array.isArray(params.slug) ? params.slug[0] : params.slug

      // Check if this is a reserved route that should redirect to its proper page
      const reservedRoutes = [
        "signin",
        "signup",
        "reset-password",
        "create",
        "debug-images",
        "test-upload",
        "image-test",
        "direct-image",
        "environment",
        "new", // Add this to prevent conflicts with the /new directory
      ]

      if (reservedRoutes.includes(slug)) {
        router.replace(`/${slug}`)
        return
      }

      const fetchProfile = async () => {
        try {
          const fetchedProfile = await getProfile(slug)

          if (fetchedProfile) {
            // Ensure all required arrays exist
            const safeProfile = {
              ...fetchedProfile,
              photos: fetchedProfile.photos || [],
              categoryTags: fetchedProfile.categoryTags || [],
            }
            setProfile(safeProfile)
            updateEditedProfile(safeProfile)
          } else {
            console.error("Profile not found:", slug)
            setError("Profile not found")
          }
          setLoading(false)
        } catch (error) {
          console.error("Error fetching profile:", error)
          setError("Failed to load profile")
          setLoading(false)
        }
      }

      fetchProfile()
    }
  }, [params.slug, router])

  // Handle hash fragment for section scrolling
  useEffect(() => {
    if (typeof window !== "undefined" && profile && !isEditMode) {
      // Get the hash fragment from the URL
      const hash = window.location.hash.replace("#", "")

      if (hash) {
        setHighlightedSection(hash)

        // Wait for the component to render with the highlighted section
        setTimeout(() => {
          const element = document.getElementById(hash)
          if (element) {
            // Scroll to the element with offset for the fixed header
            const headerOffset = 100 // Adjust based on your header height
            const elementPosition = element.getBoundingClientRect().top
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset

            window.scrollTo({
              top: offsetPosition,
              behavior: "smooth",
            })
          }
        }, 300)
      }
    }
  }, [profile, isEditMode])

  // Check if the current user is the owner of this profile
  const isProfileOwner = user && profile && profile.userId === user.uid

  // Update the handleSaveProfile function to properly handle the save
  const handleSaveProfile = async () => {
    if (!editedProfile || !profile) return

    // Clear previous messages
    setError(null)
    setSuccess(null)

    // Validate required fields
    if (!editedProfile.name || !editedProfile.bio || !editedProfile.whyHere || !editedProfile.lookingFor) {
      setError("Please fill in all required fields")
      return
    }

    // Validate required tags
    if (!editedProfile.bioTag || !editedProfile.whyHereTag || !editedProfile.lookingForTag) {
      setError("Please provide all required tags")
      return
    }

    // Validate photos - require at least 1 photo
    if (!editedProfile.photos || editedProfile.photos.length < 1) {
      setError("Please upload at least one photo")
      return
    }

    setSaving(true)

    try {
      // Ensure we have the userId from the original profile
      const updatedProfile = {
        ...editedProfile,
        userId: profile.userId, // Ensure userId is preserved
      }

      await updateProfile(profile.id, updatedProfile)
      setProfile(updatedProfile)
      setSuccess("Profile saved successfully!")

      // Don't exit edit mode immediately to allow user to see success message
      setTimeout(() => {
        if (!error) {
          setIsEditMode(false)
          setSuccess(null)
        }
      }, 2000)
    } catch (error) {
      console.error("Error updating profile:", error)
      setError(error instanceof Error ? error.message : "Failed to save profile changes. Please try again.")
    } finally {
      setSaving(false)
    }
  }

  const handleCancelEdit = () => {
    updateEditedProfile(profile as Profile)
    setIsEditMode(false)
    setError(null)
    setSuccess(null)
  }

  if (loading) {
    return (
      <>
        <HalftoneWaves />
        <TopNav />
        <div className="min-h-screen flex items-center justify-center pb-28 pt-24">
          <div className="text-white flex flex-col items-center">
            <Loader2 className="h-8 w-8 animate-spin mb-4" />
            <div>Loading profile...</div>
          </div>
        </div>
        <BottomNav />
      </>
    )
  }

  if (error || !profile) {
    return (
      <>
        <HalftoneWaves />
        <TopNav />
        <div className="min-h-screen flex flex-col items-center justify-center pb-28 pt-24">
          <div className="text-white mb-4 text-center">
            <h2 className="text-xl font-bold mb-2">Profile Not Found</h2>
            <p className="text-zinc-400 mb-4">The profile you're looking for doesn't exist.</p>
          </div>
          <Button onClick={() => router.push("/")} variant="outline">
            Go back to browse
          </Button>
        </div>
        <BottomNav />
      </>
    )
  }

  return (
    <>
      <HalftoneWaves />
      <TopNav />

      <div className="min-h-screen flex flex-col pb-28 pt-28 px-4">
        <div className="flex justify-between items-center mb-4">
          <Button variant="ghost" size="sm" className="text-white" onClick={() => router.push("/")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>

          {/* Show the owner badge if this is the user's profile */}
          {!isEditMode && <ProfileOwnerBadge profileUserId={profile.userId} />}

          {/* Toggle between edit and view modes if this is the user's profile */}
          {isProfileOwner &&
            (isEditMode ? (
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="text-red-300 border-red-700 hover:bg-red-900/30"
                  onClick={handleCancelEdit}
                >
                  <X className="mr-2 h-4 w-4" />
                  Cancel
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-purple-300 border-purple-700 hover:bg-purple-900/30"
                  onClick={handleSaveProfile}
                  disabled={saving || !formValid}
                >
                  {saving ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Save
                    </>
                  )}
                </Button>
              </div>
            ) : (
              <Button
                variant="outline"
                size="sm"
                className="text-purple-300 border-purple-700 hover:bg-purple-900/30"
                onClick={() => setIsEditMode(true)}
              >
                <Edit className="mr-2 h-4 w-4" />
                Edit Profile
              </Button>
            ))}
        </div>

        {error && (
          <Alert className="mb-4 bg-red-900/20 border-red-800 text-red-300">
            <AlertCircle className="h-4 w-4 mr-2" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-4 bg-green-900/20 border-green-800 text-green-300">
            <CheckCircle className="h-4 w-4 mr-2" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        <main className="flex-1 flex flex-col items-center justify-center">
          <motion.div
            ref={profileRef}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="w-full max-w-md"
          >
            {isEditMode && editedProfile ? (
              <ProfileEditor
                profile={editedProfile}
                onProfileChange={updateEditedProfile}
                onSave={handleSaveProfile}
                saving={saving}
                formValid={formValid}
              />
            ) : (
              <ProfileCard
                profile={profile}
                expanded={true}
                disableNavigation={true}
                highlightedSection={highlightedSection}
              />
            )}
            {!isProfileOwner && profile && (
              <div className="mt-4 w-full max-w-md">
                <MessageButton userId={profile.userId} userName={profile.name} className="w-full" />
              </div>
            )}
          </motion.div>
        </main>
      </div>

      <BottomNav />
    </>
  )
}
