"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AdminAuthGuard } from "@/components/admin-auth-guard"
import { AdminService, type AdminStats, type RecentUser, type BusinessMetrics } from "@/lib/admin-service"
import {
  Users,
  MessageSquare,
  Activity,
  RefreshCw,
  AlertCircle,
  TrendingUp,
  Target,
  BarChart3,
  UserCheck,
} from "lucide-react"
import { formatDistanceToNow } from "date-fns"

function AdminDashboard() {
  const [stats, setStats] = useState<AdminStats | null>(null)
  const [recentUsers, setRecentUsers] = useState<RecentUser[]>([])
  const [businessMetrics, setBusinessMetrics] = useState<BusinessMetrics | null>(null)
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const loadData = async () => {
    try {
      setRefreshing(true)
      setError(null)

      console.log("Loading admin data...")

      const [statsData, usersData, businessData] = await Promise.all([
        AdminService.getStats(),
        AdminService.getRecentUsers(20),
        AdminService.getBusinessMetrics(),
      ])

      console.log("Data loaded successfully")
      setStats(statsData)
      setRecentUsers(usersData)
      setBusinessMetrics(businessData)
    } catch (error) {
      console.error("Error loading admin data:", error)
      setError("Failed to load admin data. Please check console for details.")
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4 text-white" />
          <p className="text-white">Loading business analytics...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <div className="text-center">
          <AlertCircle className="h-8 w-8 mx-auto mb-4 text-red-400" />
          <p className="text-white mb-4">{error}</p>
          <Button onClick={loadData} className="bg-purple-600 hover:bg-purple-700">
            Retry
          </Button>
        </div>
      </div>
    )
  }

  if (!stats || !businessMetrics) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <div className="text-center">
          <p className="text-white">No data available</p>
          <Button onClick={loadData} className="mt-4 bg-purple-600 hover:bg-purple-700">
            Retry
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Business Analytics</h1>
            <p className="text-purple-200">wayve.bio product viability metrics</p>
          </div>
          <Button onClick={loadData} disabled={refreshing} className="bg-purple-600 hover:bg-purple-700">
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? "animate-spin" : ""}`} />
            Refresh Data
          </Button>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-black/20 backdrop-blur-sm">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="growth">Growth</TabsTrigger>
            <TabsTrigger value="engagement">Engagement</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Key Business Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-white">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-purple-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{stats.totalUsers}</div>
                  <p className="text-xs text-purple-200">
                    {stats.newUsersToday > 0 ? `+${stats.newUsersToday} today` : "No new users today"}
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-white">Profile Creation Rate</CardTitle>
                  <UserCheck className="h-4 w-4 text-green-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{stats.profileCompletionRate}%</div>
                  <p className="text-xs text-green-200">{stats.totalProfiles} profiles created</p>
                </CardContent>
              </Card>

              <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-white">Messaging Engagement</CardTitle>
                  <MessageSquare className="h-4 w-4 text-blue-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">
                    {stats.engagementMetrics.messagingEngagementRate}%
                  </div>
                  <p className="text-xs text-blue-200">{stats.engagementMetrics.usersWithMessages} users messaging</p>
                </CardContent>
              </Card>

              <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-white">Daily Active Rate</CardTitle>
                  <Activity className="h-4 w-4 text-orange-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{stats.dailyActiveRate}%</div>
                  <p className="text-xs text-orange-200">{stats.activeUsersToday} active today</p>
                </CardContent>
              </Card>
            </div>

            {/* Debug Information */}
            {stats.debugInfo && (
              <Card className="bg-red-900/20 backdrop-blur-sm border-red-500/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <AlertCircle className="h-5 w-5 mr-2" />
                    Debug Information
                  </CardTitle>
                  <CardDescription className="text-red-200">Firebase connection and data status</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-white">Firebase Connected</span>
                    <Badge variant={stats.debugInfo.firebaseConnected ? "default" : "destructive"}>
                      {stats.debugInfo.firebaseConnected ? "Yes" : "No"}
                    </Badge>
                  </div>
                  <div className="space-y-1">
                    <span className="text-white">Collections Found:</span>
                    {stats.debugInfo.collectionsFound.length > 0 ? (
                      stats.debugInfo.collectionsFound.map((collection, index) => (
                        <div key={index} className="text-sm text-purple-200 ml-4">
                          • {collection}
                        </div>
                      ))
                    ) : (
                      <div className="text-sm text-red-200 ml-4">No collections found</div>
                    )}
                  </div>
                  {stats.debugInfo.errors.length > 0 && (
                    <div className="space-y-1">
                      <span className="text-white">Errors:</span>
                      {stats.debugInfo.errors.map((error, index) => (
                        <div key={index} className="text-sm text-red-200 ml-4">
                          • {error}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Product Viability Indicators */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2" />
                    Product Traction
                  </CardTitle>
                  <CardDescription className="text-purple-200">Key indicators of product-market fit</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white">User Acquisition</span>
                    <div className="text-right">
                      <div className="text-white font-medium">{stats.newUsersThisWeek} this week</div>
                      <div className="text-xs text-purple-200">{stats.newUsersThisMonth} this month</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">User Activation</span>
                    <div className="text-right">
                      <div className="text-white font-medium">{stats.profileCompletionRate}%</div>
                      <div className="text-xs text-purple-200">create profiles</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">User Engagement</span>
                    <div className="text-right">
                      <div className="text-white font-medium">{stats.engagementMetrics.messagingEngagementRate}%</div>
                      <div className="text-xs text-purple-200">send messages</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">User Retention</span>
                    <div className="text-right">
                      <div className="text-white font-medium">{stats.weeklyActiveRate}%</div>
                      <div className="text-xs text-purple-200">weekly active</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Target className="h-5 w-5 mr-2" />
                    Content Quality
                  </CardTitle>
                  <CardDescription className="text-purple-200">User-generated content metrics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white">Profiles with Photos</span>
                    <div className="text-right">
                      <div className="text-white font-medium">{stats.profilesWithPhotos}</div>
                      <div className="text-xs text-purple-200">
                        {Math.round((stats.profilesWithPhotos / Math.max(stats.totalProfiles, 1)) * 100)}% of profiles
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Average Photos</span>
                    <div className="text-right">
                      <div className="text-white font-medium">{stats.averagePhotosPerProfile}</div>
                      <div className="text-xs text-purple-200">per profile</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Total Images</span>
                    <div className="text-right">
                      <div className="text-white font-medium">{stats.storageStats.totalImages}</div>
                      <div className="text-xs text-purple-200">{stats.storageStats.estimatedStorageUsed}</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Popular Tags</span>
                    <div className="text-right">
                      <div className="text-white font-medium">{stats.topTags.length}</div>
                      <div className="text-xs text-purple-200">unique tags</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Communication Activity */}
            <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  Communication Activity
                </CardTitle>
                <CardDescription className="text-purple-200">Platform interaction metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">{stats.totalConversations}</div>
                    <div className="text-sm text-purple-200">Total Conversations</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">{stats.totalMessages}</div>
                    <div className="text-sm text-purple-200">Total Messages</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">{stats.messageStats.conversationsToday}</div>
                    <div className="text-sm text-purple-200">New Conversations Today</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">
                      {stats.messageStats.averageMessagesPerConversation}
                    </div>
                    <div className="text-sm text-purple-200">Avg Messages/Conversation</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="growth" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white">User Growth</CardTitle>
                  <CardDescription className="text-purple-200">Registration trends</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white">Today</span>
                    <Badge variant="secondary">{businessMetrics.userGrowth.today}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">This Week</span>
                    <Badge variant="secondary">{businessMetrics.userGrowth.week}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">This Month</span>
                    <Badge variant="secondary">{businessMetrics.userGrowth.month}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Growth Rate</span>
                    <Badge variant={businessMetrics.userGrowth.growthRate > 0 ? "default" : "outline"}>
                      {businessMetrics.userGrowth.growthRate > 0 ? "+" : ""}
                      {businessMetrics.userGrowth.growthRate}%
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Engagement Rates</CardTitle>
                  <CardDescription className="text-purple-200">User activation metrics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white">Profile Creation</span>
                    <Badge variant="secondary">{businessMetrics.engagement.profileCreation}%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Messaging</span>
                    <Badge variant="secondary">{businessMetrics.engagement.messaging}%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Photo Uploads</span>
                    <Badge variant="secondary">{businessMetrics.engagement.photoUploads}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Daily Active</span>
                    <Badge variant="secondary">{businessMetrics.engagement.dailyActive}%</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Retention</CardTitle>
                  <CardDescription className="text-purple-200">User return rates</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white">Weekly Active</span>
                    <Badge variant="secondary">{businessMetrics.retention.weeklyActive}%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Returning Users</span>
                    <Badge variant="secondary">{Math.max(0, businessMetrics.retention.returningUsers)}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">New vs Returning</span>
                    <Badge variant="outline">
                      {stats.newUsersThisWeek}:{Math.max(0, businessMetrics.retention.returningUsers)}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="engagement" className="space-y-6">
            {/* Popular Tags */}
            <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white">Popular Tags</CardTitle>
                <CardDescription className="text-purple-200">
                  Most used profile tags indicate user interests
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {stats.topTags.length > 0 ? (
                    stats.topTags.map((tag, index) => (
                      <Badge key={tag.tag} variant={index < 3 ? "default" : "secondary"} className="text-sm">
                        {tag.tag} ({tag.count})
                      </Badge>
                    ))
                  ) : (
                    <p className="text-purple-200">No tags found</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Engagement Breakdown */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white">User Journey</CardTitle>
                  <CardDescription className="text-purple-200">Conversion funnel</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white">1. Sign Up</span>
                    <Badge variant="secondary">{stats.totalUsers} users</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">2. Create Profile</span>
                    <Badge variant="secondary">
                      {stats.totalProfiles} ({stats.profileCompletionRate}%)
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">3. Add Photos</span>
                    <Badge variant="secondary">
                      {stats.profilesWithPhotos} (
                      {Math.round((stats.profilesWithPhotos / Math.max(stats.totalUsers, 1)) * 100)}%)
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">4. Send Messages</span>
                    <Badge variant="secondary">
                      {stats.engagementMetrics.usersWithMessages} ({stats.engagementMetrics.messagingEngagementRate}%)
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Activity Levels</CardTitle>
                  <CardDescription className="text-purple-200">User engagement distribution</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white">Highly Active</span>
                    <Badge variant="default">{stats.activeUsersToday} users</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Moderately Active</span>
                    <Badge variant="secondary">{stats.activeUsersThisWeek - stats.activeUsersToday} users</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Inactive</span>
                    <Badge variant="outline">{stats.totalUsers - stats.activeUsersThisWeek} users</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white">Recent User Registrations</CardTitle>
                <CardDescription className="text-purple-200">Latest users who joined the platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentUsers.length > 0 ? (
                    recentUsers.map((user) => (
                      <div key={user.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                        <div className="space-y-1">
                          <p className="text-white font-medium">{user.displayName}</p>
                          <p className="text-sm text-purple-200">{user.email}</p>
                          <p className="text-xs text-purple-300">Joined {formatDistanceToNow(user.createdAt)} ago</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant={user.profileComplete ? "default" : "outline"}>
                            {user.profileComplete ? "Complete Profile" : "Basic Profile"}
                          </Badge>
                          <Badge variant="secondary">{user.photoCount} photos</Badge>
                          {user.hasMessages && <Badge variant="default">Active</Badge>}
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-purple-200">No users found</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default function AdminPage() {
  return (
    <AdminAuthGuard>
      <AdminDashboard />
    </AdminAuthGuard>
  )
}
